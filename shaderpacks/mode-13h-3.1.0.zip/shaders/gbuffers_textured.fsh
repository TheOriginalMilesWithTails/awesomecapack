#version 410 compatibility
#include "/shaders.settings"
#include "/lib/vertex.glsl"
#include "/lib/common.glsl"
#include "/lib/fog.glsl"
#include "/lib/texmap.glsl"

uniform float alphaTestRef;
uniform int   renderStage;

/* RENDERTARGETS: 0 */
layout(location=0) out vec4 out0;

void main() {
    vec4 c = albedo(texmap(texcoord));
    if (c.a < alphaTestRef) discard;

    c.rgb *= applyLightmap(lmcoord);
    // Vanilla never fogs the world border.
    if (renderStage != MC_RENDER_STAGE_WORLD_BORDER) c.rgb = applyFog(c.rgb, viewPos);
    out0 = c;
}
