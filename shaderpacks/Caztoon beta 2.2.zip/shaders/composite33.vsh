#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
out vec2 _z7xvepo;
void main() {
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; reverse engineering, de-obfuscating or porting it to another pack is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. See LICENSE.txt.
gl_Position = ftransform();
_z7xvepo = gl_MultiTexCoord0.xy;
}
