#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; publishing, reverse engineering or redistributing needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
#include "/rr9/wkfbmt14go.glsl"
#include "/rr9/4856ceyj3d.glsl"
#define _w1rsfiy
#if !defined(LITE_COLORTEX_BLOOM)
#define _leupucv _il3xhlh
#define _y35vvmk _xgjna3b
#endif
#include "/rr9/23faim3pgm.glsl"
