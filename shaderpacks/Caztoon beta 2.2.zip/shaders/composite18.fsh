#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/wkfbmt14go.glsl"
#if defined(LITE_COLORTEX_BLOOM)
/* RENDERTARGETS: 18 */
#define _2r9jej1 colortex19
#define _6ohanj7 colortex18
#else
/* RENDERTARGETS: 0 */
#define _v7wrevx _ulprlq3(2)
#define _c0xks95 _fr08pcx(1)
#define _sk60y37 _ulprlq3(1)
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; copying, modifying, porting it to another pack or redistributing is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
#endif
#define _vyf9bba 1
#include "/rr9/wm70sg16wp.glsl"
