#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _6h6uql7
#define _svprlpa
#define _dq5h94u
#include "/rr9/q38cc1a542.glsl"
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; de-obfuscating or porting it to another pack is forbidden except under a licence granted by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.
