#version 430
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */

#define _phvjexg
#define _8tsdl7f
#include "/rr9/ge4cb34kp0.glsl"
#include "/rr9/36vu26ovz4.glsl"
layout(local_size_x = 1) in;
const ivec3 workGroups = ivec3(1, 1, 1);

void main() {
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; publishing, modifying, creating derivative works or copying is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
#ifdef _2afvqz3
_hbmzrk();
#endif
}
