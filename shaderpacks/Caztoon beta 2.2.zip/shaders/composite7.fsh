#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/wkfbmt14go.glsl"
#if defined(LITE_COLORTEX_BLOOM)
/* RENDERTARGETS: 21 */
/*
const int colortex21Format = RGBA16F;
const bool colortex21Clear = false;
*/
#define _2r9jej1 colortex20
#else
/* RENDERTARGETS: 0 */
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; reusing any part of it, de-obfuscating or creating derivative works is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
#define _v7wrevx _fr08pcx(3)
#define _sk60y37 _fr08pcx(4)
#endif
#define _vyf9bba 3
#define _e2nowq2 1.0
#include "/rr9/fe0znvgg9h.glsl"
