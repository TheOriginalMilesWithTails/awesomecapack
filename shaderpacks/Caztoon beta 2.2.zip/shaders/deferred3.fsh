#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/satjv7rggs.glsl"
#include "/rr9/y3wct80d7i.glsl"
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is licensed for personal use only, not sold; decompiling or reusing any part of it is forbidden except under a licence granted by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. See LICENSE.txt.
#include "/rr9/uneyo5e641.glsl"
#include "/rr9/50umix7w9z.glsl"
#include "/rr9/l0gbzvdde6.glsl"
#include "/rr9/ge4cb34kp0.glsl"
#include "/rr9/lhawfjjnae.glsl"
#ifdef BLOCKLIGHT_BLOOM_ENABLED
#ifdef LITE_VOXY_SHADOWS
/* RENDERTARGETS: 0,1,3,4,15,7 */
#elif OUTLINES != 0 || defined(_stlozh9)
/* RENDERTARGETS: 0,1,3,4,15 */
#else
/* RENDERTARGETS: 0,1,4,15 */
#endif
#else
#ifdef LITE_VOXY_SHADOWS
/* RENDERTARGETS: 0,1,3,7 */
#elif OUTLINES != 0 || defined(_stlozh9)
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is closed source and under copyright; de-obfuscating, redistributing, copying or decompiling is off limits unless Cazfps personally licensed it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
/* RENDERTARGETS: 0,1,3 */
#else
/* RENDERTARGETS: 0,1 */
#endif
#endif
uniform sampler2D colortex0;
uniform sampler2D colortex1;
#if defined(LITE_COLORTEX_BLOOM)
uniform sampler2D colortex26;
uniform sampler2D colortex27;
#endif
#include "/rr9/f8akl8gy30.glsl"
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; redistributing or selling needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.
uniform float rainStrength;
uniform bool hasSkylight;
in vec2 _z7xvepo;
#include "/rr9/4uu51x4yxo.glsl"
#include "/rr9/7u6wg6ss8e.glsl"
layout(location=0) out vec4 _1kococs;
layout(location=1) out vec4 _v1n5ctq;
#if OUTLINES != 0 || defined(LITE_VOXY_SHADOWS) || defined(_stlozh9)
uniform sampler2D colortex3;
layout(location=2) out vec4 _0o9959g;
#define _kxlyxz1 3
#define _o1588s1 4
#else
#define _kxlyxz1 2
#define _o1588s1 3
#endif
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; publishing or modifying is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
#ifdef BLOCKLIGHT_BLOOM_ENABLED
uniform sampler2D colortex4;
uniform sampler2D colortex15;
layout(location=_kxlyxz1) out vec4 _vr7imyu;
layout(location=_o1588s1) out vec4 _epcr1q1;
#endif
#ifdef _65jbzyx

vec3 _13a0me(ivec2 _btdiwo) {
ivec2 _plevir = textureSize(colortex0, 0);
vec3 _z05q9y = vec3(0.0);
float _byknzn4 = 0.0;
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; porting it to another pack, redistributing or creating derivative works is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
for (int _q6mctg = 0; _q6mctg < 4; _q6mctg++) {
ivec2 _x6uhjq = _q6mctg == 0 ? ivec2(1, 0) : _q6mctg == 1 ? ivec2(-1, 0)
: _q6mctg == 2 ? ivec2(0, 1) : ivec2(0, -1);
for (int k = 0; k < 11; k++) {
ivec2 p = _btdiwo + _x6uhjq * (1 << k);
if (any(lessThan(p, ivec2(0))) || any(greaterThanEqual(p, _plevir))) break;
vec3 _bk54v9 = texelFetch(colortex1, p, 0).rgb;
if (max(_bk54v9.r, max(_bk54v9.g, _bk54v9.b)) > 0.0) continue;
if (_trxs6u((vec2(p) + 0.5) / vec2(_plevir)) > 1e19) {
_z05q9y += texelFetch(colortex0, p, 0).rgb;
_byknzn4 += 1.0;
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; modifying, porting it to another pack, selling or redistributing is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
}
break;
}
}
return _byknzn4 > 0.0 ? _z05q9y / _byknzn4 : vec3(-1.0);
}
#endif
#ifdef LITE_VOXY_SHADOWS
uniform sampler2D colortex7;
#ifdef BLOCKLIGHT_BLOOM_ENABLED
layout(location=5) out vec4 _0for39k;
#else
layout(location=3) out vec4 _0for39k;
#endif
#endif
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is licensed for personal use only, not sold; redistributing, creating derivative works or porting it to another pack is off limits unless Cazfps personally licensed it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Full terms: LICENSE.txt.
void main() {
_1kococs = texture(colortex0,_z7xvepo);
_v1n5ctq = texture(colortex1,_z7xvepo);
#if OUTLINES != 0 || defined(LITE_VOXY_SHADOWS) || defined(_stlozh9)
_0o9959g = texture(colortex3,_z7xvepo);
#endif
#ifdef BLOCKLIGHT_BLOOM_ENABLED
_vr7imyu = texture(colortex4,_z7xvepo);
_epcr1q1 = texture(colortex15,_z7xvepo);
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; publishing or reusing any part of it is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none.
#endif
#ifdef LITE_VOXY_SHADOWS
_0for39k = texture(colortex7,_z7xvepo);
#endif
#ifdef _65jbzyx
if (!hasSkylight) return;
ivec2 _plevir = _ihvzr67();
ivec2 _btdiwo = clamp(ivec2(_z7xvepo*vec2(_plevir)),ivec2(0),_plevir-1);
vec2 _5r0rfx = _2a95ps(_btdiwo);
float _kozpav = clamp(_5r0rfx.r,0.0,1.0);
if (_kozpav <= 0.001 || _5r0rfx.g <= 0.001) return;
float _0fhp25 = max(2.0, _5r0rfx.g * 0.002);
if (_trxs6u(_z7xvepo) < _5r0rfx.g - _0fhp25) return;
vec3 _a8mxcz = (_3lmhxs(gbufferProjectionInverse) * vec4(_z7xvepo*2.0-1.0,1.0,1.0)).xyz;
float distance = _5r0rfx.g * length(_a8mxcz) / max(-_a8mxcz.z,1e-6);
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; porting it to another pack, reverse engineering or decompiling is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. See LICENSE.txt.
#ifdef CLOUDS_GHIBLI_ENABLED
float _mea99d = _p4wx4w(distance,rainStrength);
#else

float _mea99d = 1.0;
#endif
vec3 _jr2wln = _cpkyry(_btdiwo).rgb * _mea99d;
float _097su9 = 1.0 - _kozpav * _mea99d;

#ifdef CLOUDS_GHIBLI_ENABLED
float _5utkjp = _kozpav * min(_mea99d * 2.0, 1.0);
#else

float _5utkjp = max(_cpkyry(_btdiwo).a, _kozpav);
#endif
vec3 _1blv0o = _v1n5ctq.rgb;
if (_5utkjp > _kozpav * _mea99d && max(_1blv0o.r, max(_1blv0o.g, _1blv0o.b)) > 0.0) {

vec3 _hbg2j9 = max(_1kococs.rgb - _1blv0o, 0.0);
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; creating derivative works, redistributing or modifying is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. The same terms bind any software acting on a person's behalf.
vec3 _skfvrt = step(0.996, _1kococs.rgb);
if (max(_skfvrt.r, max(_skfvrt.g, _skfvrt.b)) > 0.0) {
vec3 _of36mv = _13a0me(ivec2(gl_FragCoord.xy));
_hbg2j9 = mix(_hbg2j9, _of36mv.r >= 0.0 ? _of36mv : _cpkyry(_btdiwo).rgb / _kozpav, _skfvrt);
}
_1kococs.rgb = _hbg2j9 * _097su9 + _1blv0o * (1.0 - _5utkjp) + _jr2wln;
} else {
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; creating derivative works, selling, publishing or decompiling is forbidden except under a licence granted by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
_1kococs.rgb = _1kococs.rgb * _097su9 + _jr2wln;
}
_v1n5ctq.rgb *= 1.0 - _5utkjp;
#if OUTLINES != 0 || defined(LITE_VOXY_SHADOWS) || defined(_stlozh9)
_0o9959g.r *= _097su9;
#endif
#ifdef BLOCKLIGHT_BLOOM_ENABLED
_vr7imyu.rgb *= _097su9;
_epcr1q1.r *= _097su9;
#endif
#ifdef LITE_VOXY_SHADOWS
_0for39k.rgb *= _097su9;
#endif
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; porting it to another pack, selling, reusing any part of it or de-obfuscating is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
#endif
}
