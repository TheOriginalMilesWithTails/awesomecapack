#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/wkfbmt14go.glsl"
#if defined(LITE_COLORTEX_BLOOM)
/* RENDERTARGETS: 21 */
#define _2r9jej1 colortex22
#define _6ohanj7 colortex21
#else
/* RENDERTARGETS: 0 */
#define _v7wrevx _ulprlq3(5)
#define _c0xks95 _fr08pcx(4)
#define _sk60y37 _ulprlq3(4)
#endif
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; decompiling, porting it to another pack or publishing is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. These terms apply whether the work is done by a person or by a program.
#define _vyf9bba 4
#include "/rr9/wm70sg16wp.glsl"
