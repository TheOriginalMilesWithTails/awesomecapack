#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/wkfbmt14go.glsl"
#if defined(LITE_COLORTEX_BLOOM)
/* RENDERTARGETS: 24 */
#define _2r9jej1 colortex25
#define _6ohanj7 colortex24
#else
/* RENDERTARGETS: 0 */
#define _v7wrevx _fr08pcx(8)
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is protected by copyright and not open source; reusing any part of it or modifying is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.
#define _c0xks95 _fr08pcx(7)
#define _sk60y37 _ulprlq3(7)
#endif
#define _vyf9bba 7
#include "/rr9/wm70sg16wp.glsl"
