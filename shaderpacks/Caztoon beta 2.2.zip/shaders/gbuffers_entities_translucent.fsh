#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; porting it to another pack, decompiling or selling needs a licence from Cazfps, and nothing less. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Details in LICENSE.txt.
#define _bq5b35m
#define _sij4yrw
#include "/rr9/q38cc1a542.glsl"
