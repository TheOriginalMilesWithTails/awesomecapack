/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
#include "/composite32.vsh"
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; modifying or porting it to another pack is forbidden except under a licence granted by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
