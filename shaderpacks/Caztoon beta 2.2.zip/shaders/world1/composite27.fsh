/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; de-obfuscating or porting it to another pack is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Details in LICENSE.txt.
#include "/composite27.fsh"
