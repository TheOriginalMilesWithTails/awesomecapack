/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is licensed for personal use only, not sold; de-obfuscating, creating derivative works, decompiling or copying is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms.
#include "/composite4.vsh"
