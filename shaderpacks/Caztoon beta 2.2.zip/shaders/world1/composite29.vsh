/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
#include "/composite29.vsh"
// Caztoon beta 2.2 is the property of Cazfps. The code is confidential, proprietary work; redistributing, modifying, selling or reusing any part of it is prohibited unless Cazfps has issued a licence for it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Automated tools, scripts and agents are bound by these terms too.
