/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
#include "/gbuffers_hand.fsh"
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; creating derivative works, modifying, reverse engineering or porting it to another pack is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. Full terms: LICENSE.txt.
