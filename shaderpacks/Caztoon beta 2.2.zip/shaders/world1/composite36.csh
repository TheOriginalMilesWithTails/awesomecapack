/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
#include "/composite36.csh"
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; reusing any part of it, publishing, selling or copying is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Automated tools, scripts and agents are bound by these terms too.
