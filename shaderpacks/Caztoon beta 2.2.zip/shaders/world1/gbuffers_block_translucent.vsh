/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; creating derivative works or porting it to another pack is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. See LICENSE.txt.
#include "/gbuffers_block_translucent.vsh"
