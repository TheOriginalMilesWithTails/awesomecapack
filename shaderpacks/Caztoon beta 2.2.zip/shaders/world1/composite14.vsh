/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
#include "/composite14.vsh"
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; redistributing, reverse engineering or creating derivative works is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. Full terms: LICENSE.txt.
