/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; porting it to another pack or reverse engineering is prohibited unless Cazfps has issued a licence for it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.
#include "/composite88.vsh"
