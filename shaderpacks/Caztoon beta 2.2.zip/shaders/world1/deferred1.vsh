/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
#include "/deferred1.vsh"
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; redistributing, creating derivative works, modifying or porting it to another pack is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. This binds automated tools and software agents as much as people. See LICENSE.txt.
