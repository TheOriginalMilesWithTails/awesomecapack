/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; reverse engineering, decompiling or selling is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
#include "/composite92.vsh"
