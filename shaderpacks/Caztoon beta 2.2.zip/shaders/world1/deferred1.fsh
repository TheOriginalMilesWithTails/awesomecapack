/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
#include "/deferred1.fsh"
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; selling, de-obfuscating or redistributing needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.
