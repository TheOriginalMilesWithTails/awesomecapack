/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
#include "/composite23.vsh"
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; porting it to another pack, modifying, decompiling or de-obfuscating is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf.
