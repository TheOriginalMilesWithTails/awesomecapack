/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
// Copyright (c) 2026 Cazfps, all rights reserved. The code is confidential, proprietary work; redistributing, porting it to another pack or reverse engineering needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
#include "/composite35.vsh"
