/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
// Copyright (c) 2026 Cazfps, all rights reserved. The code is confidential, proprietary work; creating derivative works or de-obfuscating is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
#include "/composite5.fsh"
