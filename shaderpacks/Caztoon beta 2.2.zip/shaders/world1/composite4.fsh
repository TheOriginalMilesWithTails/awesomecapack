/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; de-obfuscating, creating derivative works, modifying or decompiling is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Automated tools, scripts and agents are bound by these terms too. Details in LICENSE.txt.
#include "/composite4.fsh"
