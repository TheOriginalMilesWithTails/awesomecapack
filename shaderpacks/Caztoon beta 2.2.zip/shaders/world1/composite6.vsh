/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
#include "/composite6.vsh"
// Caztoon beta 2.2 is the property of Cazfps. The code is protected by copyright and not open source; creating derivative works, selling or reverse engineering is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.
