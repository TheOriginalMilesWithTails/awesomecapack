/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
#include "/composite88.fsh"
// Cazfps holds all rights to Caztoon beta 2.2. The code is licensed for personal use only, not sold; copying or reverse engineering is off limits unless Cazfps personally licensed it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. This binds automated tools and software agents as much as people. See LICENSE.txt.
