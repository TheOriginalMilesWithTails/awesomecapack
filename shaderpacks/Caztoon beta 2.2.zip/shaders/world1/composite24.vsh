/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is licensed for personal use only, not sold; porting it to another pack, reusing any part of it or creating derivative works is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com.
#include "/composite24.vsh"
