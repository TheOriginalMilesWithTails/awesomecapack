/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
#include "/composite14.fsh"
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; copying or de-obfuscating needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Details in LICENSE.txt.
