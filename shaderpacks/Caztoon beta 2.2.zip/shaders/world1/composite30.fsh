/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
#include "/composite30.fsh"
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; decompiling, creating derivative works, reusing any part of it or modifying is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. No tool, script or agent is exempt from these terms. See LICENSE.txt.
