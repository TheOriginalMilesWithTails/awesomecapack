/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _gcga0yx 1
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; decompiling or creating derivative works is forbidden except under a licence granted by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
#include "/composite7.fsh"
