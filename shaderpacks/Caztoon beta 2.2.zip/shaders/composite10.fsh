#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; decompiling, modifying or creating derivative works is forbidden except under a licence granted by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Automated tools, scripts and agents are bound by these terms too.
#include "/rr9/wkfbmt14go.glsl"
#if defined(LITE_COLORTEX_BLOOM)
/* RENDERTARGETS: 24 */
/*
const int colortex24Format = RGBA16F;
const bool colortex24Clear = false;
*/
#define _2r9jej1 colortex23
#else
/* RENDERTARGETS: 0 */
#define _v7wrevx _fr08pcx(6)
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; decompiling, modifying or redistributing is prohibited unless Cazfps has issued a licence for it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf. Full terms: LICENSE.txt.
#define _sk60y37 _fr08pcx(7)
#endif
#define _vyf9bba 6
#define _e2nowq2 4.0
#define _a7u2n5j
#include "/rr9/fe0znvgg9h.glsl"
