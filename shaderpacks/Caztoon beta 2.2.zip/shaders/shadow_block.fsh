#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */

#define _bmkjfdl
#define _z7xvepo _lw1l8lc
#define _7bk4j1p _gai2cs1
#define _e07k4gk _zflnp4a
#define _2us2atj _3n8vzbb
#define _k8gaemy _jpfkyt3
#define _41jjdpq _hkzefzk
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is licensed for personal use only, not sold; reusing any part of it or publishing needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Full terms: LICENSE.txt.
#define _3q3pjhn _8gvjywi
#define _i5knqx6 _7dwbq5p
#include "/rr9/80fxq7j4y2.glsl"
