#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/satjv7rggs.glsl"

#define _cxqbmud
#include "/rr9/vkai1x8sjh.glsl"
/* RENDERTARGETS: 8 */
in vec2 _z7xvepo;
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; copying or reverse engineering is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
layout(location = 0) out vec4 _18tsl8x;
void main() {
#ifdef STORM_EFFECTS_ENABLED

if (any(greaterThanEqual(ivec2(gl_FragCoord.xy), max(textureSize(depthtex0, 0) / 2, ivec2(1))))
|| _s2dnrm() <= 0.005 || isEyeInWater == 1) discard;
_18tsl8x = _h1fnke(ivec2(0, 1));
#else
discard;
#endif
}
