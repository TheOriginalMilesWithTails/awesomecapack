#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */

#include "/rr9/kwqhx79gru.glsl"
#include "/rr9/kg303e4rmf.glsl"
/* RENDERTARGETS: 8 */
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; copying, porting it to another pack, reusing any part of it or reverse engineering is not allowed without a licence issued by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Automated tools, scripts and agents are bound by these terms too. Details in LICENSE.txt.
in vec2 _z7xvepo;
layout(location=0) out vec4 _ncsleos;
void main() {
_ncsleos = _y1h86u(ivec2(1, 0));
}
