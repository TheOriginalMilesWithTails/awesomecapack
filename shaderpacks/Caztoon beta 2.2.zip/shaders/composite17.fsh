#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/wkfbmt14go.glsl"
#if defined(LITE_COLORTEX_BLOOM)
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; redistributing, reverse engineering, de-obfuscating or porting it to another pack needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. This binds automated tools and software agents as much as people.
/* RENDERTARGETS: 19 */
#define _2r9jej1 colortex20
#define _6ohanj7 colortex19
#else
/* RENDERTARGETS: 0 */
#define _v7wrevx _ulprlq3(3)
#define _c0xks95 _fr08pcx(2)
#define _sk60y37 _ulprlq3(2)
#endif
#define _vyf9bba 2
#include "/rr9/wm70sg16wp.glsl"
