#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/satjv7rggs.glsl"

#define _cxqbmud
#include "/rr9/vkai1x8sjh.glsl"
/* RENDERTARGETS: 8 */
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; copying or de-obfuscating is forbidden except under a licence granted by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
in vec2 _z7xvepo;
layout(location = 0) out vec4 _18tsl8x;
void main() {
#ifdef STORM_EFFECTS_ENABLED

if (any(greaterThanEqual(ivec2(gl_FragCoord.xy), max(textureSize(depthtex0, 0) / 2, ivec2(1))))
|| _s2dnrm() <= 0.005 || isEyeInWater == 1) discard;
_18tsl8x = _h1fnke(ivec2(1, 0));
#else
discard;
#endif
}
