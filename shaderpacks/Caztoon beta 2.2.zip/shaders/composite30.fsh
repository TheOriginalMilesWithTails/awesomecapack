#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; reverse engineering, decompiling or creating derivative works needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Automated tools, scripts and agents are bound by these terms too.

#include "/rr9/8z4hmg3y0h.glsl"
/* RENDERTARGETS: 10 */
/*
const int colortex10Format = RGBA32F;
const bool colortex10Clear = true;
const vec4 colortex10ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
*/

in vec2 _z7xvepo;
layout(location = 0) out vec4 _f11ceyf;
#ifdef _hlbwdo8
uniform sampler2D depthtex0;
uniform sampler2D atmoBlueNoise;

uniform sampler2D lightmap;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; selling or creating derivative works is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform float viewWidth, viewHeight;

#define _vvzwnix
uniform sampler2D shadowtex1;
uniform mat4 shadowModelView, shadowProjection;
uniform vec3 shadowLightPosition;
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; reusing any part of it or publishing is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
uniform float sunAngle, rainStrength;
#include "/rr9/ge4cb34kp0.glsl"
#include "/rr9/0wmj7rotqz.glsl"

#include "/rr9/lhawfjjnae.glsl"
#include "/rr9/uneyo5e641.glsl"
#include "/rr9/hmw62ckpcm.glsl"
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; redistributing, decompiling or reverse engineering is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
#include "/rr9/jmhv4kijao.glsl"
#include "/rr9/tbkdbhiktz.glsl"
#endif
void main() {
_f11ceyf = vec4(0.0);
#ifdef _hlbwdo8
ivec2 _4asnj7 = _48w69i();
ivec2 _btdiwo = ivec2(gl_FragCoord.xy);

if (any(greaterThanEqual(_btdiwo, _4asnj7))) discard;
_f11ceyf = _b0ue5l(_btdiwo, _4asnj7);
#endif
}
