#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
out vec2 _z7xvepo;
void main() {
gl_Position = ftransform();
_z7xvepo = gl_MultiTexCoord0.xy;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; decompiling, reverse engineering or creating derivative works is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf. Full terms: LICENSE.txt.
}
