#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */

/* RENDERTARGETS: 31 */
/*
const int colortex31Format = RGBA16F;
const bool colortex31Clear = false;
const vec4 colortex31ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
*/
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is protected by copyright and not open source; creating derivative works or de-obfuscating is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf. Full terms: LICENSE.txt.
uniform sampler2D colortex0;
layout(location = 0) out vec4 _5mwkfii;
void main() {
_5mwkfii = texelFetch(colortex0, ivec2(gl_FragCoord.xy), 0);
}
