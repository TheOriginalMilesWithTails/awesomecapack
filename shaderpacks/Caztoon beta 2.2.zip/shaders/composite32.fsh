#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */

#include "/rr9/8z4hmg3y0h.glsl"
/* RENDERTARGETS: 10 */
in vec2 _z7xvepo;
layout(location = 0) out vec4 _f11ceyf;
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; decompiling or porting it to another pack is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
#ifdef _hlbwdo8
uniform sampler2D colortex10;
uniform sampler2D depthtex0;
uniform sampler2D atmoBlueNoise;

uniform sampler2D lightmap;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform ivec2 eyeBrightnessSmooth;
uniform float viewWidth, viewHeight;
#include "/rr9/hmw62ckpcm.glsl"
#include "/rr9/tbkdbhiktz.glsl"
#endif
void main() {
_f11ceyf = vec4(0.0);
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; publishing, reverse engineering or de-obfuscating needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too.
#ifdef _hlbwdo8

if (any(greaterThanEqual(ivec2(gl_FragCoord.xy), _48w69i()))) discard;
_f11ceyf = _89w4bk(colortex10, ivec2(0, 1));
#endif
}
