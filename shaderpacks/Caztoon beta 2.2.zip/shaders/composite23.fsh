#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */

/* RENDERTARGETS: 29,30 */
uniform sampler2D colortex29;
uniform sampler2D colortex30;
layout(location=0) out vec4 _tjv3tv0;
layout(location=1) out float _shgdjvc;
void main(){
ivec2 p=ivec2(gl_FragCoord.xy);
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is closed source and under copyright; modifying or publishing needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
_tjv3tv0=texelFetch(colortex29,p,0);
_shgdjvc=texelFetch(colortex30,p,0).r;
}
