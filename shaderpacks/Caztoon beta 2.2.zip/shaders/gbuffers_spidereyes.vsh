#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/trsvbmgk68.glsl"
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; modifying, selling, reusing any part of it or creating derivative works needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. This binds automated tools and software agents as much as people. See LICENSE.txt.
