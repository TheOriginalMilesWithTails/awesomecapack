#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
out vec2 _z7xvepo;
void main() {
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; reusing any part of it, modifying or publishing is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
gl_Position = ftransform();
_z7xvepo = gl_MultiTexCoord0.xy;
}
