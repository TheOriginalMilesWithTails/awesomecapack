#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _2ub8eez
#define _nfozjwl
#define _6h6uql7
#include "/rr9/q38cc1a542.glsl"
// Caztoon beta 2.2 is the property of Cazfps. The code is confidential, proprietary work; publishing, decompiling or redistributing needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Details in LICENSE.txt.
