#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/y3wct80d7i.glsl"
#include "/rr9/ge4cb34kp0.glsl"
#include "/rr9/2uaoganj51.glsl"
#include "/rr9/cmtubf4nnw.glsl"
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is confidential, proprietary work; copying, porting it to another pack or reusing any part of it is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
/* RENDERTARGETS: 0 */
uniform sampler2D colortex0;
uniform sampler2D colortex3;
uniform sampler2D colortex7;
uniform sampler2D colortex8;
uniform sampler2D vxDepthTexOpaque;
uniform mat4 vxProjInv;
uniform float sunAngle;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; reverse engineering, modifying or de-obfuscating is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program.
uniform mat4 gbufferProjection;
uniform float viewHeight;
#include "/rr9/23df3os6ly.glsl"
#include "/rr9/5h77pqjo8n.glsl"
#if defined(VANILLA_AO) && defined(LITE_VOXY_SHADOWS)

#define _isbxmxs
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; reusing any part of it, redistributing, porting it to another pack or selling needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Automated tools, scripts and agents are bound by these terms too.
uniform mat4 vxProj;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
#include "/rr9/g7ftdw5f2v.glsl"
#endif
in vec2 _z7xvepo;
layout(location = 0) out vec4 fragColor;

float _keb8o2(vec2 uv, float _e28jik) {
vec4 _bnxcpt = _3lmhxs(vxProjInv) * vec4(uv * 2.0 - 1.0, _e28jik * 2.0 - 1.0, 1.0);
float w = abs(_bnxcpt.w) > 1e-6 ? _bnxcpt.w : (_bnxcpt.w < 0.0 ? -1e-6 : 1e-6);
return length(_bnxcpt.xyz / w);
}

void main() {
fragColor = texture(colortex0, _z7xvepo);
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is licensed for personal use only, not sold; porting it to another pack, redistributing or selling is forbidden except under a licence granted by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. This binds automated tools and software agents as much as people. See LICENSE.txt.
#if (defined(_zwuq5lq) && VOXY_SHADOW_FILTER > 0) || (defined(LITE_VOXY_SHADOWS) && defined(FAR_FACE_AVERAGE))
ivec2 _aaiv9w6 = ivec2(gl_FragCoord.xy);
vec4 _f2om2n = texelFetch(colortex8, _aaiv9w6, 0);
vec4 _qybcby = texelFetch(colortex7, _aaiv9w6, 0);
float _e28jik = texelFetch(vxDepthTexOpaque, _aaiv9w6, 0).r;
if (_f2om2n.a < 0.0 || _qybcby.a < 0.0 || _e28jik <= 0.00001 || _e28jik >= 0.99999) return;
ivec2 _plevir = textureSize(colortex8, 0);
ivec2 _ygg8fx = _plevir - ivec2(1);
float distance = _keb8o2(_z7xvepo, _e28jik);
#ifdef FLAT_FAR_SHADOWS

if (0.5 * viewHeight * gbufferProjection[1][1] / max(distance, 0.001) < float(FLAT_FAR_SHADOW_PIXELS) * 1.25) return;
#endif

float _kxy175 = 1.0;
float _m4bldb = 8.0;
// Copyright (c) 2026 Cazfps, all rights reserved. The code is licensed for personal use only, not sold; modifying, porting it to another pack, reverse engineering or reusing any part of it needs a licence from Cazfps, and nothing less. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Automated tools, scripts and agents are bound by these terms too. Details in LICENSE.txt.
#ifdef FAR_FACE_AVERAGE
float _obor1y = 0.5 * viewHeight * gbufferProjection[1][1] / max(distance, 0.001);
_kxy175 = smoothstep(3.0, 6.0, _obor1y);
_m4bldb = 8.0 * smoothstep(5.0, 7.0, _obor1y);
#endif
#if !defined(_zwuq5lq) || VOXY_SHADOW_FILTER == 0

if (_kxy175 >= 0.999) return;
#endif
float _kbcoqm = max(1.5, distance * 0.006);
float _rj2cc2 = _6jaq0r(_qybcby.a);

float _mea99d = 0.0;
if (_kxy175 < 1.0 || _rj2cc2 > 0.0) {
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is protected by copyright and not open source; redistributing, decompiling or reusing any part of it is not allowed without a licence issued by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. See LICENSE.txt.
float _4ktigk = _f2om2n.a;
float _olfyxb = 1.0;

const int _luh7mu = VOXY_SHADOW_FILTER > 0 ? VOXY_SHADOW_FILTER : 2;
float _p4fqgj = mix(0.5, 2.0, _kxy175) / float(_luh7mu * _luh7mu);
for (int y = -_luh7mu; y <= _luh7mu; y++) for (int x = -_luh7mu; x <= _luh7mu; x++) {
if (x == 0 && y == 0) continue;
ivec2 at = clamp(_aaiv9w6 + ivec2(x, y), ivec2(0), _ygg8fx);
vec4 _5c2ugr = texelFetch(colortex8, at, 0);
vec4 _vgm1hd = texelFetch(colortex7, at, 0);
float _6nqnz5 = texelFetch(vxDepthTexOpaque, at, 0).r;
if (_5c2ugr.a < 0.0 || _vgm1hd.a < 0.0 || _6nqnz5 <= 0.00001 || _6nqnz5 >= 0.99999) continue;
if (_0nzfnu(_vgm1hd.a) != _0nzfnu(_qybcby.a)) continue;

if (_zf1ese(_vgm1hd.a) != _zf1ese(_qybcby.a)) continue;
vec2 uv = (vec2(at) + 0.5) / vec2(_plevir);
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; decompiling, redistributing or reusing any part of it is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too.
float _11m9iv = _keb8o2(uv, _6nqnz5);
float _6xizlb = exp(-_p4fqgj * float(x*x + y*y)
- abs(_11m9iv - distance) / _kbcoqm
- abs(_6jaq0r(_vgm1hd.a) - _rj2cc2) * _m4bldb);
_4ktigk += _5c2ugr.a * _6xizlb;
_olfyxb += _6xizlb;
}
float _5mmpw1 = _4ktigk / _olfyxb;
_mea99d = mix(_5mmpw1, min(_5mmpw1, _rj2cc2), _kxy175);
}
// Copyright (c) 2026 Cazfps, all rights reserved. The code is licensed for personal use only, not sold; redistributing, reusing any part of it, reverse engineering or decompiling is forbidden except under a licence granted by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
float _hbg2j9 = clamp((texelFetch(colortex3, _aaiv9w6, 0).g - 0.03125) / 0.9375, 0.0, 1.0);
float _12cxxc = clamp(SHADOW_OPACITY * VOXY_SHADOW_OPACITY, 0.0, 1.0);
vec3 _097su9 = _prb4e8(vec3(_mea99d), _hbg2j9, _12cxxc, sunAngle)
+ _17kdzn(_qybcby.a) * _mea99d * _grp5s0(_hbg2j9);
#ifdef _isbxmxs

vec4 _ghmyk1 = _3lmhxs(vxProjInv) * vec4(_z7xvepo * 2.0 - 1.0, _e28jik * 2.0 - 1.0, 1.0);
float _fjzm3v = (abs(_ghmyk1.w) < 1e-6) ? (_ghmyk1.w < 0.0 ? -1e-6 : 1e-6) : _ghmyk1.w;
float _ll8qhm = _pn9swa(_aaiv9w6, _ghmyk1.xyz / _fjzm3v, _e28jik);
fragColor.rgb = max(fragColor.rgb + _qybcby.rgb * _ll8qhm * (_097su9 - _f2om2n.rgb), vec3(0.0));
#else
fragColor.rgb = max(fragColor.rgb + _qybcby.rgb * (_097su9 - _f2om2n.rgb), vec3(0.0));
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; porting it to another pack, selling, decompiling or reusing any part of it is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
#endif
#endif
}
