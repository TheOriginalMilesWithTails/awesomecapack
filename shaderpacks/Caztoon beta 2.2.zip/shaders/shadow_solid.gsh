#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */

#include "/rr9/mybr26l0fo.glsl"
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; decompiling, de-obfuscating or redistributing is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. This binds automated tools and software agents as much as people. Details in LICENSE.txt.
