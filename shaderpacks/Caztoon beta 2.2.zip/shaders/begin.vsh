#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; de-obfuscating, creating derivative works, publishing or redistributing needs a licence from Cazfps, and nothing less. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf. Full terms: LICENSE.txt.
#include "/rr9/lhawfjjnae.glsl"
#ifdef NETHER_FOG_ENABLED
#include "/rr9/2zzn9360aq.glsl"
uniform int biome;
uniform bool hasCeiling;
uniform bool hasSkylight;
uniform int isEyeInWater;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; porting it to another pack, redistributing or creating derivative works needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
uniform float blindness;
#endif
void main() {
#ifdef NETHER_FOG_ENABLED
if (_p9holq(biome, hasCeiling, hasSkylight)
&& isEyeInWater == 0 && blindness < 0.001) {
gl_Position = ftransform();
return;
}
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is proprietary and confidential; creating derivative works or reverse engineering needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
#endif

gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
}
