#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; reusing any part of it or porting it to another pack is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too.
#include "/rr9/wkfbmt14go.glsl"
#if defined(LITE_COLORTEX_BLOOM)
/* RENDERTARGETS: 22 */
/*
const int colortex22Format = RGBA16F;
const bool colortex22Clear = false;
*/
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; redistributing, creating derivative works or selling needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.
#define _2r9jej1 colortex21
#else
/* RENDERTARGETS: 0 */
#define _v7wrevx _fr08pcx(4)
#define _sk60y37 _fr08pcx(5)
#endif
#define _vyf9bba 4
#define _e2nowq2 1.0
#include "/rr9/fe0znvgg9h.glsl"
