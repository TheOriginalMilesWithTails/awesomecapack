#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
out vec2 _z7xvepo;
void main() {
gl_Position = ftransform();
_z7xvepo = gl_MultiTexCoord0.xy;
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; modifying, redistributing, de-obfuscating or porting it to another pack is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. The same terms bind any software acting on a person's behalf.
}
