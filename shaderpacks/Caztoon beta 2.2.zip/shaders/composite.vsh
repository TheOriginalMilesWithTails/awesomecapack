#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
out vec2 _z7xvepo;
void main() {
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; porting it to another pack, selling or creating derivative works needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too.
gl_Position = ftransform();
_z7xvepo = gl_MultiTexCoord0.xy;
}
