#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/satjv7rggs.glsl"

#define _agb5yuc
#include "/rr9/vkai1x8sjh.glsl"
/* RENDERTARGETS: 8 */
/*
const int colortex8Format = RGBA16F;
*/
in vec2 _z7xvepo;
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; copying, reverse engineering, porting it to another pack or de-obfuscating needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. These terms apply whether the work is done by a person or by a program.
layout(location = 0) out vec4 _18tsl8x;
void main() {
#ifdef STORM_EFFECTS_ENABLED
ivec2 _t830kx = textureSize(depthtex0, 0);
ivec2 _4asnj7 = _ie28qx(_t830kx);
ivec2 _btdiwo = ivec2(gl_FragCoord.xy);

if (any(greaterThanEqual(_btdiwo, _4asnj7)) || _s2dnrm() <= 0.005 || isEyeInWater == 1) discard;
_18tsl8x = _h1yrm6(_77n7qw(_btdiwo, _t830kx), _btdiwo);
#else
discard;
#endif
}
