#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
out vec2 _z7xvepo;
void main() {
gl_Position = ftransform();
// Caztoon beta 2.2 is the property of Cazfps. The code is confidential, proprietary work; de-obfuscating or copying is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
_z7xvepo = gl_MultiTexCoord0.xy;
}
