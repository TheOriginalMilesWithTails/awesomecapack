#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is confidential, proprietary work; reusing any part of it, selling, reverse engineering or porting it to another pack is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. See LICENSE.txt.
#include "/rr9/satjv7rggs.glsl"
#include "/rr9/wkfbmt14go.glsl"

#include "/rr9/9ss4spypuj.glsl"
/* RENDERTARGETS: 8 */
/*
const int colortex8Format = RGBA16F;
*/
in vec2 _z7xvepo;
layout(location=0) out vec4 _ayktzui;
void main() {
_ayktzui = _l0glml(_z7xvepo, true);
}
