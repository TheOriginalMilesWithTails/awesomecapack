#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */

out vec2 _z7xvepo;

void main() {
gl_Position = ftransform();
_z7xvepo = gl_MultiTexCoord0.xy;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is proprietary and confidential; reusing any part of it, redistributing or publishing is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
}
