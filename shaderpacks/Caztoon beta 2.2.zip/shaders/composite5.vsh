#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; decompiling, copying, porting it to another pack or de-obfuscating is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. See LICENSE.txt.
out vec2 _z7xvepo;
void main() {
gl_Position = ftransform();
_z7xvepo = gl_MultiTexCoord0.xy;
}
