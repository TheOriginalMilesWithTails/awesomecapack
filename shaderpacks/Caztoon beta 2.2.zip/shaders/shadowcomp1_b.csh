#version 430
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */

#define _phvjexg
#define _8tsdl7f
#include "/rr9/ge4cb34kp0.glsl"
#include "/rr9/36vu26ovz4.glsl"
layout(local_size_x = 64) in;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; selling, reverse engineering, modifying or publishing needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.

const ivec3 workGroups = ivec3(8188, 1, 1);

void main() {
#ifdef _2afvqz3
uint _htbumg = gl_GlobalInvocationID.x;
if (_htbumg < _xvfwnz()) _0oeb1p(_htbumg);
#endif
}
