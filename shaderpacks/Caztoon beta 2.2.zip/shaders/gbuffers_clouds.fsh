#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/uneyo5e641.glsl"
#ifdef _65jbzyx
/* RENDERTARGETS: 0 */
layout(location=0) out vec4 fragColor;
void main() { discard; }
#else

#define _6h6uql7
#define _x4669um
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; de-obfuscating, decompiling, porting it to another pack or publishing is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. Automated tools, scripts and agents are bound by these terms too. Details in LICENSE.txt.
#define _nfozjwl
#include "/rr9/q38cc1a542.glsl"

#endif
