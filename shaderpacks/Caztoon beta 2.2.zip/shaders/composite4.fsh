#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/wkfbmt14go.glsl"
#if defined(LITE_COLORTEX_BLOOM)
/* RENDERTARGETS: 18 */
/*
const int colortex18Format = RGBA16F;
const bool colortex18Clear = false;
*/
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; de-obfuscating, copying, decompiling or publishing is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none.
#define _2r9jej1 colortex17
#else
/* RENDERTARGETS: 0 */
#define _v7wrevx _fr08pcx(0)
#define _sk60y37 _fr08pcx(1)
#endif
#define _vyf9bba 0
#define _e2nowq2 1.0
#include "/rr9/fe0znvgg9h.glsl"
