#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; decompiling or reverse engineering is off limits unless Cazfps personally licensed it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf.

#include "/rr9/68lws4ad5n.glsl"
