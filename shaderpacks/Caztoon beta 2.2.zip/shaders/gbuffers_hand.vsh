#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; decompiling, de-obfuscating, publishing or porting it to another pack is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
#include "/rr9/trsvbmgk68.glsl"
