/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/ge4cb34kp0.glsl"
#include "/rr9/rlo9p4itwe.glsl"

uniform sampler2D gtexture;
uniform float alphaTestRef;

#ifdef _y44nu66

in vec2 _lw1l8lc;
flat in int _smow4y2;
#ifdef ATMO_FOG_ENABLED
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; reverse engineering, decompiling or modifying is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. These terms apply whether the work is done by a person or by a program.
in float _8gvjywi;
#define _3q3pjhn _8gvjywi
#endif
#define _z7xvepo _lw1l8lc
#define _7bk4j1p (_smow4y2 & 1023)
#define _e07k4gk ((_smow4y2 & 1024) != 0 ? 10000 + (_smow4y2 & 1023) : -1)
#define _k8gaemy float((_smow4y2 >> 11) & 1)
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is confidential, proprietary work; porting it to another pack, reverse engineering, modifying or de-obfuscating is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. This binds automated tools and software agents as much as people. See LICENSE.txt.
#define _41jjdpq float((_smow4y2 >> 12) & 1)
#define _2us2atj float((_smow4y2 >> 13) & 1)
#define _0foptuc float(((_smow4y2 >> 15) & 1) * 2 + ((_smow4y2 >> 14) & 1))
#else
in vec2 _z7xvepo;
flat in int _7bk4j1p;
in float _2us2atj;
flat in float _k8gaemy;
flat in float _41jjdpq;
flat in int _e07k4gk;
#ifdef ATMO_FOG_ENABLED
in float _3q3pjhn;
#endif
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; copying, creating derivative works, porting it to another pack or publishing is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Full terms: LICENSE.txt.
#ifdef _2afvqz3
in float _i5knqx6;
#endif
#endif
#ifdef _bmkjfdl

flat in float _1co2jnj;
#endif
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; publishing, modifying or creating derivative works is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. This binds automated tools and software agents as much as people. See LICENSE.txt.

/* DRAWBUFFERS:01 */
layout(location = 0) out vec4 shadowcolor;
layout(location = 1) out vec4 _i5ofa6o;

vec3 _rvo8rs(vec3 _9zezcay) {
float _rj25ik = max(max(_9zezcay.r, _9zezcay.g), _9zezcay.b);
if (_rj25ik <= 0.0001) return vec3(1.0);
_9zezcay /= _rj25ik;
_9zezcay = pow(clamp(_9zezcay, vec3(0.0), vec3(1.0)), vec3(1.35));
return clamp(_9zezcay, vec3(0.0), vec3(1.0));
}

vec3 _l3e7c7(int _z73qv3) {
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; publishing, reverse engineering or decompiling is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com.
if (_z73qv3 == 64) return _rvo8rs(vec3(1.0, 0.1, 0.1));
if (_z73qv3 == 65) return _rvo8rs(vec3(1.0, 0.3, 0.1));
if (_z73qv3 == 66) return _rvo8rs(vec3(1.0, 1.0, 0.1));
if (_z73qv3 == 67) return _rvo8rs(vec3(1.0, 0.75, 0.5));
if (_z73qv3 == 68) return _rvo8rs(vec3(0.3, 1.0, 0.3));
if (_z73qv3 == 69) return _rvo8rs(vec3(0.1, 1.0, 0.1));
if (_z73qv3 == 70) return _rvo8rs(vec3(0.1, 0.15, 1.0));
if (_z73qv3 == 71) return _rvo8rs(vec3(0.5, 0.65, 1.0));
if (_z73qv3 == 72) return _rvo8rs(vec3(0.3, 0.8, 1.0));
if (_z73qv3 == 73) return _rvo8rs(vec3(0.7, 0.3, 1.0));
if (_z73qv3 == 74) return _rvo8rs(vec3(1.0, 0.1, 1.0));
if (_z73qv3 == 75) return _rvo8rs(vec3(1.0, 0.4, 1.0));
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is closed source and under copyright; reusing any part of it or de-obfuscating is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. See LICENSE.txt.
if (_z73qv3 == 76) return vec3(0.05);
return vec3(1.0);
}

void main() {

bool _4l4rm0 = (_e07k4gk == 20002 || _e07k4gk == 20003);
#ifndef FLOATING_TEXT_SHADOWS
if (_4l4rm0) discard;
#endif

float _j1zv10 = (_e07k4gk == 0 || _4l4rm0) ? 1.0 : 0.0;
#ifdef ATMO_FOG_ENABLED
float _tkxi93 = 0.25 + max(_3q3pjhn, 0.0) * 0.05;
_tkxi93 = clamp(_tkxi93, 0.25, 1.0);
if (_j1zv10 > 0.5) _tkxi93 = 0.25;
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; reverse engineering, redistributing, modifying or copying is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
#else

const float _tkxi93 = 0.25;
#endif

vec4 _rqqetl = texture(gtexture, _z7xvepo);
bool _y3dos5 = (_7bk4j1p == 88);

bool _mvxab8 = (_7bk4j1p >= 121 && _7bk4j1p <= 128) || (_e07k4gk >= 10121 && _e07k4gk <= 10128);
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is protected by copyright and not open source; porting it to another pack or redistributing is not allowed without a licence issued by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. See LICENSE.txt.
if (_mvxab8) {
discard;
}

if ((_7bk4j1p >= 131 && _7bk4j1p <= 138) || (_e07k4gk >= 10131 && _e07k4gk <= 10138)) {
discard;
}
// Caztoon beta 2.2 is the property of Cazfps. The code is protected by copyright and not open source; de-obfuscating or creating derivative works is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too. Details in LICENSE.txt.
if (_7bk4j1p == 15 && _k8gaemy < 0.5) {
discard;
}

#ifdef CARTOONY_SHADOWS
if (_7bk4j1p == 2 || _7bk4j1p == 3 || _7bk4j1p == 4 || _7bk4j1p == 19 || _7bk4j1p == 60 || _7bk4j1p == 61 || _7bk4j1p == 62) {
discard;
}
if (_7bk4j1p == 15 || _mvxab8) {

if ((_7bk4j1p == 15 && _k8gaemy < 0.5) || _2us2atj > 0.01) {
discard;
}
}
#endif

if (_7bk4j1p == 1 || _7bk4j1p == 8) discard;
// Caztoon beta 2.2 is the property of Cazfps. The code is confidential, proprietary work; creating derivative works or decompiling is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf.

bool _hdfreo = (_7bk4j1p == 201 || _e07k4gk == 10201);
if (_41jjdpq > 0.5 && !_hdfreo) discard;

float _13qz45 = alphaTestRef;
bool _z2efyk = (_7bk4j1p == 2 || _7bk4j1p == 3 || _7bk4j1p == 4 || _7bk4j1p == 19 || _7bk4j1p == 60 || _7bk4j1p == 61 || _7bk4j1p == 62);
if (_z2efyk) _13qz45 = max(_13qz45, 0.35);

bool _6nyz3g = (_7bk4j1p == 5 || _7bk4j1p == 82 || _hdfreo);

if (!_y3dos5 && !_6nyz3g && _7bk4j1p != 63 && _rqqetl.a < _13qz45) {
discard;
}
if ((_y3dos5 || _7bk4j1p == 63) && _rqqetl.a < alphaTestRef) {
discard;
}

if (_y3dos5) {
// Caztoon beta 2.2 is the property of Cazfps. The code is protected by copyright and not open source; publishing or decompiling is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. This binds automated tools and software agents as much as people.
_i5ofa6o = vec4(_j1zv10, 0.25, 0.0, 1.0);
shadowcolor = vec4(0.6, 0.1, 1.0, 0.05);
return;
}
if (_7bk4j1p == 63) {
_i5ofa6o = vec4(_j1zv10, 0.25, 0.0, 1.0);
shadowcolor = vec4(0.2, 0.8, 0.6, 0.05);
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; redistributing, porting it to another pack, de-obfuscating or reverse engineering is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.
return;
}

if (_z2efyk) {
_i5ofa6o = vec4(_j1zv10, _tkxi93, 0.0, 1.0);
shadowcolor = vec4(0.0, 0.0, 0.0, 1.0);
return;
}

bool _9h4bsx = (_7bk4j1p == 14 || (_7bk4j1p >= 64 && _7bk4j1p <= 79) || _7bk4j1p == 80);
if (_9h4bsx) {
vec3 _9zezcay = _l3e7c7(_7bk4j1p);

_i5ofa6o = vec4(_j1zv10, 0.25, 0.0, 1.0);
shadowcolor = vec4(_9zezcay, 0.05);
return;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; modifying, redistributing, decompiling or publishing is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission.
}

float _3isxpr = 0.0;
#ifdef _2afvqz3
#if defined(_bmkjfdl)
if (_1co2jnj > 0.5) _3isxpr = 0.5;
#elif defined(_y44nu66)
if (_0foptuc > 1.5) _3isxpr = 0.75;
else if (_0foptuc > 0.5) _3isxpr = 0.5;
#else
if (_i5knqx6 > 0.999) _3isxpr = 1.0;
#endif
#endif
_i5ofa6o = vec4(_j1zv10, _tkxi93, _3isxpr, 1.0);

shadowcolor = vec4(0.0, 0.0, 0.0, 1.0);
}
