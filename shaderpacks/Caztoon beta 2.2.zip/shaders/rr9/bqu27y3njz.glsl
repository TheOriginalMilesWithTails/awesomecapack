/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _ar3tbx7
#define _ar3tbx7

vec3 _wtkqdh(vec3 _rqqetl, vec3 _oumc5c, vec2 _btdiwo) {
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; decompiling, copying or redistributing is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf. See LICENSE.txt.

float _yunvja = fract(52.9829189 * fract(dot(_btdiwo, vec2(0.06711056, 0.00583715))));

vec3 _6xizlb = clamp(_oumc5c * 255.0, vec3(0.0), vec3(1.0));
_6xizlb *= clamp((vec3(1.0) - _rqqetl) * 255.0, vec3(0.0), vec3(1.0));
return _rqqetl + (_yunvja - 0.5) * (1.0 / 255.0) * _6xizlb;
}

#endif
