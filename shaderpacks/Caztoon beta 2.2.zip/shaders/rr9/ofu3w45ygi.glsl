/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _iwc4u0q
#define _iwc4u0q

#ifndef _9tbngxa
uniform sampler3D caztoonRgbVolume;
uniform vec3 caztoonRgbOrigin;
uniform vec3 caztoonRgbCameraRelative;
uniform int caztoonRgbEnabled;
#endif

#include "/rr9/3mdxrcn3xk.glsl"
// Copyright (c) 2026 Cazfps, all rights reserved. The code is confidential, proprietary work; modifying, porting it to another pack or redistributing needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.

vec3 _7d2u1u(vec3 _bj0n2v, float _vjlxsy, vec3 _hv8c1i) {
#if !defined(_r848rce) || defined(_9tbngxa)
return _bj0n2v;
#else
if (caztoonRgbEnabled == 0)
return _8wngh6(_bj0n2v, _vjlxsy, _hv8c1i);

vec3 _qqn63q = _hv8c1i + caztoonRgbCameraRelative;
if (any(lessThan(_qqn63q, vec3(0.0))) || any(greaterThanEqual(_qqn63q, vec3(128.0))))
return _8wngh6(_bj0n2v, _vjlxsy, _hv8c1i);
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; redistributing, reverse engineering, publishing or porting it to another pack is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.

vec3 _hv4t4u = mod(_qqn63q + caztoonRgbOrigin, vec3(128.0));
vec4 _hmv02m = texture(caztoonRgbVolume, _hv4t4u * (1.0 / 128.0));
if (!_hff3it(_hmv02m))
return _8wngh6(_bj0n2v, _vjlxsy, _hv8c1i);

float _ticp8b = min(min(_qqn63q.x, _qqn63q.y), _qqn63q.z);
_ticp8b = min(_ticp8b, min(min(128.0 - _qqn63q.x, 128.0 - _qqn63q.y), 128.0 - _qqn63q.z));
float _v0mnpt = clamp(_hmv02m.a * 15.0, 0.0, 1.0) * smoothstep(0.0, 3.0, _ticp8b);
vec3 _uw7j83 = _8o24hb(_bj0n2v, _vjlxsy, _hmv02m);
if (_v0mnpt >= 0.999) return _uw7j83;
return mix(_8wngh6(_bj0n2v, _vjlxsy, _hv8c1i), _uw7j83, _v0mnpt);
#endif
}

#include "/rr9/hmw62ckpcm.glsl"

#endif
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; reusing any part of it or reverse engineering needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission.
