/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _9eqwh4p
#define _9eqwh4p

#include "/rr9/4gvldx3cjs.glsl"
#include "/rr9/61jwotib2p.glsl"

#if !defined(_9tbngxa) && !defined(GHIBLI_SHADOW_SAMPLERS_DECLARED)
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; modifying, de-obfuscating, selling or reverse engineering is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. Details in LICENSE.txt.
uniform sampler2D colortex13;
uniform sampler2D colortex5;
#endif

float _dms1t6(vec3 _g4yzf4, vec2 _qfbgoe, bool _gd2f45, out float _6xizlb) {
_6xizlb = 0.0;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; decompiling, reverse engineering or creating derivative works is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
if (textureSize(colortex5, 0).x < _dblklr + _quhwla) return 1.0;
if (texelFetch(colortex5, ivec2(1, 1), 0).r != _000dji) return 1.0;
vec2 _cohh6o = texelFetch(colortex5, ivec2(0, 1), 0).rg;
vec2 _5da0zu = _g4yzf4.xz + _qfbgoe * (_f4brmo - _g4yzf4.y);
float _ap48w5 = 0.5 * float(_quhwla);
vec2 _hdstkf = (_5da0zu - _cohh6o) / _6l6qx5 + _ap48w5 - 0.5;
vec2 _5lqcc9 = abs(_hdstkf - (_ap48w5 - 0.5));
_6xizlb = 1.0 - smoothstep(_ap48w5 * 0.80, _ap48w5 * 0.95, max(_5lqcc9.x, _5lqcc9.y));
if (_6xizlb <= 0.0) return 1.0;
ivec2 _3tojq5 = ivec2(floor(_hdstkf));
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; selling or de-obfuscating is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Full terms: LICENSE.txt.
vec2 _wlwnwo = fract(_hdstkf);
float _bk54v9 = 0.0;
for (int i = 0; i < 4; i++) {
ivec2 _848w36 = ivec2(i & 1, i >> 1);
ivec2 _q5xtgy = clamp(_3tojq5 + _848w36, ivec2(0), ivec2(_quhwla - 1));
vec3 _a8mxcz = texelFetch(colortex5, ivec2(_dblklr, 0) + _q5xtgy, 0).rgb;
vec2 _qrxges = mix(1.0 - _wlwnwo, _wlwnwo, vec2(_848w36));
bool _e9xlxk = !_gd2f45 && _a8mxcz.r > 0.5 * _lub52k && _g4yzf4.y > _a8mxcz.r;
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; reusing any part of it or copying is forbidden except under a licence granted by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. No tool, script or agent is exempt from these terms. See LICENSE.txt.
float _223oo7 = clamp(_a8mxcz.g, 0.0, 1.0);
if (_gd2f45) {
float _kchvsh = clamp((_a8mxcz.b - _g4yzf4.y) / 12.0, 0.0, 1.0);
_223oo7 *= _kchvsh * _kchvsh * (3.0 - 2.0 * _kchvsh);
}
_bk54v9 += (_e9xlxk ? 1.0 : _223oo7) * _qrxges.x * _qrxges.y;
}
return _bk54v9;
}

vec4 _81xjmz(ivec2 _q5xtgy, int _848w36, int _iq6b4j) {
ivec2 _l56nt5 = clamp(_q5xtgy, ivec2(0), ivec2(_iq6b4j - 1));
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; decompiling, creating derivative works or porting it to another pack needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission. Full terms: LICENSE.txt.
_l56nt5.x += _848w36;
return texelFetch(colortex13, _l56nt5, 0);
}

vec4 _ffwrzf(ivec2 _q5xtgy, int _r8rsb8, int _iq6b4j) {
return _81xjmz(_q5xtgy, _r8rsb8 * _iq6b4j, _iq6b4j);
}

vec4 _frw37z(vec2 _hdstkf, int _848w36, int _iq6b4j) {
#ifndef _9tbngxa

vec2 _ur693a = clamp(_hdstkf + 0.5, vec2(0.5), vec2(float(_iq6b4j) - 0.5));
return textureLod(colortex13, (_ur693a + vec2(float(_848w36), 0.0)) / vec2(textureSize(colortex13, 0)), 0.0);
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; reverse engineering or decompiling is prohibited unless Cazfps has issued a licence for it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.
#endif
ivec2 _3tojq5 = ivec2(floor(_hdstkf));
vec2 _wlwnwo = fract(_hdstkf);
return mix(
mix(_81xjmz(_3tojq5, _848w36, _iq6b4j),
_81xjmz(_3tojq5 + ivec2(1, 0), _848w36, _iq6b4j), _wlwnwo.x),
mix(_81xjmz(_3tojq5 + ivec2(0, 1), _848w36, _iq6b4j),
_81xjmz(_3tojq5 + ivec2(1, 1), _848w36, _iq6b4j), _wlwnwo.x), _wlwnwo.y);
}

vec4 _f8r0un(vec2 _hdstkf, int _r8rsb8, int _iq6b4j) {
return _frw37z(_hdstkf, _r8rsb8 * _iq6b4j, _iq6b4j);
}

float _n9439f(vec3 _g4yzf4, vec3 _kqfu4h, out float _kozpav) {
_kozpav = 0.0;
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; redistributing, reverse engineering, porting it to another pack or modifying is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. No tool, script or agent is exempt from these terms. See LICENSE.txt.
int _iq6b4j = _5to4ub(textureSize(colortex13, 0));
if (_iq6b4j < 2 || textureSize(colortex5, 0).x < 2) return 0.0;
#ifdef GHIBLI_CLOUD_ATMO_PASS

#ifndef CLOUD_SHADOWS_ENABLED
return 0.0;
#endif
if (hasCeiling && !hasSkylight) return 0.0;
vec4 _9ywfqzn = vec4(_eqno2h(cameraPosition,
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; selling, reusing any part of it, porting it to another pack or publishing is off limits unless Cazfps personally licensed it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
2.0 * (_7p3idm() + 32.0) / float(_iq6b4j)), _sbd9hv);
#else
vec4 _9ywfqzn = vec4(texelFetch(colortex5, ivec2(0, 0), 0).rg,
texelFetch(colortex5, ivec2(1, 0), 0).rg);
if (_9ywfqzn.w != _sbd9hv || any(isnan(_9ywfqzn)) || any(isinf(_9ywfqzn))) return 0.0;
#endif
vec2 _mzin7x = _5fne31();
if (_g4yzf4.y >= _mzin7x.y) return 0.0;

float _u14urc = _7p3idm();
vec3 _qvawoh = _g4yzf4 - _9ywfqzn.xyz;
float distance = length(_qvawoh);
if (distance >= _u14urc) return 0.0;

float _rvv5zj = _ef0dp3(_g4yzf4.y);
int _ds8zbm = int(floor(_rvv5zj));
int _m8ndyl = min(_ds8zbm + 1, _of5kzd - 1);

vec2 _qfbgoe = _gqjkt6(_kqfu4h);
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is confidential, proprietary work; creating derivative works or copying is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. The same terms bind any software acting on a person's behalf.
float _3xpbhf = float(_iq6b4j) / (2.0 * (_u14urc + 32.0));
vec2 _2mhspk = vec2(0.5 * float(_iq6b4j) - 0.5);
vec2 _g0ic8r = (_qvawoh.xz + _qfbgoe * (_drlc5r(_ds8zbm) - _g4yzf4.y))
* _3xpbhf + _2mhspk;
vec2 _qi7emd = (_qvawoh.xz + _qfbgoe * (_drlc5r(_m8ndyl) - _g4yzf4.y))
* _3xpbhf + _2mhspk;
float _4k3jb6 = _f8r0un(_g0ic8r, _ds8zbm / 4, _iq6b4j)[_ds8zbm % 4];
float _49wde3 = _f8r0un(_qi7emd, _m8ndyl / 4, _iq6b4j)[_m8ndyl % 4];
float _hgne8hx = mix(_4k3jb6, _49wde3, fract(_rvv5zj));

int _hzxiyx = _4mir5z(textureSize(colortex13, 0), _iq6b4j);
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; decompiling or selling is not allowed without a licence issued by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Details in LICENSE.txt.
float _wt3u70 = _jc9z0l();
if (_hzxiyx > 0 && _wt3u70 > 0.0) {
vec3 _g632fo = _g4yzf4 - _eqno2h(cameraPosition, _8x7w6m);
vec2 _zvupqd = _g632fo.xz + _qfbgoe * (_drlc5r(_ds8zbm) - _g4yzf4.y);
vec2 _etuzrz = _g632fo.xz + _qfbgoe * (_drlc5r(_m8ndyl) - _g4yzf4.y);
float _nhuh6n = _3wykmn(_hzxiyx);
vec2 _e1x103 = max(abs(_zvupqd), abs(_etuzrz));
float _n4yqwc = _wt3u70 * (1.0 - smoothstep(_nhuh6n * 0.75, _nhuh6n * 0.95, max(_e1x103.x, _e1x103.y)));
if (_n4yqwc > 0.0) {
vec2 _t3wcl1 = vec2(0.5 * float(_hzxiyx) - 0.5);
float _nrzzlo = _frw37z(_zvupqd / _8x7w6m + _t3wcl1,
2 * _iq6b4j + (_ds8zbm / 4) * _hzxiyx, _hzxiyx)[_ds8zbm % 4];
float _robnqm = _frw37z(_etuzrz / _8x7w6m + _t3wcl1,
2 * _iq6b4j + (_m8ndyl / 4) * _hzxiyx, _hzxiyx)[_m8ndyl % 4];
_hgne8hx = mix(_hgne8hx, mix(_nrzzlo, _robnqm, fract(_rvv5zj)), _n4yqwc);
}
}
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; copying, porting it to another pack or decompiling is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.

#ifndef _7ai8vnx
float _c8949q = _736smo();
if (_c8949q > 0.0) {
float _f6404t;
float _liseuk = _dms1t6(_g4yzf4, _qfbgoe, false, _f6404t);
if (_f6404t > 0.0)
_hgne8hx = mix(_hgne8hx, (1.0 - _liseuk) * texelFetch(colortex5, ivec2(1, 1), 0).g, _f6404t * _c8949q);
}
#endif
float _mea99d = 1.0 - smoothstep(_u14urc * 0.80, _u14urc, distance);
_kozpav = _mea99d;
return clamp(_hgne8hx, 0.0, 1.0) * _mea99d;
}

float _n9439f(vec3 _g4yzf4, vec3 _kqfu4h) {
float _kozpav;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; modifying, reverse engineering or copying is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. See LICENSE.txt.
return _n9439f(_g4yzf4, _kqfu4h, _kozpav);
}

#endif
