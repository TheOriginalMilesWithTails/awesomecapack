/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _ueups1h
#define _ueups1h

#include "/rr9/ge4cb34kp0.glsl"
#include "/rr9/uneyo5e641.glsl"

#if defined(HAZE_FOG_SHADOWS_ENABLED) && defined(SHADOWS_ENABLED) && defined(HAZE_FOG_ENABLED) \
&& !defined(_gcga0yx) && !defined(NETHER_SHADER)
#define _gorz9q1
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; redistributing, reusing any part of it or selling is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. Full terms: LICENSE.txt.

#ifdef _0ozv2nc

#include "/rr9/0wmj7rotqz.glsl"

#include "/rr9/c4rzdcl7kk.glsl"
#include "/rr9/r7il6oksnm.glsl"

#if defined(CLOUDS_GHIBLI_ENABLED) && defined(CLOUD_SHADOWS_ENABLED)
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; selling, copying, modifying or reverse engineering needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms.
#if GHIBLI_CLOUD_PERF_MODE != 3
#define _z60fn2f
#include "/rr9/jmhv4kijao.glsl"
#endif
#endif

float _dif1n3(sampler2D _m9uc7e, vec2 uv, float _fby3bi, float _lm7bdx) {
vec2 _wlwnwo = fract(uv * vec2(textureSize(_m9uc7e, 0)) - 0.5);
ivec2 _plevir = textureSize(_m9uc7e, 0);
ivec2 _3tojq5 = ivec2(floor(uv * vec2(_plevir) - 0.5));
ivec2 _itarm6 = _plevir - ivec2(1);
vec4 _uaihtq = vec4(
texelFetch(_m9uc7e, clamp(_3tojq5 + ivec2(0, 1), ivec2(0), _itarm6), 0).r,
texelFetch(_m9uc7e, clamp(_3tojq5 + ivec2(1, 1), ivec2(0), _itarm6), 0).r,
texelFetch(_m9uc7e, clamp(_3tojq5 + ivec2(1, 0), ivec2(0), _itarm6), 0).r,
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is proprietary and confidential; redistributing or reusing any part of it needs a licence from Cazfps, and nothing less. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. This binds automated tools and software agents as much as people. Details in LICENSE.txt.
texelFetch(_m9uc7e, clamp(_3tojq5, ivec2(0), _itarm6), 0).r);
vec4 _mea99d = clamp((_uaihtq - _fby3bi) / max(_lm7bdx, 1.0 / 65536.0) + 0.5, 0.0, 1.0);

return mix(mix(_mea99d.w, _mea99d.z, _wlwnwo.x),
mix(_mea99d.x, _mea99d.y, _wlwnwo.x), _wlwnwo.y);
}
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; reusing any part of it or reverse engineering is prohibited unless Cazfps has issued a licence for it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.

float _82t7ls(vec4 _pje07k, float _lm7bdx) {
if (any(isnan(_pje07k)) || any(isinf(_pje07k)) || abs(_pje07k.w) < 1e-6) return 1.0;
vec3 screen = _n0grq3(_pje07k.xyz / _pje07k.w) * 0.5 + 0.5;
if (any(isnan(screen)) || any(isinf(screen))
|| any(lessThanEqual(screen, vec3(0.0)))
|| any(greaterThanEqual(screen, vec3(1.0)))) return 1.0;

vec2 _ticp8b = min(screen.xy, 1.0 - screen.xy);
float _a78all = smoothstep(0.0, 0.05, min(_ticp8b.x, _ticp8b.y))
* smoothstep(0.0, 0.02, screen.z)
* (1.0 - smoothstep(0.98, 1.0, screen.z));
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; de-obfuscating or reusing any part of it is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
if (_a78all <= 0.0) return 1.0;

float _fq5n7f = _dif1n3(shadowtex0, screen.xy, screen.z, _lm7bdx);
float _mea99d = _fq5n7f;
if (_fq5n7f < 0.9999) {
float _8o2ppi = _dif1n3(shadowtex1, screen.xy, screen.z, _lm7bdx);
float _qs8b94 = max(_8o2ppi - _fq5n7f, 0.0);
if (_qs8b94 > 0.0001) {
vec4 _slxyc7 = textureLod(shadowcolor0, screen.xy, 0.0);
vec3 _9zezcay = clamp(_slxyc7.rgb, vec3(0.0), vec3(1.0));
// Cazfps holds all rights to Caztoon beta 2.2. The code is licensed for personal use only, not sold; reverse engineering, creating derivative works or modifying needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.
float _097su9 = dot(_9zezcay * _9zezcay, vec3(0.2627066, 0.6779996, 0.0592938))
* (1.0 - clamp(_slxyc7.a, 0.0, 1.0));
_mea99d += _qs8b94 * _097su9;
}
}
return mix(1.0, clamp(_mea99d, 0.0, 1.0), _a78all);
}

#ifdef _z60fn2f
float _b52jai(vec3 _g4yzf4, float _n1ypfm) {
float _097su9 = _z7e2of(
_g4yzf4, 1.0, shadowLightPosition, sunAngle);
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; reverse engineering or reusing any part of it is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
return 1.0 - clamp((1.0 - _097su9)
/ max(GHIBLI_CLOUD_SHADOW_STRENGTH, 0.0001), 0.0, 1.0);
}
#endif

float _obdiac(float distance) {
return 1.0 - smoothstep(_v680mws * 0.90, _v680mws, distance);
}

#endif
#endif
#endif
