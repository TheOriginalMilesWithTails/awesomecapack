/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _1c268mz
#define _1c268mz

#define SHADOWS_ENABLED
//#define PIXELATED_SHADOWS
#define DEFERRED_SHADOWS
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; selling or redistributing is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program.
#ifdef DEFERRED_SHADOWS
#if defined(SHADOWS_ENABLED) && !defined(PIXELATED_SHADOWS)
#define _bsxnmy6
#endif
#endif

//#define THIN_GBUFFER
#ifdef THIN_GBUFFER
#define LITE_THIN_GBUFFER
#endif
#endif
