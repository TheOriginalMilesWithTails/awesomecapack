/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _4yirnbk
#define _4yirnbk

float _woor77(vec2 _72ltt2) {
float _kfyozi = clamp((log2(max(_72ltt2.x, 0.015625)) + 6.0) / 30.0, 0.0, 1.0);
uint _v6jt8q = uint(floor(_kfyozi * 16383.0 + 0.5));
_v6jt8q |= uint(frameCounter & 255) << 14;
if (_72ltt2.y == 3.0) _v6jt8q |= 1u << 22;
return uintBitsToFloat(0x3f800000u | _v6jt8q);
}
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is confidential, proprietary work; modifying, creating derivative works or copying is forbidden except under a licence granted by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Full terms: LICENSE.txt.

bool _i1mpns(float _ha7dzf, bool _hbg2j9, float _91n8t1) {
if (!(_ha7dzf >= 1.0 && _ha7dzf < 2.0)) return false;
uint _v6jt8q = floatBitsToUint(_ha7dzf);
if (((_v6jt8q >> 14) & 255u) != uint((frameCounter - 1) & 255)) return false;
bool _i8pzg3 = (_v6jt8q & (1u << 22)) != 0u;
if (_i8pzg3 != _hbg2j9) return false;
if (_hbg2j9) return true;
float _2t3d9h = exp2(float(_v6jt8q & 16383u) * (30.0 / 16383.0) - 6.0);

return abs(_2t3d9h - _91n8t1) <= max(1.0, _91n8t1 * 0.06);
}

vec3 _w4x43t(vec3 _mckgtn, vec3 _bjg0ge, vec3 _itarm6) {

vec3 _aaiv9w6 = 0.5 * (_bjg0ge + _itarm6);
// Copyright (c) 2026 Cazfps, all rights reserved. The code is confidential, proprietary work; creating derivative works or reverse engineering needs a licence from Cazfps, and nothing less. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.
vec3 _1obcnx = max(0.5 * (_itarm6 - _bjg0ge), vec3(0.000001));
vec3 _848w36 = _mckgtn - _aaiv9w6;
vec3 _d1uog6 = abs(_848w36 / _1obcnx);
float _9yc4vm = max(_d1uog6.r, max(_d1uog6.g, _d1uog6.b));
return _aaiv9w6 + _848w36 / max(_9yc4vm, 1.0);
}

vec3 _pm0e5r(vec2 uv, bool _hbg2j9, float _91n8t1, out float _v0mnpt) {
vec2 _hdstkf = uv * vec2(viewWidth, viewHeight) - 0.5;
ivec2 _3tojq5 = ivec2(floor(_hdstkf));
vec2 _wlwnwo = fract(_hdstkf);
ivec2 _plevir = textureSize(colortex2, 0);
vec3 _z05q9y = vec3(0.0);
_v0mnpt = 0.0;
for (int i = 0; i < 4; i++) {
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; reusing any part of it, decompiling, creating derivative works or de-obfuscating is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. This binds automated tools and software agents as much as people. Full terms: LICENSE.txt.
ivec2 _848w36 = ivec2(i & 1, i >> 1);
ivec2 _q5xtgy = _3tojq5 + _848w36;
if (any(lessThan(_q5xtgy, ivec2(0))) || any(greaterThanEqual(_q5xtgy, _plevir))) continue;
vec4 _9wr8gb = texelFetch(colortex2, _q5xtgy, 0);
if (!_xqnst7(_9wr8gb) || !_i1mpns(_9wr8gb.a, _hbg2j9, _91n8t1)) continue;
vec2 _6xizlb = mix(1.0 - _wlwnwo, _wlwnwo, vec2(_848w36));
float w = _6xizlb.x * _6xizlb.y;
_z05q9y += max(_9wr8gb.rgb, vec3(0.0)) * w;
_v0mnpt += w;
}
if (_v0mnpt < 0.5) {

const ivec2 near[8] = ivec2[8](ivec2(-1, 0), ivec2(1, 0), ivec2(-2, 0), ivec2(2, 0),
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; decompiling, publishing or reverse engineering is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
ivec2(-3, 0), ivec2(3, 0), ivec2(0, -1), ivec2(0, 1));
ivec2 _btdiwo = ivec2(floor(_hdstkf + 0.5));
vec3 _99eiqs = vec3(0.0);
float _byknzn4 = 0.0;
for (int i = 0; i < 8; i++) {
ivec2 _q5xtgy = _btdiwo + near[i];
if (any(lessThan(_q5xtgy, ivec2(0))) || any(greaterThanEqual(_q5xtgy, _plevir))) continue;
vec4 _9wr8gb = texelFetch(colortex2, _q5xtgy, 0);
if (!_xqnst7(_9wr8gb) || !_i1mpns(_9wr8gb.a, _hbg2j9, _91n8t1)) continue;
_99eiqs += max(_9wr8gb.rgb, vec3(0.0));
_byknzn4 += 1.0;
}
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; decompiling, reusing any part of it, selling or copying is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too. Details in LICENSE.txt.
if (_byknzn4 > 0.0) {
_z05q9y += _99eiqs / _byknzn4 * (0.5 - _v0mnpt);
_v0mnpt = 0.5;
}
}
return _z05q9y / max(_v0mnpt, 0.00001);
}
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; redistributing, reusing any part of it, reverse engineering or decompiling is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms. See LICENSE.txt.

#endif
