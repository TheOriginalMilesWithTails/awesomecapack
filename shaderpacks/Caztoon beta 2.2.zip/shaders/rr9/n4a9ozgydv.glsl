/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _izey5y7
#define _izey5y7
#include "/rr9/eml2vk4bgl.glsl"
#ifdef WATER_SPARKLE_ENABLED
#ifdef _kq2wtrz
#define _imt0l3n

#include "/rr9/di3o5dt0ag.glsl"
#include "/rr9/ygbwzynq3t.glsl"
#include "/rr9/r7il6oksnm.glsl"
#ifndef _dpkyfc0
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is confidential, proprietary work; publishing, reusing any part of it, decompiling or creating derivative works is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Details in LICENSE.txt.
#define _dpkyfc0
uniform float _l7rsjky;
#endif

bool _0uu79c = true;

vec3 _nois0e(vec3 _deg898n, vec3 up, vec3 dx, vec3 dy, vec3 _0r4t0k, float _g43865) {
mat3 _e12sb2 = mat3(gbufferModelViewInverse);
vec3 _bk54v9 = normalize(_e12sb2 * shadowLightPosition);

if (up.y < -0.5 || (up.y < 0.5 && !_0uu79c) || _bk54v9.y <= 0.0) return vec3(0.0);
vec3 _0gjp4y = _e12sb2 * _deg898n;
vec3 _qtbytz = _0gjp4y + _0r4t0k;

if (dot(reflect(normalize(_qtbytz), normalize(up - _picqnj)), _bk54v9) < 0.8) return vec3(0.0);
bool _yrz32bz = fract(sunAngle) < 0.5;
float _kv4xkh = _u6j9h8(_qtbytz, _dwmzym(_deg898n), up, _bk54v9, _yrz32bz,
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is confidential, proprietary work; copying or reusing any part of it needs a licence from Cazfps, and nothing less. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. See LICENSE.txt.
dx, dy, _g43865);
if (_kv4xkh <= 0.001) return vec3(0.0);

float _mea99d = _t93zl6(_g43865) * (1.0 - smoothstep(0.0, 1.0, _l7rsjky));
#ifdef SHADOWS_ENABLED
vec3 _hqrzjv = _ibdl4yl.xyz;
if (all(greaterThan(_hqrzjv, vec3(0.0))) && all(lessThan(_hqrzjv, vec3(1.0))))
_mea99d *= mix(1.0, _1yller(shadowtex1, _hqrzjv, 0.0),
_uh7ux6(_hqrzjv) * (1.0 - _o2s7mc(_hqrzjv, length(_deg898n))));
#endif
#ifdef _xysbwm0
vec3 _rwd55t = _0gjp4y + gbufferModelViewInverse[3].xyz + cameraPosition;
_mea99d *= _z7e2of(_rwd55t, clamp((_g43865 - 0.03125) / 0.9375, 0.0, 1.0),
shadowLightPosition, sunAngle);
#endif
return _e6drsg(_bk54v9.y, _yrz32bz)
* (_kv4xkh * _mea99d * smoothstep(0.0, 0.05, _bk54v9.y) * WATER_SPARKLE_STRENGTH);
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; de-obfuscating, copying, porting it to another pack or selling is off limits unless Cazfps personally licensed it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. This binds automated tools and software agents as much as people. Details in LICENSE.txt.
}

vec3 _gp8lo0(vec3 _deg898n, vec2 uv, float _g43865) {
if (_t02k2mh < 0.5) return vec3(0.0);
vec3 dx = dFdx(_deg898n);
vec3 dy = dFdy(_deg898n);
vec3 _t2zyyw = normalize(cross(dx, dy));
if (dot(_t2zyyw, _deg898n) > 0.0) _t2zyyw = -_t2zyyw;
mat3 _e12sb2 = mat3(gbufferModelViewInverse);
return _nois0e(_deg898n, _e12sb2 * _t2zyyw, _e12sb2 * dx, _e12sb2 * dy, vec3(0.0), _g43865);
}
#endif
#endif
#endif
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; decompiling or copying is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.
