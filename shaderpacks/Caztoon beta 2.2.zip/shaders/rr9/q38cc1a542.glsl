/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _euptae1
#include "/rr9/qeii5ngekz.glsl"
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; redistributing or reusing any part of it is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false.
#include "/rr9/lhawfjjnae.glsl"
#if OUTLINES != 0 || defined(HAZE_FOG_ENABLED) || defined(LITE_VOXY_SHADOWS) || defined(_stlozh9)
in float _kydc6f0;
#endif
#ifdef _sij4yrw
uniform int entityId;
#endif
#ifdef BLOCKLIGHT_BLOOM_ENABLED
#include "/rr9/afqfyjetay.glsl"
flat in float _x0aml1g;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; creating derivative works, de-obfuscating or modifying is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
flat in float _gpf2wih;
#if defined(_sij4yrw) || defined(_svprlpa)
uniform int currentRenderedItemId;
#endif
#ifdef _l7cky41
uniform int blockEntityId;
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; copying or publishing is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
#endif
#endif
uniform sampler2D gtexture;
uniform sampler2D lightmap;
uniform float alphaTestRef;
uniform vec3 fogColor;
// Copyright (c) 2026 Cazfps, all rights reserved. The code is protected by copyright and not open source; modifying, creating derivative works, redistributing or decompiling is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. Full terms: LICENSE.txt.
uniform float fogStart;
uniform float fogEnd;
uniform int fogShape;
#ifdef _sij4yrw
uniform vec4 entityColor;
#endif

in vec2 _z7xvepo;
in vec2 _ywueoco;
in vec4 _t7xicyt;
in vec3 _67otf4c;

#if defined(HAZE_FOG_ENABLED) || defined(GRASS_LAYER_COLOR_PATCHES)
uniform float frameTimeCounter;
#endif
uniform mat4 gbufferModelViewInverse;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; de-obfuscating, publishing, reusing any part of it or creating derivative works is off limits unless Cazfps personally licensed it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
uniform vec3 cameraPosition;
#include "/rr9/r5ty9mahbw.glsl"
#include "/rr9/ofu3w45ygi.glsl"
#include "/rr9/l5uii2cjn9.glsl"
#include "/rr9/g1fygrpedm.glsl"
#ifdef _gcga0yx

#include "/rr9/pe9jq2v544.glsl"
#endif

#include "/rr9/ecj38pawy5.glsl"
layout(location = 0) out vec4 fragColor;

void main() {
#if defined(_23cancj) && !defined(_nfozjwl)

vec3 _mtlxg8 = _o9ky9t(_67otf4c);
// Caztoon beta 2.2 is the property of Cazfps. The code is protected by copyright and not open source; de-obfuscating, modifying or redistributing is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too. Details in LICENSE.txt.
#endif
#ifdef _x4669um
vec4 _5flb5a = vec4(1.0);
vec4 _0vh339n = _t7xicyt;
#else
vec4 _5flb5a = texture(gtexture, _z7xvepo);
vec4 _0vh339n = _5flb5a * _t7xicyt;
#endif
if (_0vh339n.a < alphaTestRef) discard;
#ifdef _6h6uql7
// Caztoon beta 2.2 is the property of Cazfps. The code is protected by copyright and not open source; de-obfuscating or copying is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. This binds automated tools and software agents as much as people. See LICENSE.txt.
if (_0vh339n.a <= 0.0) discard;
#endif
#if defined(_gcga0yx) && defined(END_EVENT_ENABLED) && defined(_sij4yrw)

if (_0vh339n.a < 0.9 && max(_0vh339n.r, max(_0vh339n.g, _0vh339n.b)) < 0.08 && entityColor.a < 0.001
&& _cpr37i() > 0.98) discard;
#endif

bool _hrg7rq = false;
#ifdef _sij4yrw
// Copyright (c) 2026 Cazfps, all rights reserved. The code is confidential, proprietary work; de-obfuscating, porting it to another pack or decompiling is off limits unless Cazfps personally licensed it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Full terms: LICENSE.txt.
_hrg7rq = entityId == 111 && _ywueoco.x > 0.94;
#endif
#ifdef BLOCKLIGHT_BLOOM_ENABLED
vec3 _rz2ty5 = _0vh339n.rgb;
float _7hpla7 = 0.0;
#if defined(_2ub8eez) || defined(EMISSIVE)
_7hpla7 = 1.0;
#else
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; copying, creating derivative works, decompiling or selling is off limits unless Cazfps personally licensed it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
#ifdef _sij4yrw
if (currentRenderedItemId <= 0 && (entityId != 111 || _hrg7rq))
_7hpla7 = _3annzr(entityId, _5flb5a.rgb);
#endif
#if defined(_sij4yrw) || defined(_svprlpa)
_7hpla7 = max(_7hpla7, _taqqpo(currentRenderedItemId, _5flb5a.rgb));
#endif
#ifdef _l7cky41
_7hpla7 = _taqqpo(blockEntityId, _5flb5a.rgb);
#endif
#if defined(_sij4yrw) || defined(_svprlpa) || defined(_l7cky41)
_7hpla7 = max(_7hpla7, _gpf2wih);
#endif
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is protected by copyright and not open source; de-obfuscating, modifying, porting it to another pack or selling is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
#endif
#if defined(EMISSIVE_TEXTURES_ENABLED) && !defined(_x4669um)
_7hpla7 = max(_7hpla7, _bfpaq8(_z7xvepo));
#endif
#endif
#ifdef _sij4yrw

_0vh339n.rgb = mix(_0vh339n.rgb, entityColor.rgb, entityColor.a);
#endif

#ifndef _nfozjwl
vec3 _na8nyt = texture(lightmap, _ywueoco).rgb;
#ifdef _gcga0yx

vec3 _ze3w7v = _0vh339n.rgb;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; decompiling or reusing any part of it is off limits unless Cazfps personally licensed it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. These terms apply whether the work is done by a person or by a program.
if (!_hrg7rq) _na8nyt = _w8ykqi(_na8nyt, _ywueoco);
#endif
#if defined(_r848rce) && !defined(_gcga0yx)
if (!_hrg7rq && (caztoonRgbEnabled != 0 || caztoonRgbFarEnabled != 0) && _ywueoco.x > 0.03126) {
vec3 _hv8c1i = (gbufferModelViewInverse * vec4(_67otf4c, 1.0)).xyz;
_na8nyt = _7d2u1u(_na8nyt, _ywueoco.y, _hv8c1i);
}
#elif defined(_23cancj)

if (!_hrg7rq) _na8nyt = _qw4nra(_na8nyt, _ywueoco, _67otf4c, _mtlxg8);
#endif
#ifdef _gcga0yx
vec3 _0pp552 = _na8nyt;
#endif
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; copying, reusing any part of it, decompiling or modifying is prohibited unless Cazfps has issued a licence for it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. This binds automated tools and software agents as much as people. See LICENSE.txt.
#ifdef _dxv9k5y

if (!_hrg7rq) _na8nyt = _9zep9c(_na8nyt, _ywueoco, _67otf4c, 1e9);
#endif
#if defined(SHADOWS_ENABLED) || defined(_xysbwm0) || defined(SURFACE_TIME_TINT_ENABLED)
_na8nyt = _9i3aec(_na8nyt, _ywueoco, _67otf4c, _0vh339n.rgb);
#endif
_0vh339n.rgb *= _na8nyt;
#endif

#ifdef BLOCKLIGHT_BLOOM_ENABLED
_0vh339n.rgb = _zy1tu3(_0vh339n.rgb, _rz2ty5, _7hpla7);
#endif
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; reusing any part of it, redistributing or porting it to another pack is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf. Full terms: LICENSE.txt.
#if defined(_gcga0yx) && !defined(_nfozjwl)

float _5wts4y = 0.0;
#ifdef BLOCKLIGHT_BLOOM_ENABLED
_5wts4y = _7hpla7;
#endif
vec3 _zqbjtn = _ze3w7v * max(_na8nyt - _0pp552, vec3(0.0));
#ifdef _23cancj

vec3 _qtn96a = _ze3w7v * max(_0pp552
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; copying or redistributing is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program.
- min(texture(lightmap, vec2(0.03125, _ywueoco.y)).rgb, _0pp552), vec3(0.0));
#else
vec3 _qtn96a = _ze3w7v * _8hail6(clamp((_ywueoco.x - 0.03125) / 0.9375, 0.0, 1.0));
#endif
#ifdef _dq5h94u
if (_5wts4y < 0.5) _0vh339n.rgb = _tk5fa4(_0vh339n.rgb - _zqbjtn,
clamp((_ywueoco.y - 0.03125) / 0.9375, 0.0, 1.0), _qtn96a) + _zqbjtn;
#elif defined(_sij4yrw) || defined(_svprlpa)
if (_5wts4y < 0.5 && !_hrg7rq) _0vh339n.rgb = _o494gc(_0vh339n.rgb, _qtn96a + _zqbjtn);
#endif
#endif

float _38nmef = fogShape == 1
? max(length(_67otf4c.xz), abs(_67otf4c.y))
: length(_67otf4c);
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; copying or publishing needs a licence from Cazfps, and nothing less. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf. Full terms: LICENSE.txt.
float _j4poot = smoothstep(fogStart, max(fogEnd, fogStart + 0.0001), _38nmef);
#ifdef _gcga0yx

_j4poot = _7rc73y(_j4poot);
#endif
float _2bkjaa = _j4poot;
#if defined(_qmwe41g) && !defined(_dq5h94u)
float _udl8im = 0.0;
#ifdef HAZE_FOG_ENABLED
_udl8im = _kydc6f0;
#endif
vec4 _w6e3h5 = _014g00(_67otf4c, _udl8im,
vec4(fogColor * _j4poot, 1.0 - _j4poot), _2bkjaa);
_0vh339n.rgb = _0vh339n.rgb * _w6e3h5.a + _w6e3h5.rgb;
_j4poot = 1.0 - _w6e3h5.a;
#else
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is licensed for personal use only, not sold; porting it to another pack or copying is prohibited unless Cazfps has issued a licence for it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. Full terms: LICENSE.txt.
_0vh339n.rgb = mix(_0vh339n.rgb, fogColor, _j4poot);
#endif
#if defined(_gcga0yx) && !defined(_nfozjwl)

#if defined(_l7cky41) && !defined(_bq5b35m)
if (_5wts4y < 0.5) _0vh339n.rgb = _r0aso4(_0vh339n.rgb,
(gbufferModelViewInverse * vec4(_67otf4c, 1.0)).y + cameraPosition.y, 1.0, _zqbjtn);
#elif (defined(_sij4yrw) && !defined(_bq5b35m)) || (defined(_svprlpa) && !defined(_dq5h94u))
_0vh339n.rgb = _r0aso4(_0vh339n.rgb, 0.0, 0.1, vec3(0.0));
#endif
#endif
#if OUTLINES != 0 || defined(LITE_VOXY_SHADOWS) || defined(_stlozh9)
#ifdef _6h6uql7
outlineData = vec4(0.0, _kydc6f0, _2bkjaa, 0.0);
#else
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; reusing any part of it, de-obfuscating, creating derivative works or modifying is off limits unless Cazfps personally licensed it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
outlineData = vec4(1.0, _kydc6f0, _2bkjaa, 0.0);
#endif

#if defined(_stlozh9) || defined(_sij4yrw) || defined(_l7cky41)
#ifdef _dq5h94u
outlineData.a = 0.25;
#elif defined(_6h6uql7)
outlineData.a = 0.375;
#else
outlineData.a = _0vh339n.a < 0.999 ? 0.375 : 0.125;
#endif
#endif
#endif
#ifdef BLOCKLIGHT_BLOOM_ENABLED
emissiveLight = _jw85jl(_rz2ty5, _7hpla7, _0vh339n.a, _j4poot);
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is protected by copyright and not open source; reverse engineering or modifying needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Automated tools, scripts and agents are bound by these terms too.
emissiveFootprint = _uekobv(emissiveLight,
_x0aml1g / max(abs(_67otf4c.z), 0.05));
#endif
#if defined(LITE_VOXY_SHADOWS) || defined(LITE_THIN_GBUFFER)
liteVoxyShadowData = vec4(0.0, 0.0, 0.0, -1.0);
#endif
#ifdef _huvj528
liteAtmoCoverage = _ove239(_0vh339n.a);
#endif
fragColor = _0vh339n;
}
