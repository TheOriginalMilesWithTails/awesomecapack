/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/pibjc437np.glsl"

int _vzxm43(int _omcfa9) {
int id = _omcfa9 - 10000;
if (id == 6) return 15;
if (id >= 20 && id <= 59) return id - 20;
if (id == 63) return 43;
if (id == 83) return 40;
if (id == 84) return 41;
if (id == 85) return 44;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is closed source and under copyright; reusing any part of it, publishing or copying is forbidden except under a licence granted by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf.
if (id == 86) return 45;
if (id == 87) return 46;
if (id == 88) return 68;
if (id == 89) return 47;
if (id >= 95 && id <= 97) return 5;
return -1;
}

float _taqqpo(int _omcfa9, vec3 _6dfy32) {
int et = _vzxm43(_omcfa9);
if (et < 0) return 0.0;
float _qybcby = _jut7tt(et, _6dfy32);

if (et == 39 || et == 40 || et == 41 || et == 46 || et == 47) {
vec3 _5oobj0 = _siwzrk(_6dfy32);
float _pw5mas = max(_04vfa9(_5oobj0, 48.0, 40.0), _04vfa9(_5oobj0, 170.0, 55.0));
float _slxyc7 = max(_pw5mas * smoothstep(0.25, 0.65, _5oobj0.z),
smoothstep(0.70, 0.9, _5oobj0.z));
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; publishing, creating derivative works or decompiling is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program.
_qybcby = _slxyc7 * (et == 41 ? 0.12 : (et == 40 ? 0.25 : 0.85));
}
return _qybcby >= 0.05 ? min(_qybcby, 1.0) : 0.0;
}

float _3annzr(int id, vec3 c) {

if (id == 101) return c.r > 0.8 && c.g < 0.2 && c.b < 0.2 ? 1.0 : 0.0;
if (id == 103) return c.r > 0.7 && c.g > 0.8 && c.b < 0.4 ? 0.8 : 0.0;
if (id == 104) return c.r > 0.8 && c.g > 0.9 && c.b > 0.9 ? 0.9 : 0.0;
if (id == 105) return 0.7;
if (id == 106) return c.r > 0.5 && c.g > 0.8 && c.b > 0.9 ? 0.8 : 0.0;
if (id == 107) return c.r > 0.6 && c.g < 0.3 && c.b < 0.3 ? 0.9 : 0.0;
if (id == 108) return c.r > 0.9 && c.g > 0.5 && c.b < 0.6 ? 0.6 : 0.0;
if (id == 109 || id == 110) return 1.0;

if (id == 111) return 0.25 + 0.25 * smoothstep(1.0, 1.8, dot(c, c));
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; redistributing, de-obfuscating, copying or decompiling is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Details in LICENSE.txt.
return 0.0;
}

#ifdef EMISSIVE_TEXTURES_ENABLED
uniform sampler2D specular;
float _bfpaq8(vec2 uv) {

float a = texture(specular, uv).a;
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; publishing, redistributing, modifying or creating derivative works is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com.
return a > 254.5 / 255.0 ? 0.0 : a;
}
#endif

#ifdef _gcga0yx
#include "/rr9/2r0gwx4gt3.glsl"
#endif
vec3 _zy1tu3(vec3 _wt0qvt, vec3 _qxk2jx, float _uwc3vv) {
#ifdef _gcga0yx

return max(_wt0qvt, _qxk2jx * min(4.0 * _uwc3vv, 1.0) * END_EMISSIVE_BOOST);
#else
return max(_wt0qvt, _qxk2jx * min(4.0 * _uwc3vv, 1.0));
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is proprietary and confidential; reverse engineering, redistributing or reusing any part of it is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. No tool, script or agent is exempt from these terms. See LICENSE.txt.
#endif
}
vec4 _jw85jl(vec3 _qxk2jx, float _uwc3vv, float _kozpav, float _khx3fy) {
return vec4(_qxk2jx * min(2.0 * _uwc3vv, 1.0) * _kozpav * (1.0 - _khx3fy), _kozpav);
}

vec4 _uekobv(vec4 _7wth21, float _awy7kp) {
float _3wfaa8 = dot(_7wth21.rgb, vec3(0.2126, 0.7152, 0.0722));
return vec4(_3wfaa8 * min(_awy7kp, 60000.0), 0.0, 0.0, _7wth21.a);
}
