/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _b3ov1ig
#define _b3ov1ig
#include "/rr9/eml2vk4bgl.glsl"
#if defined(_ksr8o1r) && defined(_kq2wtrz)

flat in float _t02k2mh;
uniform ivec3 cameraPositionInt;
uniform vec3 cameraPositionFract;
uniform float _xd9jf3n;
#define _4yxtqae _xd9jf3n
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; modifying, publishing or reverse engineering is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too.
#include "/rr9/zra2pzgmmz.glsl"

vec3 _dwmzym(vec3 _deg898n) {
return mat3(gbufferModelViewInverse) * _deg898n + gbufferModelViewInverse[3].xyz
+ vec3(cameraPositionInt & ivec3(255)) + cameraPositionFract;
}

#endif
#if defined(_wvnpeme) && defined(_kq2wtrz)

#define _0s6xabo
#include "/rr9/kvtis0mxoj.glsl"

/*
const int colortex9Format = RGBA16F;
const bool colortex9Clear = true;
const vec4 colortex9ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
*/
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; modifying, porting it to another pack or creating derivative works is off limits unless Cazfps personally licensed it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Automated tools, scripts and agents are bound by these terms too.
#if OUTLINES != 0 || defined(LITE_VOXY_SHADOWS) || defined(_stlozh9)
#ifdef BLOCKLIGHT_BLOOM_ENABLED
#ifdef LITE_VOXY_SHADOWS
/* RENDERTARGETS: 0,3,4,15,7,9 */
layout(location = 5) out vec4 liteWaterRefraction;
#else
/* RENDERTARGETS: 0,3,4,15,9 */
layout(location = 4) out vec4 liteWaterRefraction;
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; porting it to another pack, redistributing or copying is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
#endif
#else
#ifdef LITE_VOXY_SHADOWS
/* RENDERTARGETS: 0,3,7,9 */
layout(location = 3) out vec4 liteWaterRefraction;
#else
/* RENDERTARGETS: 0,3,9 */
layout(location = 2) out vec4 liteWaterRefraction;
#endif
#endif
#else
#ifdef BLOCKLIGHT_BLOOM_ENABLED
/* RENDERTARGETS: 0,4,15,9 */
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; de-obfuscating, selling, redistributing or publishing needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Automated tools, scripts and agents are bound by these terms too.
layout(location = 3) out vec4 liteWaterRefraction;
#else
/* RENDERTARGETS: 0,9 */
layout(location = 1) out vec4 liteWaterRefraction;
#endif
#endif

vec4 _4fkh8b(vec3 _deg898n, float _cw7o15, float _g43865, float _p75dwq) {
if (_t02k2mh < 0.5) return vec4(0.0);
vec3 dx = dFdx(_deg898n);
vec3 dy = dFdy(_deg898n);
vec3 _aikr6a = -normalize(_deg898n);
vec3 _t2zyyw = normalize(cross(dx, dy));
if (dot(_t2zyyw, _aikr6a) < 0.0) _t2zyyw = -_t2zyyw;
mat3 _e12sb2 = mat3(gbufferModelViewInverse);
vec3 _5be6ab = _e12sb2 * _t2zyyw;
vec2 _wyhi3a = vec2(0.0);
#ifdef WATER_REFRACTION_ENABLED
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is closed source and under copyright; porting it to another pack or publishing is forbidden except under a licence granted by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. These terms apply whether the work is done by a person or by a program.

vec3 up = _5be6ab.y < 0.0 ? -_5be6ab : _5be6ab;
vec3 _0ox3cn = _o15jj9(_dwmzym(_deg898n), up,
max(length(dx), length(dy)), _g43865);

float _ppgxh4 = _5be6ab.y < -0.5 ? 0.33 : 0.25;
_wyhi3a = ((_0ox3cn * _e12sb2) * (_ppgxh4 * smoothstep(0.0, 0.15, abs(dot(_t2zyyw, _aikr6a))))).xy;
#endif

return vec4(_wyhi3a, _0es1tj(1.0 - _cw7o15, _g43865, _5be6ab.y > 0.5, _p75dwq), -_deg898n.z);
}
#endif
#endif
