/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _8o2yo6b
#define _8o2yo6b
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; selling, reverse engineering or de-obfuscating needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. No tool, script or agent is exempt from these terms.

#define GRASS_LAYER_COLOR_PATCHES
#define GRASS_LAYER_ANIMATION
#define GRASS_WAVING_SPEED 1.00 // [0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00]
#define GRASS_WAVING_INTENSITY 1.80 // [0.25 0.50 0.75 1.00 1.25 1.50 1.75 1.80 2.00 2.50 3.00]
#define GRASS_LAYER_INTERACTION
#define GRASS_INTERACTION_INTENSITY 2.20 // [0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.20 2.50 3.00]
#define GRASS_INTERACTION_RADIUS 4.00 // [1.00 1.50 2.00 2.50 3.00 3.50 4.00 5.00]

#endif
