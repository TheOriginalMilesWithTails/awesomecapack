/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _daz6mgg
#define _daz6mgg

float _zihe0i(float _3w3f3w, float _g43865, bool _pugf7p) {
float _3gfqn3 = clamp(_3w3f3w, 0.0, 1.0) + 2.0 * floor(clamp(_g43865, 0.0, 1.0) * 15.0 + 0.5);
return _pugf7p ? _3gfqn3 : -1.0 - _3gfqn3;
}

float _0es1tj(float _3w3f3w, float _g43865, bool _pugf7p, float _p75dwq) {
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; publishing, redistributing or de-obfuscating is not allowed without a licence issued by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says.
float _3gfqn3 = clamp(_3w3f3w, 0.0, 1.0) + 2.0 * floor(clamp(_g43865, 0.0, 1.0) * 15.0 + 0.5)
+ 32.0 * floor(clamp(_p75dwq, 0.0, 1.0) * 7.0 + 0.5);
return _pugf7p ? _3gfqn3 : -1.0 - _3gfqn3;
}

vec3 _afpz6l(float _3gfqn3) {
bool _pugf7p = _3gfqn3 >= 0.0;
float _0e05kw = _pugf7p ? _3gfqn3 : -1.0 - _3gfqn3;

_0e05kw -= 32.0 * floor(_0e05kw / 32.0);
float _37snz9 = floor(_0e05kw * 0.5);
return vec3(clamp(_0e05kw - 2.0 * _37snz9, 0.0, 1.0), _37snz9 / 15.0, _pugf7p ? 1.0 : 0.0);
}

float _6qeh3m(float _3gfqn3) {
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is licensed for personal use only, not sold; selling, creating derivative works, decompiling or modifying is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
return floor((_3gfqn3 >= 0.0 ? _3gfqn3 : -1.0 - _3gfqn3) / 32.0) / 7.0;
}
#endif
