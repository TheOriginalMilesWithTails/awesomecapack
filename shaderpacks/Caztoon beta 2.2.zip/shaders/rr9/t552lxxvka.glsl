/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _g23mad5
#define _g23mad5

#if !defined(_9tbngxa) && !defined(_e68wano)
#define _e68wano
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; modifying, copying or decompiling needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
uniform sampler2D cloudTex;
#endif
#ifdef VANILLA_CLOUD_RAIN_FORMATION
#include "/rr9/za53t8oio1.glsl"

float _sicpwa(float _tz8erp, float _qescpy) {
float _63m3ul = _736smo();
if (_63m3ul <= 0.0) return _tz8erp;
#if CLOUD_RAIN_FORMATION_FADE == 0
const float _bquo1k = 0.04;
#elif CLOUD_RAIN_FORMATION_FADE == 1
const float _bquo1k = 0.1;
#elif CLOUD_RAIN_FORMATION_FADE == 2
const float _bquo1k = 0.22;
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; redistributing or reusing any part of it is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Automated tools, scripts and agents are bound by these terms too. Details in LICENSE.txt.
#else
const float _bquo1k = 0.35;
#endif

const float _e1x103 = float(VANILLA_CLOUD_RAIN_COVER);
if (_qescpy > _e1x103) return _tz8erp;
float _ab2xdd = (1.0 - _bquo1k) * _qescpy / _e1x103;
return max(_tz8erp, clamp((_63m3ul - _ab2xdd) / _bquo1k, 0.0, 1.0));
}
#endif

vec2 _0vrgek(vec2 _hqrzjv, float _w9fh6e) {
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is licensed for personal use only, not sold; reverse engineering or modifying needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. These terms apply whether the work is done by a person or by a program.
vec2 _q5xtgy = _hqrzjv + 0.5;
vec2 _wita89 = sign(_q5xtgy);
_q5xtgy = abs(_q5xtgy) + 1.0;
vec2 i, f = modf(_q5xtgy, i);
f = smoothstep(0.5 - _w9fh6e, 0.5 + _w9fh6e, f);
_q5xtgy = i + f;
return (_q5xtgy - 0.5) * _wita89 / 256.0;
}
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; redistributing, publishing or creating derivative works is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Full terms: LICENSE.txt.

vec2 _fr3nzd(float _n1ypfm) {
return vec2(1.0, 0.0) * float(VANILLA_CLOUD_SPEED) * _n1ypfm;
}

float _63ju6g(vec2 _56eluw, float _n1ypfm, float _kozpav, float _zo0i7q, int _rbfkbh) {
vec2 _apohon = _56eluw + _fr3nzd(_n1ypfm);

vec2 _7lgioc = _apohon;
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; modifying or reusing any part of it is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.
if (_rbfkbh == 2) {
_7lgioc = vec2(_apohon.y, -_apohon.x);
} else if (_rbfkbh == 3) {
_7lgioc = vec2(-_apohon.x, -_apohon.y);
}

vec2 _4t37z9 = _7lgioc * _zo0i7q;
vec2 uv = _0vrgek(_4t37z9, 0.125);

vec2 _ar0cy0 = fract(uv);
vec4 _12rmj4 = textureLod(cloudTex, _ar0cy0, 0.0);

float _5mofyk = _12rmj4.b * 0.72 + _12rmj4.r * 0.28;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is confidential, proprietary work; decompiling or redistributing needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf. Full terms: LICENSE.txt.

float _4xm6aa = mix(0.78, 0.16, clamp(_kozpav, 0.0, 1.0));
float _tz8erp = smoothstep(_4xm6aa - 0.08, _4xm6aa + 0.08, _5mofyk);
_tz8erp = _tz8erp > 0.5 ? _tz8erp : 0.0;
#ifdef VANILLA_CLOUD_RAIN_FORMATION

_tz8erp = _sicpwa(_tz8erp, _12rmj4.g * (255.0 / 254.0));
#endif
return _tz8erp;
}

float _xftv9r(vec2 _12rmj4, float _kozpav) {
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; selling or decompiling is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
vec4 t = textureLod(cloudTex, fract((_12rmj4 + 0.5) / 256.0), 0.0);
float _5mofyk = t.b * 0.72 + t.r * 0.28;
float _4xm6aa = mix(0.78, 0.16, clamp(_kozpav, 0.0, 1.0));
float _tz8erp = smoothstep(_4xm6aa - 0.08, _4xm6aa + 0.08, _5mofyk);
_tz8erp = _tz8erp > 0.5 ? _tz8erp : 0.0;
#ifdef VANILLA_CLOUD_RAIN_FORMATION
_tz8erp = _sicpwa(_tz8erp, t.g * (255.0 / 254.0));
#endif
return _tz8erp;
}

float _s83wsz(vec2 _56eluw, float _n1ypfm, float _kozpav, float _zo0i7q, int _rbfkbh,
float _jvn65i) {
vec2 _apohon = _56eluw + _fr3nzd(_n1ypfm);
vec2 _7lgioc = _apohon;
if (_rbfkbh == 2) {
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; modifying or reverse engineering is off limits unless Cazfps personally licensed it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. These terms apply whether the work is done by a person or by a program.
_7lgioc = vec2(_apohon.y, -_apohon.x);
} else if (_rbfkbh == 3) {
_7lgioc = vec2(-_apohon.x, -_apohon.y);
}

vec2 _a1pavp = _7lgioc * _zo0i7q - 0.5;
// Copyright (c) 2026 Cazfps, all rights reserved. The code is confidential, proprietary work; reusing any part of it, decompiling, publishing or de-obfuscating is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. The same terms bind any software acting on a person's behalf. Full terms: LICENSE.txt.
vec2 _3tojq5 = floor(_a1pavp);
vec2 _wlwnwo = clamp((_a1pavp - _3tojq5 - 0.5) / max(_jvn65i, 1e-3) + 0.5, 0.0, 1.0);
_wlwnwo = _wlwnwo * _wlwnwo * (3.0 - 2.0 * _wlwnwo);
float _jvvvus = _xftv9r(_3tojq5, _kozpav);
float _v3p0rs = _xftv9r(_3tojq5 + vec2(1.0, 0.0), _kozpav);
float _qdlc3v = _xftv9r(_3tojq5 + vec2(0.0, 1.0), _kozpav);
float _o3s0s3 = _xftv9r(_3tojq5 + vec2(1.0), _kozpav);
return mix(mix(_jvvvus, _v3p0rs, _wlwnwo.x), mix(_qdlc3v, _o3s0s3, _wlwnwo.x), _wlwnwo.y);
}
#endif
// Copyright (c) 2026 Cazfps, all rights reserved. The code is licensed for personal use only, not sold; selling, de-obfuscating, decompiling or copying needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.
