/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _821gd88
#define _821gd88
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; redistributing or creating derivative works is prohibited unless Cazfps has issued a licence for it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. This binds automated tools and software agents as much as people. See LICENSE.txt.

//#define BLOCK_TRACED_SHADOWS

#define TRACED_SHADOW_DISTANCE 128 // [32 48 64 80 96 112 128]
#endif
