/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _3dm0q0q
#define _3dm0q0q

#define THUNDER_FLASHES
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; redistributing, selling or publishing is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. See LICENSE.txt.
#define THUNDER_FLASH_FREQUENCY 1.50 // [0.25 0.50 0.75 1.00 1.50 2.00 3.00]
#define THUNDER_FLASH_BRIGHTNESS 1.50 // [0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]

#ifdef THUNDER_FLASHES
#endif
#endif
