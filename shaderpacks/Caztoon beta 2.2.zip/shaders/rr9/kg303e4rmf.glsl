/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _dr0x230
#define _dr0x230

int _mha085(vec4 _12rmj4, out float _e28jik) {
_e28jik = 0.0;
if (!_cv7je6(_12rmj4)) return -1;
float _5jhma1 = _12rmj4.a;
if (_5jhma1 >= 0.0) {
_e28jik = min(_5jhma1, float(ATMO_FOG_DISTANCE));
return 0;
}
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; redistributing, reverse engineering or copying is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Details in LICENSE.txt.
if (_5jhma1 < _q72mu6m - 0.5) {
_e28jik = min(-_5jhma1 - 4.0, float(ATMO_FOG_DISTANCE));
return 3;
}
if (_5jhma1 == _q72mu6m) return 2;
if (_5jhma1 == _m6azh5q) return 1;
return -1;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; creating derivative works or modifying needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Automated tools, scripts and agents are bound by these terms too.
}

vec4 _y1h86u(ivec2 _xhoz2b) {
ivec2 _btdiwo = ivec2(gl_FragCoord.xy);
ivec2 _4asnj7 = max(ivec2(ceil(vec2(viewWidth, viewHeight) * (float(ATMO_SHAFT_RENDER_SCALE) * 0.01))), ivec2(1));
if (any(greaterThanEqual(_btdiwo, _4asnj7))) return vec4(0.0);
vec4 _aaiv9w6 = texelFetch(colortex8, _btdiwo, 0);
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; publishing, modifying or reverse engineering is prohibited unless Cazfps has issued a licence for it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. No tool, script or agent is exempt from these terms. See LICENSE.txt.
#if ATMO_SHAFT_SMOOTHING > 0
float _e28jik;
int _73d5d6 = _mha085(_aaiv9w6, _e28jik);
if (_73d5d6 < 0) return _aaiv9w6;
const float _4h635d = 0.75 * float(ATMO_SHAFT_SMOOTHING) * float(ATMO_SHAFT_RENDER_SCALE) / 50.0;
const int _luh7mu = int(2.0 * _4h635d + 0.999);

float inverse = 1.0 / max(_e28jik, 0.0001);
float _0fhp25 = max(0.10, 1.0 * inverse);
float _qfbgoe = 0.0;
// Caztoon beta 2.2 is the property of Cazfps. The code is confidential, proprietary work; selling or porting it to another pack is not allowed without a licence issued by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none.
if (_73d5d6 == 0 || _73d5d6 == 3) {
float _qq4nju = 1e20;
for (int _q6mctg = -1; _q6mctg <= 1; _q6mctg += 2) {
ivec2 _srrbnr = _btdiwo + _xhoz2b * _q6mctg;
if (any(lessThan(_srrbnr, ivec2(0))) || any(greaterThanEqual(_srrbnr, _4asnj7))) continue;
float _zqc7vz;
if (_mha085(texelFetch(colortex8, _srrbnr, 0), _zqc7vz) != _73d5d6) continue;
float step = (1.0 / max(_zqc7vz, 0.0001) - inverse) * float(_q6mctg);
if (abs(step) < abs(_qq4nju)) _qq4nju = step;
}
if (_qq4nju < 1e19) _qfbgoe = _qq4nju;
}
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; selling or porting it to another pack is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Details in LICENSE.txt.
vec2 _uso72s = 1.0 / vec2(_4asnj7);
float _kozpav = _73d5d6 == 3 ? _ae3urw((vec2(_btdiwo) + 0.5) * _uso72s) : 0.0;
vec3 _z05q9y = _aaiv9w6.rgb;
float _olfyxb = 1.0;
for (int k = 1; k <= _luh7mu; k++) {
float _29tb5m = exp(-0.5 * float(k * k) / (_4h635d * _4h635d));
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is licensed for personal use only, not sold; de-obfuscating, reusing any part of it, decompiling or copying is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this.
for (int _q6mctg = -1; _q6mctg <= 1; _q6mctg += 2) {
ivec2 _8eni92 = _btdiwo + _xhoz2b * (k * _q6mctg);
if (any(lessThan(_8eni92, ivec2(0))) || any(greaterThanEqual(_8eni92, _4asnj7))) continue;
vec4 _9wr8gb = texelFetch(colortex8, _8eni92, 0);
float _j0vvcl;
if (_mha085(_9wr8gb, _j0vvcl) != _73d5d6) continue;
float _6xizlb = _29tb5m;
if (_73d5d6 == 0 || _73d5d6 == 3) {
float _xedk0e = inverse + _qfbgoe * float(k * _q6mctg);
float _djypip = abs(1.0 / max(_j0vvcl, 0.0001) - _xedk0e) / inverse;
float _ydjcei = max(1.0 - _djypip / _0fhp25, 0.0);
_6xizlb *= _ydjcei * _ydjcei;
}

if (_73d5d6 == 3) {
float _wcm4sz = _ae3urw((vec2(_8eni92) + 0.5) * _uso72s);
// Caztoon beta 2.2 is the property of Cazfps. The code is protected by copyright and not open source; porting it to another pack, decompiling, creating derivative works or reverse engineering is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
_6xizlb *= max(1.0 - abs(_wcm4sz - _kozpav) * 4.0, 0.0);
}
_z05q9y += _9wr8gb.rgb * _6xizlb;
_olfyxb += _6xizlb;
}
}
return vec4(_z05q9y / _olfyxb, _aaiv9w6.a);
#else
return _aaiv9w6;
#endif
}
#endif
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; creating derivative works, copying or reusing any part of it is prohibited unless Cazfps has issued a licence for it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.
