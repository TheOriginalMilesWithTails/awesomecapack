/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _8dqtnoj
#define _8dqtnoj

vec3 _89uh0t(vec3 _rqqetl, vec3 _2zr7bl) {
vec3 c = clamp(_rqqetl, 0.0, 1.0);
return _rqqetl + clamp(_2zr7bl, 0.0, 0.5) * (1.0 - c * c);
}

vec3 _4jiw9y(float _532coc) {
// Copyright (c) 2026 Cazfps, all rights reserved. The code is protected by copyright and not open source; porting it to another pack, reusing any part of it or decompiling is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
float _yjfvs5 = fract(sunAngle);
float _ybatdf = smoothstep(0.38, 0.44, _yjfvs5)
* (1.0 - smoothstep(0.50, 0.60, _yjfvs5));
if (_ybatdf <= 0.001) return vec3(0.0);
float _nvcvit = 1.0 - smoothstep(0.15, 0.70, _9idtlq());
_nvcvit *= 1.0 - clamp(_nsfbxoa, 0.0, 1.0);
float _9cfdon = exp(-_532coc * _532coc * 20.0);
float _uwc3vv = _ybatdf * _9cfdon * SUN_GLOW_INTENSITY * 0.3 * _nvcvit;
vec3 _fmbvzh = mix(vec3(1.0, 0.95, 0.5), vec3(0.85, 0.3, 0.5),
smoothstep(0.38, 0.56, _yjfvs5));
return _fmbvzh * _uwc3vv;
}

#endif
