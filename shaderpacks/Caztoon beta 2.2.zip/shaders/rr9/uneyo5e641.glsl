/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _bkz0tzg
#define _bkz0tzg

#define CLOUD_RAIN_OPACITY_REDUCTION 100 // [0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100]
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; de-obfuscating, reverse engineering, reusing any part of it or publishing is forbidden except under a licence granted by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Automated tools, scripts and agents are bound by these terms too.

#define CLOUD_RAIN_FORMATION_FADE 3 // [0 1 2 3]

#define CLOUD_RAIN_BODY_R 0.36 // [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.14 0.16 0.18 0.20 0.22 0.24 0.26 0.28 0.30 0.32 0.34 0.36 0.38 0.40 0.42 0.44 0.46 0.48 0.50 0.52 0.54 0.56 0.58 0.60 0.62 0.64 0.66 0.68 0.70 0.72 0.74 0.76 0.78 0.80 0.82 0.84 0.86 0.88 0.90 0.92 0.94 0.96 0.98 1.00]
#define CLOUD_RAIN_BODY_G 0.40 // [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.14 0.16 0.18 0.20 0.22 0.24 0.26 0.28 0.30 0.32 0.34 0.36 0.38 0.40 0.42 0.44 0.46 0.48 0.50 0.52 0.54 0.56 0.58 0.60 0.62 0.64 0.66 0.68 0.70 0.72 0.74 0.76 0.78 0.80 0.82 0.84 0.86 0.88 0.90 0.92 0.94 0.96 0.98 1.00]
#define CLOUD_RAIN_BODY_B 0.54 // [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.14 0.16 0.18 0.20 0.22 0.24 0.26 0.28 0.30 0.32 0.34 0.36 0.38 0.40 0.42 0.44 0.46 0.48 0.50 0.52 0.54 0.56 0.58 0.60 0.62 0.64 0.66 0.68 0.70 0.72 0.74 0.76 0.78 0.80 0.82 0.84 0.86 0.88 0.90 0.92 0.94 0.96 0.98 1.00]
#define CLOUD_RAIN_SHADOW_R 0.26 // [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.14 0.16 0.18 0.20 0.22 0.24 0.26 0.28 0.30 0.32 0.34 0.36 0.38 0.40 0.42 0.44 0.46 0.48 0.50 0.52 0.54 0.56 0.58 0.60 0.62 0.64 0.66 0.68 0.70 0.72 0.74 0.76 0.78 0.80 0.82 0.84 0.86 0.88 0.90 0.92 0.94 0.96 0.98 1.00]
#define CLOUD_RAIN_SHADOW_G 0.22 // [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.14 0.16 0.18 0.20 0.22 0.24 0.26 0.28 0.30 0.32 0.34 0.36 0.38 0.40 0.42 0.44 0.46 0.48 0.50 0.52 0.54 0.56 0.58 0.60 0.62 0.64 0.66 0.68 0.70 0.72 0.74 0.76 0.78 0.80 0.82 0.84 0.86 0.88 0.90 0.92 0.94 0.96 0.98 1.00]
#define CLOUD_RAIN_SHADOW_B 0.38 // [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.14 0.16 0.18 0.20 0.22 0.24 0.26 0.28 0.30 0.32 0.34 0.36 0.38 0.40 0.42 0.44 0.46 0.48 0.50 0.52 0.54 0.56 0.58 0.60 0.62 0.64 0.66 0.68 0.70 0.72 0.74 0.76 0.78 0.80 0.82 0.84 0.86 0.88 0.90 0.92 0.94 0.96 0.98 1.00]
#define CLOUD_RAIN_HIGHLIGHT 0.30 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define CLOUDS_GHIBLI_ENABLED
#include "/rr9/0udranncg9.glsl"

#define GHIBLI_CLOUD_RAIN_FORMATION
#define GHIBLI_CLOUD_RAIN_COVER 1.00 // [0.25 0.40 0.55 0.70 0.85 1.00]
#define GHIBLI_CLOUD_RAIN_GAP_SIZE 1 // [1 2 3]
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; modifying, selling, copying or reverse engineering is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.

#define GHIBLI_CLOUD_SUN_GAPS 2 // [0 1 2 3]

#if (defined(CLOUDS_GHIBLI_ENABLED) && defined(GHIBLI_CLOUD_RAIN_FORMATION)) || (defined(_eflkbd5) && defined(VANILLA_CLOUD_RAIN_FORMATION))
#define _xjhe5z7 0.0
#else
#define _xjhe5z7 (float(CLOUD_RAIN_OPACITY_REDUCTION) / 100.0)
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; modifying, creating derivative works, copying or porting it to another pack is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. The same terms bind any software acting on a person's behalf.
#endif
#ifdef _65jbzyx
const float wetnessHalflife = 3.0;
const float drynessHalflife = 3.0;
#endif
#define GHIBLI_CLOUD_RESOLUTION 2 // [0 2 3]
#define GHIBLI_CLOUD_PROFILE 0 // [0 1]
#define GHIBLI_CLOUD_PERF_MODE 0 // [0 1 2 3]
#define GHIBLI_CLOUD_STEPS 24 // [8 10 12 16 20 24]
#define GHIBLI_CLOUD_COVERAGE 1.00 // [0.10 0.15 0.20 0.25 0.30 0.32 0.35 0.40 0.42 0.46 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define GHIBLI_CLOUD_DENSITY 1.35 // [0.50 0.65 0.80 1.00 1.25 1.35 1.50 1.75 2.00 2.50 3.00]
#define GHIBLI_CLOUD_HEIGHT 60.0 // [0.0 20.0 40.0 60.0 80.0 100.0 120.0 160.0 200.0 220.0 240.0 260.0 280.0 320.0 400.0 500.0 650.0 800.0]
#define GHIBLI_CLOUD_HEIGHT_RANGE 320.0 // [0.0 40.0 80.0 120.0 160.0 240.0 320.0 400.0 600.0 800.0 1200.0]
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; copying, selling or redistributing needs a licence from Cazfps, and nothing less. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Full terms: LICENSE.txt.
#define GHIBLI_CLOUD_THICKNESS 460.0 // [100.0 140.0 180.0 220.0 260.0 320.0 400.0 460.0 500.0]
#define GHIBLI_CLOUD_TOWERING 1.20 // [0.50 0.65 0.80 1.00 1.15 1.20 1.30 1.50]
#define GHIBLI_CLOUD_SCALE 1.50 // [0.40 0.55 0.70 0.85 1.00 1.20 1.50 1.80 2.00]
#define GHIBLI_CLOUD_DETAIL 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50]
#define GHIBLI_CLOUD_BUBBLE_SIZE 6.0 // [4.0 6.0 8.0 10.0 12.0 16.0 20.0 24.0 32.0 40.0 48.0]
#define GHIBLI_CLOUD_FLAT_BOTTOM
#define GHIBLI_CLOUD_CUBE_BUBBLES
#define GHIBLI_CLOUD_DEFORMATION
#define GHIBLI_CLOUD_SPEED 6.0 // [0.0 0.5 1.0 2.0 3.0 4.0 6.0 8.0 12.0]
#define GHIBLI_CLOUD_WIND_VARIATION 1.00 // [0.00 0.10 0.25 0.50 0.65 0.75 1.00]
#define GHIBLI_CLOUD_WIND_PERIOD 180.0 // [30.0 60.0 90.0 120.0 180.0 240.0 360.0 600.0]
#define GHIBLI_CLOUD_DISTANCE 6000 // [2000 3000 4000 5000 6000 8000 9000 10000 12000 16000 20000]
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; creating derivative works, porting it to another pack or redistributing is forbidden except under a licence granted by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
#define GHIBLI_CLOUD_RAY_SHADING_ENABLED
#define GHIBLI_CLOUD_LIGHT_STEPS 16 // [8 12 16 24 32]
#define GHIBLI_CLOUD_SHADOW_DEPTH 18.0 // [6.0 8.0 12.0 16.0 18.0 24.0 32.0 40.0 48.0]
#define GHIBLI_CLOUD_BRIGHTNESS 1.00 // [0.50 0.65 0.80 0.90 1.00 1.10 1.20 1.30 1.50 1.75 2.00]
#define GHIBLI_CLOUD_NIGHT_BRIGHTNESS 0.85 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.85 0.90 1.00 1.10 1.20 1.30 1.50]
#define GHIBLI_CLOUD_NIGHT_BAND_DARKNESS 0.85 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.85 0.90 1.00]
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is licensed for personal use only, not sold; porting it to another pack or reverse engineering is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.
#define GHIBLI_CLOUD_LIGHT_BANDS 7 // [1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32]
#define GHIBLI_CLOUD_HIGHLIGHT_WIDTH 0.20 // [0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70]
#define GHIBLI_CLOUD_BANDING 1.00 // [0.00 0.20 0.35 0.50 0.65 0.78 0.90 0.95 1.00]
#define _hxm370y 0.03 // [0.00 0.03 0.10 0.20 0.35 0.50 0.65 0.80 1.00]
#define GHIBLI_CLOUD_SHADOW_STRENGTH 0.40 // [0.00 0.05 0.10 0.15 0.22 0.30 0.40 0.50 0.60]
#define GHIBLI_CLOUD_BAND1_R 0.98 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.79 0.80 0.85 0.86 0.90 0.92 0.93 0.94 0.95 0.97 0.98 0.99 1.00]
#define GHIBLI_CLOUD_BAND1_G 1.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.79 0.80 0.85 0.86 0.90 0.92 0.93 0.94 0.95 0.97 0.98 0.99 1.00]
#define GHIBLI_CLOUD_BAND1_B 1.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.79 0.80 0.85 0.86 0.90 0.92 0.93 0.94 0.95 0.97 0.98 0.99 1.00]
#define GHIBLI_CLOUD_BAND2_R 0.92 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.79 0.80 0.85 0.86 0.90 0.92 0.93 0.94 0.95 0.97 0.98 0.99 1.00]
#define GHIBLI_CLOUD_BAND2_G 0.97 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.79 0.80 0.85 0.86 0.90 0.92 0.93 0.94 0.95 0.97 0.98 0.99 1.00]
#define GHIBLI_CLOUD_BAND2_B 0.99 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.79 0.80 0.85 0.86 0.90 0.92 0.93 0.94 0.95 0.97 0.98 0.99 1.00]
#define GHIBLI_CLOUD_BAND3_R 0.80 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.79 0.80 0.85 0.86 0.90 0.92 0.93 0.94 0.95 0.97 0.98 0.99 1.00]
#define GHIBLI_CLOUD_BAND3_G 0.93 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.79 0.80 0.85 0.86 0.90 0.92 0.93 0.94 0.95 0.97 0.98 0.99 1.00]
#define GHIBLI_CLOUD_BAND3_B 0.97 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.79 0.80 0.85 0.86 0.90 0.92 0.93 0.94 0.95 0.97 0.98 0.99 1.00]
#define GHIBLI_CLOUD_BAND4_R 0.70 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.79 0.80 0.85 0.86 0.90 0.92 0.93 0.94 0.95 0.97 0.98 0.99 1.00]
#define GHIBLI_CLOUD_BAND4_G 0.86 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.79 0.80 0.85 0.86 0.90 0.92 0.93 0.94 0.95 0.97 0.98 0.99 1.00]
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; de-obfuscating, reusing any part of it or reverse engineering is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.
#define GHIBLI_CLOUD_BAND4_B 0.94 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.79 0.80 0.85 0.86 0.90 0.92 0.93 0.94 0.95 0.97 0.98 0.99 1.00]
#define GHIBLI_CLOUD_BAND5_R 0.60 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.79 0.80 0.85 0.86 0.90 0.92 0.93 0.94 0.95 0.97 0.98 0.99 1.00]
#define GHIBLI_CLOUD_BAND5_G 0.79 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.79 0.80 0.85 0.86 0.90 0.92 0.93 0.94 0.95 0.97 0.98 0.99 1.00]
#define GHIBLI_CLOUD_BAND5_B 0.90 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.79 0.80 0.85 0.86 0.90 0.92 0.93 0.94 0.95 0.97 0.98 0.99 1.00]

#define CLOUD_SHADOWS_ENABLED
#ifdef CLOUDS_GHIBLI_ENABLED
#ifdef CLOUD_SHADOWS_ENABLED
#if GHIBLI_CLOUD_PERF_MODE != 3
#define _zwco3j1
#endif
#endif
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; redistributing or reusing any part of it is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. See LICENSE.txt.
#endif

#if defined(_zwco3j1) || defined(_iy7t50j)
#define _xysbwm0
#ifdef _zwco3j1
#define _12klm1m GHIBLI_CLOUD_SHADOW_STRENGTH
#else
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; modifying, de-obfuscating, creating derivative works or reusing any part of it is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. Details in LICENSE.txt.
#define _12klm1m VANILLA_CLOUD_SHADOW_STRENGTH
#endif
#endif
#endif
