/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/j3usxxpv1y.glsl"
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; creating derivative works or copying is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Details in LICENSE.txt.
#include "/rr9/42xwprqbx1.glsl"
#include "/rr9/4621j1h972.glsl"
#include "/rr9/i9knobfrhl.glsl"
#if ((defined(WATER_EDGE_OUTLINE) && WATER_EDGE_FOAM_STYLE == 1) || defined(BLOCK_TRACED_SHADOWS) || (COLORED_LIGHTING_MODE == 1 && defined(IRIS_FEATURE_COMPUTE_SHADERS)) || defined(_owayyrc)) && defined(IRIS_FEATURE_CUSTOM_IMAGES)
#extension GL_ARB_shader_image_load_store : require
#endif
#if defined(WATER_EDGE_OUTLINE) && WATER_EDGE_FOAM_STYLE == 1 && defined(IRIS_FEATURE_CUSTOM_IMAGES)
#define _kzl28hb
#endif
#define _phvjexg
#include "/rr9/ge4cb34kp0.glsl"
#include "/rr9/rlo9p4itwe.glsl"
#include "/rr9/0nsc8vsoxo.glsl"
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is confidential, proprietary work; de-obfuscating, copying or reverse engineering needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
#include "/rr9/bldb4py8i5.glsl"
#include "/rr9/0wmj7rotqz.glsl"
#include "/rr9/8webtbqewr.glsl"
#include "/rr9/pmsbbehveh.glsl"
#include "/rr9/6nxhvcuuy9.glsl"
#include "/rr9/gxone3mqat.glsl"
#include "/rr9/36vu26ovz4.glsl"
#define _wciv31c
#include "/rr9/0ei45l9rup.glsl"
#define _vuuzekz
#include "/rr9/hmw62ckpcm.glsl"
#include "/rr9/pt4tevzb0i.glsl"
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is closed source and under copyright; de-obfuscating or publishing is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.

#ifdef METAL_HIGHLIGHTS
#define _iolagkw _ipmcn3(int(mc_Entity.x))
#define _y45kzum float(_ipmcn3(int(mc_Entity.x)))
#else
#define _iolagkw int(mc_Entity.x)
#define _y45kzum mc_Entity.x
#endif
uniform mat4 shadowModelView;
uniform mat4 shadowModelViewInverse;
attribute vec4 mc_Entity;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; de-obfuscating or reusing any part of it is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. This binds automated tools and software agents as much as people. See LICENSE.txt.
attribute vec4 mc_midTexCoord;
attribute vec4 at_midBlock;
out vec2 _z7xvepo;
#ifdef _y44nu66

int _7bk4j1p;
int _e07k4gk;
float _k8gaemy;
float _41jjdpq;
flat out int _jnp4ogz;
#else
flat out int _7bk4j1p;
flat out int _e07k4gk;
flat out float _k8gaemy;
flat out float _41jjdpq;
#endif
// Caztoon beta 2.2 is the property of Cazfps. The code is confidential, proprietary work; decompiling, de-obfuscating or modifying is off limits unless Cazfps personally licensed it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Full terms: LICENSE.txt.
out float _2us2atj;
#ifdef ATMO_FOG_ENABLED
out float _3q3pjhn;
#endif
#ifdef _2afvqz3
#ifdef _y44nu66
float _i5knqx6;
#else
out float _i5knqx6;
#endif
#endif
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is confidential, proprietary work; copying, modifying or porting it to another pack is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Full terms: LICENSE.txt.
#if defined(_bmkjfdl) || defined(_y44nu66)

out vec3 _58k6kp8;
#endif
#ifdef _y44nu66

out vec3 _0l8jkwj;
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; selling, creating derivative works, reusing any part of it or de-obfuscating is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
#endif

void main() {
_z7xvepo = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
int _6dfy32 = _iolagkw;

bool _m8rz43 = _6dfy32 >= 10102 && _6dfy32 <= 10104;
if (_m8rz43) _6dfy32 -= 100;

if (_6dfy32 == 10202) _6dfy32 = 10002;
int _ko9cg2 = _6dfy32;
if (_6dfy32 == 10203) _6dfy32 = 10002;
if (_6dfy32 >= 10205 && _6dfy32 <= 10207) _6dfy32 -= 203;
bool _s4lxf7 = _6dfy32 == 20002 || _6dfy32 == 20003;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; de-obfuscating or copying is prohibited unless Cazfps has issued a licence for it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.
bool _20wa0u = _6dfy32 >= 10000 && !_s4lxf7;
int id = _20wa0u ? _6dfy32 - 10000 : 0;
_e07k4gk = _6dfy32;
_7bk4j1p = id;
vec3 _t2zyyw = normalize(gl_Normal);
vec3 _vk1nwl = abs(abs(at_midBlock.xyz) - vec3(32.0));
float _8awh52 = max(_vk1nwl.x, max(_vk1nwl.y, _vk1nwl.z));
_k8gaemy = id == 15 ? 1.0 - step(0.25, _8awh52) : 1.0;
_2us2atj = id == 15
? (1.0 - step(0.2, abs(_t2zyyw.y))) * (1.0 - step(0.98, max(abs(_t2zyyw.x), abs(_t2zyyw.z)))) : 0.0;
_41jjdpq = (id == 5 || id == 82) ? step(0.25, _8awh52) : 0.0;
vec3 _p3t2ci = (gl_ModelViewMatrix * gl_Vertex).xyz;
#if defined(_bmkjfdl) || defined(_y44nu66)
_58k6kp8 = (shadowModelViewInverse * vec4(_p3t2ci, 1.0)).xyz;
#endif
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is protected by copyright and not open source; selling or modifying is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. This binds automated tools and software agents as much as people. See LICENSE.txt.
#ifdef _y44nu66
_0l8jkwj = at_midBlock.xyz;
#endif
vec3 _rwd55t = (shadowModelViewInverse * vec4(_p3t2ci, 1.0)).xyz + cameraPosition;
#ifdef _66ncx11

_eokhxa(_iolagkw, (shadowModelViewInverse * vec4(_p3t2ci, 1.0)).xyz, _t2zyyw, at_midBlock.xyz);
#endif
#ifdef _12szmpt

_5ws8zz(_iolagkw, (shadowModelViewInverse * vec4(_p3t2ci, 1.0)).xyz, _t2zyyw, at_midBlock.xyz);
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is licensed for personal use only, not sold; copying, porting it to another pack or selling is not allowed without a licence issued by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. These terms apply whether the work is done by a person or by a program.
#endif
#ifdef _2afvqz3

_cfqft3(_iolagkw, (shadowModelViewInverse * vec4(_p3t2ci, 1.0)).xyz, at_midBlock.xyz);
_i5knqx6 = _l9oo0e(_iolagkw, at_midBlock.xyz);
#endif
#ifdef _23cancj

_pyoaym(_y45kzum, (shadowModelViewInverse * vec4(_p3t2ci, 1.0)).xyz, at_midBlock, _t2zyyw,
clamp(gl_MultiTexCoord1.x / 240.0, 0.0, 1.0));
#endif
bool _2juucr = _z7xvepo.y < mc_midTexCoord.y;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; decompiling or modifying is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says.
float _g43865 = clamp(gl_MultiTexCoord1.y / 240.0, 0.0, 1.0);

if (id == 201) {
vec3 _5mvurm = gl_Vertex.xyz + at_midBlock.xyz / 64.0;
vec3 _09dv7x = mix(vec3(1.0), sign(at_midBlock.xyz), step(vec3(0.001), abs(at_midBlock.xyz)));
vec3 _frkzfx = _5mvurm - _09dv7x * 0.5;
_rwd55t = (shadowModelViewInverse * gl_ModelViewMatrix * vec4(_frkzfx, 1.0)).xyz + cameraPosition;
} else if (_20wa0u && _92x48q(_6dfy32) && id != 5 && id != 82 && !_m8rz43) {
if (id != 15 || (_2us2atj > 0.5 && _2juucr))
_rwd55t = _oyj32b(_rwd55t, _2juucr, _g43865, _ko9cg2, at_midBlock.xyz);
}
#ifdef SWAYING_LANTERNS

if (_p22wip(_6dfy32)) _rwd55t = _3q6wr5(_rwd55t, at_midBlock.xyz);
#endif
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; publishing or modifying is off limits unless Cazfps personally licensed it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Automated tools, scripts and agents are bound by these terms too. Details in LICENSE.txt.
#ifdef ATMO_FOG_ENABLED
_3q3pjhn = _rwd55t.y - cameraPosition.y;
#endif

vec4 _pje07k = gl_ProjectionMatrix * shadowModelView * vec4(_rwd55t - cameraPosition, 1.0);
_pje07k.xyz = _n0grq3(_pje07k.xyz);
gl_Position = _pje07k;
#if !defined(_y44nu66) && !defined(_bmkjfdl)

bool _6ks8wp = id == 1 || id == 8;
#ifdef CARTOONY_SHADOWS
_6ks8wp = _6ks8wp || id == 2 || id == 3 || id == 4 || id == 19 || (id >= 60 && id <= 62);
#endif
if (_6ks8wp || _41jjdpq > 0.5 || _k8gaemy < 0.5
|| (id >= 121 && id <= 128) || (id >= 131 && id <= 138))
gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
#endif
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is closed source and under copyright; de-obfuscating, creating derivative works, decompiling or selling needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
#ifdef _y44nu66
_jnp4ogz = (_7bk4j1p & 1023) | (_e07k4gk >= 10000 ? 1024 : 0)
| (_k8gaemy > 0.5 ? 2048 : 0) | (_41jjdpq > 0.5 ? 4096 : 0);
#endif
}
