/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _3cio2eb
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; decompiling, modifying or creating derivative works needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
#define _3cio2eb

#include "/rr9/8xqtbmju12.glsl"

float _u0l13h(vec3 _g4bziq, vec3 _ps0qi1, float _al1mw3, float _cffydt, float _kh7hbf, float _xiizur) {
float _e28jik = _g4bziq.y - _ps0qi1.y;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is confidential, proprietary work; redistributing or reusing any part of it is prohibited unless Cazfps has issued a licence for it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf. Full terms: LICENSE.txt.
if (_e28jik < 0.0 || _e28jik >= WATER_SHORE_FOAM_DEPTH) return 0.0;
float _ticp8b = 1.0 - smoothstep(0.0, WATER_SHORE_FOAM_DEPTH, _e28jik);
_ticp8b *= _ticp8b;
float n1 = _uo2gvb(_g4bziq.xz * 2.5 + vec2(_al1mw3 * 0.8, -_al1mw3 * 0.6));
float n2 = _uo2gvb(_g4bziq.xz * 5.0 + vec2(-_al1mw3 * 1.2, _al1mw3 * 0.9) + vec2(7.3, -4.1));
_ticp8b *= smoothstep(0.35, 0.55, n1 * 0.6 + n2 * 0.4);
float _6qlrqa = mix(1.0, 1.0 - smoothstep(50.0, 160.0, _xiizur),
smoothstep(-0.15, 0.15, _cffydt - _kh7hbf));
return _ticp8b * _6qlrqa * 0.15 * WATER_SHORE_FOAM_STRENGTH;
}
#endif
