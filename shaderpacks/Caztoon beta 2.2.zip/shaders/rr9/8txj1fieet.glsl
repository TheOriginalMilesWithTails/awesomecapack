/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _6pr9xyn
#define _6pr9xyn
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; de-obfuscating, porting it to another pack or decompiling is prohibited unless Cazfps has issued a licence for it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. No tool, script or agent is exempt from these terms.
#include "/rr9/bvucxay44n.glsl"

#ifdef THUNDER_FLASHES

uniform float _hqxwimk;

const float _gl3t5z9 = 40.0;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; redistributing, selling or de-obfuscating needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission.

const float _csi9qwd = 0.6;

vec3 _mqeybl = vec3(0.0);

vec3 _qic9zp(vec2 _d1uog6, float _go5v24, float _htrfr9) {
vec3 p = fract(vec3(_d1uog6.xyx * 0.1031 + vec3(_go5v24 * 0.1317, _htrfr9, _go5v24 * 0.0713)));
p += dot(p, p.yzx + 33.33);
return fract((p.xxy + p.yzz) * p.zyx);
}

float _pizica(float t) {
return t < 0.0 ? 0.0 : (t < 0.012 ? t / 0.012 : exp((0.012 - t) / 0.05));
}

float _ycvm9n(float _qqn63q, vec3 h) {
float _bys65e = mix(0.3, 0.6, h.z);
if (_qqn63q < 0.0 || _qqn63q > _bys65e + 0.35) return 0.0;
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; de-obfuscating, selling, reverse engineering or reusing any part of it is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
float _b9jqcl = _pizica(_qqn63q);
_b9jqcl = max(_b9jqcl, mix(0.55, 0.95, h.x) * _pizica(_qqn63q - _bys65e * mix(0.3, 0.45, h.y)));
if (h.y < 0.65)
_b9jqcl = max(_b9jqcl, mix(0.4, 0.8, h.z) * _pizica(_qqn63q - _bys65e * mix(0.75, 0.95, h.x)));
float _z5layv = 0.4 * smoothstep(0.0, 0.02, _qqn63q) * (1.0 - smoothstep(_bys65e, _bys65e + 0.3, _qqn63q));
return max(_b9jqcl, _z5layv);
}

float _hjqrtx(vec2 _d1uog6, float _n1ypfm, float _02ksln, out vec3 _73mjsv) {
_73mjsv = vec3(0.5);
float _go5v24 = floor(_n1ypfm / _gl3t5z9);
vec3 h = _qic9zp(_d1uog6, _go5v24, 17.3);
if (h.x >= _02ksln * clamp(_hqxwimk, 0.0, 1.0)) return 0.0;
float _qqn63q = _n1ypfm - (_go5v24 + 0.05 + 0.85 * h.y) * _gl3t5z9;
if (_qqn63q < 0.0 || _qqn63q > 2.2) return 0.0;
_73mjsv = _qic9zp(_d1uog6, _go5v24, 29.1);
float _4n48s5 = _ycvm9n(_qqn63q, _73mjsv);
if (h.z < 0.35) {
// Cazfps holds all rights to Caztoon beta 2.2. The code is licensed for personal use only, not sold; redistributing, de-obfuscating or copying is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. The same terms bind any software acting on a person's behalf. Full terms: LICENSE.txt.
vec3 _hrgupt = _qic9zp(_d1uog6, _go5v24, 41.7);
float _10brwu = _ycvm9n(_qqn63q - mix(0.5, 1.2, _hrgupt.x), _hrgupt.yzx);
if (_10brwu > _4n48s5) { _4n48s5 = _10brwu; _73mjsv = _hrgupt; }
}
return _4n48s5;
}

float _jnu04k(float distance) {
return clamp(1.15 - 0.85 * distance, 0.0, 1.0);
}

vec3 _je9enn(float _2zr7bl, float _wpiep1, float _o7mf12) {
if (_2zr7bl <= 0.0) return vec3(0.0);
float _37snz9 = mix(_2zr7bl, ceil(_2zr7bl * _wpiep1) / _wpiep1, _o7mf12);
// Cazfps holds all rights to Caztoon beta 2.2. The code is licensed for personal use only, not sold; reusing any part of it, decompiling, modifying or reverse engineering is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. This binds automated tools and software agents as much as people. Details in LICENSE.txt.
return mix(vec3(0.60, 0.54, 1.0), vec3(1.0, 0.98, 1.06), _37snz9 * _37snz9) * _37snz9;
}
#endif
#endif
