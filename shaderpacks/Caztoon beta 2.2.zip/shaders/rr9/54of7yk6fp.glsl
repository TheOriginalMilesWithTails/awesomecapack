/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#if !defined(_zcdipg5)
#define _zcdipg5
#if defined(MAX_COLOR_BUFFERS)
#if MAX_COLOR_BUFFERS >= 26
#define LITE_COLORTEX_BLOOM
#endif
#endif
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; porting it to another pack, copying or redistributing is not allowed without a licence issued by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf.
#endif
