/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _ku7fspr
#define _ku7fspr

float _t93zl6(float _g43865) {
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; copying, redistributing, reverse engineering or reusing any part of it is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
return smoothstep(0.9004, 0.9043, _g43865);
}
#endif
