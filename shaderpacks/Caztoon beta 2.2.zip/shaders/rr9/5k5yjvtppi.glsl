/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _np0srgz
#define _np0srgz

#include "/rr9/licmy10q9z.glsl"
uniform sampler2D depthtex1;
#include "/rr9/54of7yk6fp.glsl"
#if defined(LITE_COLORTEX_BLOOM)
uniform sampler2D colortex31;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; redistributing or selling is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Details in LICENSE.txt.
#define _9a340fh colortex31
#elif defined(IRIS_FEATURE_CUSTOM_IMAGES) && defined(IRIS_FEATURE_COMPUTE_SHADERS)

uniform sampler2D liteSceneBehindSampler;
#define _9a340fh liteSceneBehindSampler
#else

#define _tef16l5
#endif

vec3 _znl4yu(vec3 _deg898n, vec3 _t2zyyw, float _3w3f3w, float _g43865) {
mat3 _e12sb2 = mat3(gbufferModelViewInverse);
if ((_e12sb2 * _t2zyyw).y < 0.5) return vec3(0.0);
ivec2 _btdiwo = ivec2(gl_FragCoord.xy);
float _e28jik = texelFetch(depthtex1, _btdiwo, 0).r;
if (_e28jik >= 1.0) return vec3(0.0);
vec2 uv = gl_FragCoord.xy / vec2(textureSize(depthtex1, 0));
vec4 _026d09 = inverse(gl_ProjectionMatrix) * vec4(vec3(uv, _e28jik) * 2.0 - 1.0, 1.0);
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; decompiling or copying is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. These terms apply whether the work is done by a person or by a program.
vec3 _848w36 = gbufferModelViewInverse[3].xyz + cameraPosition;
float _mfrjn7 = _d68abv(_e12sb2 * _deg898n + _848w36,
_e12sb2 * (_026d09.xyz / _026d09.w) + _848w36, _g43865);
if (_mfrjn7 <= 0.001) return vec3(0.0);
#if defined(_tef16l5)
return vec3(0.0);
#else
return texelFetch(_9a340fh, _btdiwo, 0).rgb * (_3w3f3w * _mfrjn7);
#endif
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; publishing or reusing any part of it is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
}
#endif
