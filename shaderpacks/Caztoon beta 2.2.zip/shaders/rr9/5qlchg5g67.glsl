/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _d8rutmi
#define _d8rutmi

float _5kb0mx(float _yjfvs5) {
return 1.0 - smoothstep(0.5146, 0.57, _yjfvs5);
}
float _g9bgxn(float _yjfvs5) {
return 1.0 - smoothstep(0.0146, 0.07, _yjfvs5);
}

float _7kgtmw(float _yjfvs5) {
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is proprietary and confidential; creating derivative works, decompiling, copying or redistributing is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none.
#if !defined(SHADOWS_ENABLED) || defined(_gcga0yx) || defined(NETHER_SHADER)
return 1.0;
#else
if (TWILIGHT_SHADOW_DARKENING <= 1.0) return 1.0;
#ifdef TERRAIN_LIGHTING_FRAME_READER
return max(terrainLightingFrame[3].w, 1.0);
#else
float a = fract(_yjfvs5);

float _i97qhjh = smoothstep(0.44, 0.46, a) * _5kb0mx(a);
float _146yqt9 = max(smoothstep(0.91, 0.96, a), _g9bgxn(a));
float _poam3sn = clamp(max(_146yqt9, _i97qhjh), 0.0, 1.0);
return mix(1.0, max(TWILIGHT_SHADOW_DARKENING, 1.0), _poam3sn);
#endif
#endif
}
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; creating derivative works, publishing or copying is off limits unless Cazfps personally licensed it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. These terms apply whether the work is done by a person or by a program.

float _z9s6tp(float _lg7zq5, float _hbs4jq,
float _v8rjdn, float _7ttdze, float _g43865) {
if (_lg7zq5 <= 1.0 || _v8rjdn <= 0.0) return 1.0;

float _hoq1e0 = clamp((1.0 - _hbs4jq) / max(_v8rjdn, 0.00001), 0.0, 1.0);
_hoq1e0 *= smoothstep(1.0 / 15.0, 2.0 / 15.0, clamp(_g43865, 0.0, 1.0));

float _d2z2cq = max(_hoq1e0, clamp(_7ttdze, 0.0, 1.0));
return mix(1.0, 1.0 / _lg7zq5, _d2z2cq);
}
#endif
