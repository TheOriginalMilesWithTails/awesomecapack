/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _g8l0d4k
#define _g8l0d4k
#include "/rr9/b45iuzztws.glsl"
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; reusing any part of it, decompiling, copying or selling is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. These terms apply whether the work is done by a person or by a program.

float _lnsu55(float _yjfvs5, vec3 _16jf7l, float _63m3ul) {
float _yrz32bz = fract(_yjfvs5) < 0.5 ? smoothstep(0.02, 0.12, _16jf7l.y) : 0.0;
return _yrz32bz * (1.0 - 0.8 * clamp(_63m3ul, 0.0, 1.0));
}

float _ksvfjb(int _omcfa9, float _qqz8tv, vec3 _qxk2jx) {
if (_omcfa9 == 10001 || _omcfa9 == 10039) return 0.0;
float _jokaec = max(SUNLIGHT_BRIGHTNESS * _qqz8tv, 0.0);
float _i8wimz = clamp(max(_qxk2jx.r, max(_qxk2jx.g, _qxk2jx.b)), 0.001, 1.0);
float _0j0vow = 1.0 - pow(1.0 - _i8wimz, 1.0 + _jokaec);
return max(_0j0vow / _i8wimz - 1.0, 0.0);
}
#endif
