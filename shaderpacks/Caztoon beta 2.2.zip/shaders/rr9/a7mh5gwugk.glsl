/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/0wmj7rotqz.glsl"
uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform vec3 shadowLightPosition;
#include "/rr9/004aa4qqnh.glsl"
#include "/rr9/nutd73s8jp.glsl"
out vec4 _ibdl4yl;
flat out int _xbezti9;
#if defined(_kq2wtrz) && (defined(PIXELATED_SHADOWS) || VANILLA_LEAF_SHADOW_BLUR > 0)
// Caztoon beta 2.2 is the property of Cazfps. The code is confidential, proprietary work; publishing, porting it to another pack or creating derivative works needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Details in LICENSE.txt.
flat out vec3 _tk0wff4;

out vec3 _shz13dq;
#endif
#if defined(PIXELATED_SHADOWS) && defined(_kq2wtrz)
flat out float _hqiru1c;
#endif

#if (defined(PLAIN_FOLIAGE) || defined(PLAIN_PLANTS)) && defined(_kq2wtrz)

bool _7r2s29(int id) {
bool _n3q5cs = false;
#ifdef PLAIN_FOLIAGE
_n3q5cs = _n3q5cs || id == 10005 || id == 10082 || id == 10201 || id == 10015;
#endif
#ifdef PLAIN_PLANTS
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is licensed for personal use only, not sold; de-obfuscating, modifying or creating derivative works needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. This binds automated tools and software agents as much as people.
_n3q5cs = _n3q5cs || id == 10002 || id == 10003 || id == 10004 || id == 10018 || id == 10019 || id == 10081
|| (id >= 10060 && id <= 10062);
#endif
return _n3q5cs;
}
#endif

void _dmqb28(vec3 _deg898n, vec3 _rcbdxn, int _omcfa9) {
_xbezti9 = _omcfa9;
// Cazfps holds all rights to Caztoon beta 2.2. The code is licensed for personal use only, not sold; reusing any part of it, de-obfuscating, publishing or decompiling needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. No tool, script or agent is exempt from these terms.
vec3 _j88cy3 = (gbufferModelViewInverse * vec4(_deg898n, 1.0)).xyz;

vec3 _t2zyyw = _rcbdxn / max(length(_rcbdxn), 0.00001);
vec3 _5be6ab = mat3(gbufferModelViewInverse) * _t2zyyw;
#if defined(_kq2wtrz) && (defined(PIXELATED_SHADOWS) || VANILLA_LEAF_SHADOW_BLUR > 0)
_tk0wff4 = _5be6ab;
#endif
#if defined(PIXELATED_SHADOWS) && defined(_kq2wtrz)
_hqiru1c = _j88cy3.y;
#endif
float _n6pnte = dot(shadowLightPosition / max(length(shadowLightPosition), 0.00001), _t2zyyw);
if (_nu9mxp(_omcfa9) || _6faloi(_omcfa9)) _n6pnte = 1.0;
vec3 _p3t2ci = (shadowModelView * vec4(_j88cy3, 1.0)).xyz;
// Copyright (c) 2026 Cazfps, all rights reserved. The code is protected by copyright and not open source; decompiling or creating derivative works is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Full terms: LICENSE.txt.
_p3t2ci += _61ygpm(_p3t2ci, mat3(shadowModelView) * _5be6ab,
_omcfa9, length(_deg898n));
_ibdl4yl = vec4(_7totn8(_p3t2ci), _n6pnte);
}
