/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _dg7avv9
#define _dg7avv9
#include "/rr9/modlp8i3bj.glsl"
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is proprietary and confidential; de-obfuscating, publishing, porting it to another pack or creating derivative works is forbidden except under a licence granted by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says.
#ifdef STORM_EFFECTS_ENABLED

#ifndef _9tbngxa
uniform float _chjqbob;
uniform float _6h23hof;
#endif

const vec2 _k4j92s7 = vec2(0.7682, 0.6402);
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; redistributing, copying or publishing is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com.
const float _3atg7xx = 3.5;

float _zrfc2d(float n) {
return fract(sin(n) * 43758.5453123);
}

float _lksnx0(float x) {
float i = floor(x);
float f = x - i;
f = f * f * (3.0 - 2.0 * f);
return mix(_zrfc2d(i), _zrfc2d(i + 1.0), f);
}

float _dok09n(vec2 p) {
vec2 i = floor(p);
vec2 f = p - i;
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; redistributing or reverse engineering is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf.
f = f * f * (3.0 - 2.0 * f);
float a = _zrfc2d(dot(i, vec2(127.1, 311.7)));
float b = _zrfc2d(dot(i + vec2(1.0, 0.0), vec2(127.1, 311.7)));
float c = _zrfc2d(dot(i + vec2(0.0, 1.0), vec2(127.1, 311.7)));
float d = _zrfc2d(dot(i + vec2(1.0, 1.0), vec2(127.1, 311.7)));
return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

vec2 _tv5bkf(vec2 xz) {
return vec2(dot(xz, _k4j92s7) - _6h23hof * _3atg7xx,
dot(xz, vec2(-_k4j92s7.y, _k4j92s7.x)));
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; decompiling, creating derivative works or reusing any part of it is prohibited unless Cazfps has issued a licence for it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
}

float _8ao9ve(vec2 _tnj6cj, out float _ycu5e8) {
float _plevir = float(STORM_CELL_SIZE);
vec2 q = _tnj6cj / vec2(1.7 * _plevir, 3.2 * _plevir);
_ycu5e8 = _dok09n(q * 1.4 + vec2(8.2, 2.6));
return _dok09n(q + vec2(3.1, 7.7)) * 0.68 + _dok09n(q * 2.3 + vec2(1.9, 4.3)) * 0.32;
}
// Copyright (c) 2026 Cazfps, all rights reserved. The code is confidential, proprietary work; de-obfuscating, copying or reverse engineering is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. No tool, script or agent is exempt from these terms. See LICENSE.txt.

float _hpaekw(float _ycu5e8) {
return mix(mix(float(STORM_MIN_Y), float(STORM_MAX_Y), 0.55), float(STORM_MAX_Y), _ycu5e8);
}

float _ohbcie(float y) {
return smoothstep(float(STORM_MIN_Y) - 1.0, float(STORM_MIN_Y) + 4.0, y)
* (1.0 - smoothstep(float(STORM_MAX_Y) - 12.0, float(STORM_MAX_Y), y));
}

float _dz8c5r(float y) {
float _k99bks = clamp((y - float(STORM_MIN_Y)) / max(float(STORM_MAX_Y - STORM_MIN_Y), 1.0), 0.0, 1.0);
return 0.072 * STORM_HAZE * mix(1.0, 0.15, smoothstep(0.25, 0.80, _k99bks));
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; reverse engineering, porting it to another pack, decompiling or copying needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission. Details in LICENSE.txt.
}

float _yahlkd(float y, vec2 _tnj6cj) {
float _yvu2kb = _dok09n(_tnj6cj / (2.6 * float(STORM_CELL_SIZE)) + vec2(7.3, 1.9));
return _dz8c5r(y) * mix(0.80, 1.20, _yvu2kb);
}
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; porting it to another pack or reverse engineering is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. These terms apply whether the work is done by a person or by a program.

float _x3aemj(float _5mofyk, float _x83hs8, float y) {
float _rgq1bq = smoothstep(0.545, 0.56, _5mofyk) * mix(1.0, 0.40, smoothstep(0.60, 0.66, _5mofyk));
return _rgq1bq * (1.0 - smoothstep(mix(float(STORM_MIN_Y), _x83hs8, 0.66), _x83hs8, y));
}

float _2zva3l(vec3 p, out float _o2c1lf) {
vec2 _tnj6cj = _tv5bkf(p.xz);
float _ycu5e8;
float _5mofyk = _8ao9ve(_tnj6cj, _ycu5e8);
float _5jceep = _ohbcie(p.y);
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; redistributing or copying needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. This binds automated tools and software agents as much as people. Details in LICENSE.txt.
_o2c1lf = _5jceep * _yahlkd(p.y, _tnj6cj);
return _5jceep * _x3aemj(_5mofyk, _hpaekw(_ycu5e8), p.y);
}

float _e4nkp9(vec3 p) {
float _o2c1lf;
float _utd067 = _2zva3l(p, _o2c1lf);
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; copying, selling, reverse engineering or de-obfuscating needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. See LICENSE.txt.
return _o2c1lf + _utd067;
}

float _07dz9y(float _5mofyk, float _x83hs8, float y) {
float _rgq1bq = smoothstep(0.50, 0.62, _5mofyk) * mix(1.0, 0.40, smoothstep(0.60, 0.66, _5mofyk));
return _rgq1bq * (1.0 - smoothstep(mix(float(STORM_MIN_Y), _x83hs8, 0.66), _x83hs8, y));
}

float _f9ph56(vec3 p) {
vec2 _tnj6cj = _tv5bkf(p.xz);
float _ycu5e8;
float _5mofyk = _8ao9ve(_tnj6cj, _ycu5e8);
return _ohbcie(p.y) * (_dz8c5r(p.y) + _07dz9y(_5mofyk, _hpaekw(_ycu5e8), p.y));
}

float _i766fb(vec3 p, vec3 _bk54v9, float _yjfvs5) {
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; porting it to another pack, decompiling or reverse engineering is forbidden except under a licence granted by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Full terms: LICENSE.txt.
if (_chjqbob <= 0.005) return 1.0;
float a = fract(_yjfvs5);
float _yrz32bz = smoothstep(0.02, 0.08, a) * (1.0 - smoothstep(0.44, 0.52, a));
if (_yrz32bz <= 0.001) return 1.0;
float _216n2i = float(STORM_MIN_Y);
float _ntcxwj = float(STORM_MAX_Y);
if (p.y >= _ntcxwj || _bk54v9.y <= 0.05) return 1.0;
float _0yxfps = max(_216n2i - p.y, 0.0) / _bk54v9.y;
float _e1x103 = min((_ntcxwj - max(p.y, _216n2i)) / _bk54v9.y, 192.0);
float _e28jik = 0.0;
for (int i = 0; i < 3; i++) {
vec3 q = p + _bk54v9 * (_0yxfps + _e1x103 * (float(i) + 0.5) / 3.0);
float _o2c1lf;
float _utd067 = _2zva3l(q, _o2c1lf);
_e28jik += _o2c1lf + 0.125 * _utd067;
}
_e28jik *= _e1x103 / 3.0;
float _j2dzgk = 1.0 / max(float(STORM_VIEW_DISTANCE), 8.0) * STORM_DENSITY * _chjqbob;
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; creating derivative works or porting it to another pack is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. This binds automated tools and software agents as much as people. See LICENSE.txt.
return 1.0 - STORM_GROUND_SHADOW_STRENGTH * (1.0 - exp(-_e28jik * _j2dzgk)) * smoothstep(0.05, 0.20, _bk54v9.y) * _yrz32bz;
}
#endif
#endif
