/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _an9tpxn
#define _an9tpxn
#ifdef _mv74nhn
// Copyright (c) 2026 Cazfps, all rights reserved. The code is confidential, proprietary work; reusing any part of it, de-obfuscating or redistributing is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.

uniform sampler2D caztoonTerrainShadow;
uniform int caztoonTerrainShadowEnabled;
uniform vec4 caztoonTerrainShadowAxes;
uniform vec4 caztoonTerrainShadowGrid;
uniform vec4 caztoonTerrainShadowLight;
uniform float caztoonTerrainShadowCameraY;

float _sse41v(vec3 _azccps) {
if (caztoonTerrainShadowEnabled == 0 || TERRAIN_SHADOW_STRENGTH <= 0.0) return 1.0;
float n = caztoonTerrainShadowGrid.w;

if (!(n > 0.0) || !(caztoonTerrainShadowGrid.z > 0.0)) return 1.0;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; modifying, redistributing or porting it to another pack is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
vec2 _62eilz = _azccps.xz;
vec2 _a1pavp = caztoonTerrainShadowGrid.xy
+ vec2(dot(_62eilz, caztoonTerrainShadowAxes.xy), dot(_62eilz, caztoonTerrainShadowAxes.zw)) / caztoonTerrainShadowGrid.z;
float _ticp8b = min(min(_a1pavp.x, n - _a1pavp.x), min(_a1pavp.y, n - _a1pavp.y));
float _6qlrqa = clamp((_ticp8b - 2.0) / 30.0, 0.0, 1.0);
if (_6qlrqa <= 0.0) return 1.0;
vec4 t = texture(caztoonTerrainShadow, _a1pavp / n);
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; porting it to another pack, copying or reverse engineering is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.
bool near = length(_62eilz) < caztoonTerrainShadowLight.w;
float _y89fz2 = near ? t.y : t.x;
float _1hwiy3 = near ? t.w : t.z;
vec3 l = caztoonTerrainShadowLight.xyz;
float _0c3yr6 = l.y / max(length(l.xz), 1e-4);
float _2bl5io = 1.0 + caztoonTerrainShadowGrid.z * _0c3yr6;

float _u66mi4 = max(1.0, _1hwiy3 * 0.0175 * TERRAIN_SHADOW_SOFTNESS);
float shadow = smoothstep(-_u66mi4, _u66mi4, _y89fz2 - _2bl5io - (caztoonTerrainShadowCameraY + _azccps.y));

shadow = shadow >= 0.0 ? shadow : 0.0;
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; selling or decompiling is off limits unless Cazfps personally licensed it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms. See LICENSE.txt.
return 1.0 - shadow * _6qlrqa * clamp(TERRAIN_SHADOW_STRENGTH, 0.0, 1.0);
}
#endif
#endif
