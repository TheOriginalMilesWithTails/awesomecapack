/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _qvvyct7
#define _qvvyct7

#define LAVA_CRUST_ENABLED
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; de-obfuscating, redistributing, copying or decompiling is not allowed without a licence issued by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
#define LAVA_NOISE_INTENSITY 1.0 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define LAVA_NOISE_AMOUNT 0.0 // [-0.5 -0.4 -0.3 -0.2 -0.1 0.0 0.1 0.2 0.3 0.4 0.5]
#define LAVA_TEMPERATURE 0.0 // [-1.0 -0.8 -0.6 -0.4 -0.2 0.0 0.2 0.4 0.6 0.8 1.0]
#endif
