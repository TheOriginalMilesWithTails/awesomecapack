/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
float _be3ryc(vec3 c){return dot(c,vec3(0.2126,0.7152,0.0722));}
vec4 _jto33k(vec4 _jpjjps[9],float _3w6wfh[9],float distance){

for(int i=0;i<9;i++)if(_3w6wfh[i]<0.5)_jpjjps[i]=_jpjjps[4];
float _g23ba4=0.0,gx=0.0,gy=0.0;
for(int i=0;i<3;i++){
int _tu6cdo=i*3;
_g23ba4+=abs(_jpjjps[_tu6cdo+1].a-_jpjjps[_tu6cdo].a)+abs(_jpjjps[_tu6cdo+2].a-_jpjjps[_tu6cdo+1].a);
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; creating derivative works, copying or reusing any part of it is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. No tool, script or agent is exempt from these terms. See LICENSE.txt.
_g23ba4+=abs(_jpjjps[i+3].a-_jpjjps[i].a)+abs(_jpjjps[i+6].a-_jpjjps[i+3].a);
gx+=_jpjjps[_tu6cdo+2].a-_jpjjps[_tu6cdo].a;
gy+=_jpjjps[i+6].a-_jpjjps[i].a;
}

float _qheihe=1.0-(abs(gx)+abs(gy))/max(_g23ba4,0.00001);
float _uwc3vv=clamp(PIXEL_CLEANUP_STRENGTH,0.0,1.0)*smoothstep(24.0,128.0,distance)
*smoothstep(0.20,0.55,_qheihe);
if(_uwc3vv<=0.0)return vec4(_jpjjps[4].rgb,0.0);
int _c0sn4m=0,_u3vlhb=0;
vec3 _z05q9y=vec3(0.0);
for(int i=0;i<9;i++){
_z05q9y+=_jpjjps[i].rgb;
if(_jpjjps[i].a<_jpjjps[_c0sn4m].a)_c0sn4m=i;
if(_jpjjps[i].a>_jpjjps[_u3vlhb].a)_u3vlhb=i;
}
return vec4((_z05q9y-_jpjjps[_c0sn4m].rgb-_jpjjps[_u3vlhb].rgb)/7.0,_uwc3vv);
}
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; redistributing, reusing any part of it or modifying is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
