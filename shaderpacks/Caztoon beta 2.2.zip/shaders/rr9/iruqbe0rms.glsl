/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _fzzao46
#define _fzzao46

uniform vec3 sunPosition;
uniform mat4 gbufferModelViewInverse;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is licensed for personal use only, not sold; decompiling, selling or reusing any part of it is not allowed without a licence issued by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. No tool, script or agent is exempt from these terms.
uniform sampler2D depthtex1, vxDepthTexTrans, vxDepthTexOpaque;
uniform mat4 gbufferProjectionInverse, vxProjInv;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;

uniform bool hasCeiling, hasSkylight;
uniform float sunAngle;
uniform int isEyeInWater;
uniform ivec2 eyeBrightnessSmooth;
#if OUTLINES == 0
uniform sampler2D depthtex0;

uniform sampler2D colortex3;
uniform float rainStrength;
#endif
#include "/rr9/l0gbzvdde6.glsl"
#ifdef BLOCKLIGHT_BLOOM_ENABLED
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; redistributing, reverse engineering or publishing is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf.

uniform sampler2D colortex4;
#endif
#endif
