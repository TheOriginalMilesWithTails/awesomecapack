/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _8uzhi2x
#define _8uzhi2x

vec3 _v6lnhz(float _7f7dj3) {
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; de-obfuscating, redistributing, creating derivative works or publishing is prohibited unless Cazfps has issued a licence for it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. This binds automated tools and software agents as much as people. See LICENSE.txt.
vec3 _rny47c = vec3(CLOUD_RAIN_BODY_R, CLOUD_RAIN_BODY_G, CLOUD_RAIN_BODY_B);
vec3 shadow = vec3(CLOUD_RAIN_SHADOW_R, CLOUD_RAIN_SHADOW_G, CLOUD_RAIN_SHADOW_B);
vec3 _cbz38f = mix(_rny47c, vec3(0.80, 0.83, 0.92), 0.45);

vec3 _10nn03 = mix(_cbz38f, vec3(0.80, 0.83, 0.94), CLOUD_RAIN_HIGHLIGHT);
float s = clamp(_7f7dj3, 0.0, 1.0);
if (s < 0.18) return mix(_10nn03, _cbz38f, s / 0.18);
if (s < 0.55) return mix(_cbz38f, _rny47c, (s - 0.18) / 0.37);
return mix(_rny47c, shadow, (s - 0.55) / 0.45);
}
#endif
