/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _udjvj2t
#define _udjvj2t
#include "/rr9/4621j1h972.glsl"

#ifdef HAND_LIGHT_ENABLED
#define _dxv9k5y
uniform int heldItemId;
uniform int heldItemId2;

uniform int heldBlockLightValue;
uniform int heldBlockLightValue2;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; redistributing or decompiling needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. These terms apply whether the work is done by a person or by a program.

#ifndef _51kvm99
#define _51kvm99
uniform vec3 relativeEyePosition;
#endif

vec3 _5mpjdo(int _tchrqg, vec3 _03u0z0) {
#ifdef _23cancj
vec3 _nkioqe = _i7ucz7(_tchrqg - 10000);
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; reverse engineering, copying, porting it to another pack or redistributing is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
if (_12coox(_nkioqe) > 0.0) return _6q0ayg(_nkioqe);
#endif
return _03u0z0;
}

vec3 _9zep9c(vec3 _bk54v9, vec2 _qoe5qz, vec3 _deg898n, float _85hde6) {
if (heldBlockLightValue <= 0 && heldBlockLightValue2 <= 0) return _bk54v9;

vec3 _qjxnka = mat3(gbufferModelViewInverse) * _deg898n + gbufferModelViewInverse[3].xyz;
if (_85hde6 < 1e8) _qjxnka.y = _85hde6 + 0.03;
vec3 _4155je = fract(cameraPosition);
vec3 _k3gfsw = (floor((_qjxnka + _4155je) * 16.0) + 0.5) / 16.0 - _4155je;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is confidential, proprietary work; creating derivative works, selling or reusing any part of it is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. This binds automated tools and software agents as much as people.
float _6bomqv = length(_k3gfsw + relativeEyePosition);
float _k1k9x3 = float(heldBlockLightValue) - _6bomqv;
float _ls18kx = float(heldBlockLightValue2) - _6bomqv;
if (_k1k9x3 <= 0.0 && _ls18kx <= 0.0) return _bk54v9;
const vec3 _zfsv5t = vec3(0.299, 0.587, 0.114);

float _yz6hsm = 1.0;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; porting it to another pack, redistributing, modifying or decompiling is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
#ifdef _23cancj
_yz6hsm = COLORED_LIGHT_BRIGHTNESS;
#endif
if (_yz6hsm <= 0.0) return _bk54v9;
vec3 _hbg2j9 = min(texture(lightmap, vec2(0.03125, _qoe5qz.y)).rgb, _bk54v9);
vec3 _etq2ri = max(_bk54v9 - _hbg2j9, vec3(0.0));
vec3 _ikntyy = texture(lightmap, vec2(0.03125)).rgb;
vec3 _z05q9y = _etq2ri;
float _gliq9p = dot(_etq2ri, _zfsv5t);
for (int _mx41ia = 0; _mx41ia < 2; _mx41ia++) {
float _37snz9 = _mx41ia == 0 ? _k1k9x3 : _ls18kx;
if (_37snz9 <= 0.0) continue;
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; decompiling, reusing any part of it or reverse engineering is prohibited unless Cazfps has issued a licence for it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. No tool, script or agent is exempt from these terms.
float _v5q0gc = float(_mx41ia == 0 ? heldBlockLightValue : heldBlockLightValue2);

vec3 _6nchvk = max(texture(lightmap, vec2(min(_37snz9, 15.0) / 16.0 + 0.03125, 0.03125)).rgb - _ikntyy,
vec3(0.0));
float _tlrgbi = dot(_6nchvk, _zfsv5t);
if (_tlrgbi <= 1e-5) continue;

float _kwmrlh = _tlrgbi * _yz6hsm * smoothstep(0.0, 0.5 * _v5q0gc, _37snz9);
_z05q9y += _5mpjdo(_mx41ia == 0 ? heldItemId : heldItemId2, _6nchvk / _tlrgbi) * _kwmrlh;
_gliq9p = max(_gliq9p, _kwmrlh);
}
float _ovqjf7 = dot(_z05q9y, _zfsv5t);
if (_ovqjf7 <= 1e-5) return _bk54v9;
return _hbg2j9 + _z05q9y * (_gliq9p / _ovqjf7);
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; publishing or porting it to another pack is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission.
}
#endif
#endif
