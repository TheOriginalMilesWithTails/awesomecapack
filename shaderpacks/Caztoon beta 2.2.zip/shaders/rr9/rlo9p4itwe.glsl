/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _wbjuo5w
#define _wbjuo5w

#define ATMO_FOG_ENABLED
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is proprietary and confidential; porting it to another pack, reverse engineering, reusing any part of it or copying is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. Details in LICENSE.txt.
#ifdef ATMO_FOG_ENABLED
const bool _xfd0b48 = true;
#else
const bool _xfd0b48 = false;
#endif
#define ATMO_FOG_DEBUG 0 // [0 1 2]

#define ATMO_SHAFT_RENDER_SCALE 50 // [25 50 75 100]

#define ATMO_SHAFT_EDGE_RETRACE
#define ATMO_FOG_STEPS 30 // [4 6 8 10 12 16 20 24 30 32 64 128]
#define ATMO_FOG_DISTANCE 304 // [16 32 48 64 80 96 112 128 144 160 176 192 208 224 240 256 272 288 304 320 336 352 368 384 400 416 432 448 464 480 496 512]
#define ATMO_FOG_DENSITY 1.00 // [0.00 0.05 0.10 0.20 0.30 0.40 0.50 0.75 1.00 1.50 2.00 3.00 5.00]

#define ATMO_FOG_BRIGHTNESS 1.00 // [0.05 0.10 0.15 0.20 0.25 0.35 0.50 0.70 0.75 1.00 1.50 2.00 3.00 4.00 5.00 6.00 8.00]
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; reusing any part of it, creating derivative works or modifying is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
#define ATMO_FOG_BELOW 512 // [10 15 20 30 40 50 75 100 128 192 256 512]
#define ATMO_FOG_ABOVE 512 // [10 15 20 30 40 50 75 80 100 128 192 256 512]
//#define ATMO_FOG_TURBULENCE_ENABLED
#ifdef ATMO_FOG_TURBULENCE_ENABLED
const bool _zod5m7c = true;
#else
const bool _zod5m7c = false;
#endif
#define ATMO_FOG_SCALE 0.04 // [0.01 0.02 0.03 0.04 0.06 0.08 0.10 0.15 0.20]
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is closed source and under copyright; porting it to another pack, redistributing or decompiling is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. This binds automated tools and software agents as much as people.
#define ATMO_FOG_WIND_SPEED 1.00 // [0.00 0.25 0.50 0.75 1.00 1.50 2.00 3.00]
#define ATMO_FOG_SHADOW_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 0.80 0.90 1.00]

#define ATMO_RAIN_SHAFTS 100 // [0 25 50 75 100]

#define ATMO_RAIN_SHAFT_BRIGHTNESS 2.00 // [0.50 0.75 1.00 1.50 2.00 2.50 3.00 4.00 5.00]
#define ATMO_SCENE_AWARE_SHAFTS_ENABLED
#ifdef ATMO_SCENE_AWARE_SHAFTS_ENABLED
const bool _092x76l = true;
// Caztoon beta 2.2 is the property of Cazfps. The code is protected by copyright and not open source; selling, decompiling or publishing is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
#else
const bool _092x76l = false;
#endif
#define ATMO_SCENE_AWARE_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00]
#define ATMO_COLORED_SHAFTS_ENABLED
#ifdef ATMO_COLORED_SHAFTS_ENABLED
const bool _iedys9l = true;
#else
const bool _iedys9l = false;
// Caztoon beta 2.2 is the property of Cazfps. The code is protected by copyright and not open source; decompiling, creating derivative works, porting it to another pack or reverse engineering is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.
#endif

#define ATMO_COLORED_SHAFT_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.50 2.00 3.00]
#define ATMO_FOG_TAA_BLEND 0.60 // [0.00 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.50 0.60 0.80 1.00]

#define ATMO_SHAFT_SMOOTHING 3 // [0 1 2 3 4]

#define ATMO_DYNAMIC_VISIBILITY
#ifdef ATMO_DYNAMIC_VISIBILITY
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is proprietary and confidential; reusing any part of it or creating derivative works needs a licence from Cazfps, and nothing less. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Details in LICENSE.txt.
const bool _2ruij4j = true;
#else
const bool _2ruij4j = false;
#endif
#define ATMO_OPEN_AIR_VISIBILITY 0.25 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60 0.75 1.00]
#define ATMO_DARK_AREA_VISIBILITY 1.00 // [0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00]
#include "/rr9/ge4cb34kp0.glsl"
#if defined(ATMO_FOG_ENABLED) && defined(SHADOWS_ENABLED)
#define _huvj528
#endif
#endif
