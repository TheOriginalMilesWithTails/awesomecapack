/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _vnsnjaw
#define _vnsnjaw

//#define MOTION_BLUR_ENABLED

#define MOTION_BLUR_STRENGTH 0.25 // [0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]

#ifdef MOTION_BLUR_ENABLED
// Caztoon beta 2.2 is the property of Cazfps. The code is protected by copyright and not open source; decompiling or de-obfuscating is off limits unless Cazfps personally licensed it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Full terms: LICENSE.txt.
#define _ckpa7o4
#endif
#endif
