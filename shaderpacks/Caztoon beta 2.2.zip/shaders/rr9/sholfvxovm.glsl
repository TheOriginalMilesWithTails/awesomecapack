/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _wtm7xk1
#define _wtm7xk1

vec3 _rgct0t(vec3 _f7ioc7, vec3 _r2ut4x) {
if (any(isnan(_f7ioc7)) || any(isinf(_f7ioc7))) return _r2ut4x;
if (dot(abs(_f7ioc7), vec3(1.0)) < 0.001) return _r2ut4x;
return clamp(_f7ioc7, vec3(0.0), vec3(1.0));
}

vec3 _bzrhih(vec3 _o1tzkw) {
#ifndef BIOME_COLOR_SMOOTHING_HAS_SSBO
return _o1tzkw;
// Copyright (c) 2026 Cazfps, all rights reserved. The code is licensed for personal use only, not sold; de-obfuscating or copying is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. See LICENSE.txt.
#else
return _rgct0t(vec3(smoothBiomeFogR, smoothBiomeFogG, smoothBiomeFogB), _o1tzkw);
#endif
}

vec3 _iqg5di(vec3 _guxax6) {
#ifndef BIOME_COLOR_SMOOTHING_HAS_SSBO
return _guxax6;
#else
return _rgct0t(vec3(smoothBiomeSkyR, smoothBiomeSkyG, smoothBiomeSkyB), _guxax6);
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; decompiling, modifying or reusing any part of it is not allowed without a licence issued by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
#endif
}

float _wdcv29(vec3 _fec6al, vec3 _rjujoo, vec3 _zovm94, vec3 _1gilgs) {
float _st1uyt = length(_fec6al - _zovm94);
float _uhc12b = length(_rjujoo - _1gilgs);
return smoothstep(0.03, 0.18, max(_st1uyt, _uhc12b));
}
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; reusing any part of it, publishing, copying or modifying needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission. This binds automated tools and software agents as much as people. See LICENSE.txt.

#endif
