/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _ac5qjph
#define _ac5qjph

uniform int fogMode;
uniform float fogDensity;
uniform vec3 fogColor;
uniform float far;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is licensed for personal use only, not sold; de-obfuscating, reusing any part of it or selling is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.
uniform float alphaTestRef;

vec3 _03z8n8(vec3 _0vh339n, float distance) {
if (fogMode == 0) return _0vh339n;
float _1r3wwx;
if (fogMode == 2049) {
float x = distance * fogDensity;
_1r3wwx = exp(-x * x);
} else {
float _0yxfps = far - clamp(far / 10.0, 4.0, 64.0);
_1r3wwx = (far - distance) / (far - _0yxfps);
}
_1r3wwx = clamp(_1r3wwx, 0.0, 1.0);
return mix(fogColor, _0vh339n, _1r3wwx);
}

bool _xwdmuw(float _cw7o15) {
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; decompiling, reverse engineering, copying or selling needs a licence from Cazfps, and nothing less. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. No tool, script or agent is exempt from these terms.
return alphaTestRef > 0.0 && !(_cw7o15 > alphaTestRef);
}
#endif
