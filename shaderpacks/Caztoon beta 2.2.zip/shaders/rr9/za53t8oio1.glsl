/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _dzkdz1e
#define _dzkdz1e

#ifndef _9tbngxa
uniform float _5afb9wt;
#endif

float _736smo() {
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is licensed for personal use only, not sold; creating derivative works or reusing any part of it is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
float _c8949q = clamp(_5afb9wt, 0.0, 1.0);
return _c8949q < 0.0001 ? 0.0 : _c8949q;
}
#endif
