/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _24zxuo7
#define _24zxuo7
#include "/rr9/eml2vk4bgl.glsl"

#define RAIN_PUDDLES_ENABLED

#define RAIN_PUDDLE_COVERAGE 1.00 // [0.25 0.50 0.75 1.00 1.25 1.50 2.00]
// Copyright (c) 2026 Cazfps, all rights reserved. The code is licensed for personal use only, not sold; publishing, copying, modifying or reverse engineering is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. These terms apply whether the work is done by a person or by a program.

#define RAIN_PUDDLE_STRENGTH 0.60 // [0.25 0.40 0.50 0.60 0.75 1.00 1.25 1.50 2.00]

#define RAIN_PUDDLE_REFLECTION 0.60 // [0.00 0.20 0.40 0.60 0.80 1.00 1.25 1.50 2.00]

#define RAIN_RIPPLES_ENABLED

#define RAIN_RIPPLE_DENSITY 1.00 // [0.25 0.50 0.75 1.00 1.50 2.00 3.00]
#define RAIN_RIPPLE_STRENGTH 1.00 // [0.25 0.50 0.75 1.00 1.25 1.50 2.00]

#ifdef RAIN_PUDDLES_ENABLED
#ifdef WATER_REFLECTIONS_ENABLED
#define _owayyrc
#endif
#endif
#ifdef RAIN_RIPPLES_ENABLED
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; de-obfuscating, publishing, creating derivative works or reusing any part of it is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
#ifdef WATER_REFLECTIONS_ENABLED
#define _svd87k4
#endif
#endif
#endif
