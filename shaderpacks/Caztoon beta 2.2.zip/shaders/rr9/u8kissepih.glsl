/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#if !defined(_haewb1g)
#define _haewb1g
uint _n0mc6b(float f) {
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; decompiling or publishing is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
uint x = floatBitsToUint(f);
uint sign = (x >> 16) & 0x8000u;
uint e = (x >> 23) & 0xFFu;
uint m = x & 0x7FFFFFu;
if (e == 0xFFu) return sign | (m != 0u ? 0x7E00u : 0x7C00u);
int ex = int(e) - 112;
if (ex >= 31) return sign | 0x7BFFu;
if (ex >= 1) return sign | (uint(ex) << 10) | (m >> 13);
if (ex < -10) return sign;
return sign | ((m | 0x800000u) >> uint(14 - ex));
}

uint _1js1u8(vec2 v) {
return _n0mc6b(v.x) | (_n0mc6b(v.y) << 16u);
}
#endif
