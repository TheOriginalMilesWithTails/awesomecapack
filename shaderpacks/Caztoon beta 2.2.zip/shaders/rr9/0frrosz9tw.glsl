/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _t6zxfo1
#define _t6zxfo1
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is closed source and under copyright; copying or publishing is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
#include "/rr9/rlo9p4itwe.glsl"

//#define MOTION_SMOOTHING_ENABLED
#define MOTION_SMOOTHING_STRENGTH 0.80 // [0.50 0.60 0.70 0.80 0.85 0.90]

#define STILL_SMOOTHING_STRENGTH 0.00 // [0.00 0.25 0.50 0.75 1.00]

//#define DISTANT_TEXTURE_FILTER

//#define STRAY_PIXEL_CLEANUP
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; reverse engineering or porting it to another pack is forbidden except under a licence granted by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.

//#define FLAT_FAR_SHADOWS
#define FLAT_FAR_SHADOW_PIXELS 8 // [4 6 8 12 16 24 32]

#define FLAT_FAR_FACE_SHADING 0.50 // [0.00 0.25 0.35 0.50 0.65 0.75 1.00]

#define THIN_FACE_LIGHT

#define STEADY_SHADOWS

//#define FAR_FACE_AVERAGE
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; modifying or copying is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too.
//#define PIXEL_CLEANUP_ENABLED
#define PIXEL_CLEANUP_STRENGTH 1.00 // [0.25 0.50 0.75 1.00]

#if defined(MOTION_SMOOTHING_ENABLED) || defined(PIXEL_CLEANUP_ENABLED) || defined(STRAY_PIXEL_CLEANUP) || defined(_huvj528)
#define _stlozh9
#endif
#endif
