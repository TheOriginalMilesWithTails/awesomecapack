/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _y9g7f9c
#define _y9g7f9c
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; de-obfuscating or selling is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.

#include "/rr9/a4jzpp7xwj.glsl"

float _v5bkio() {
#ifdef _k4pj49b
return clamp(rainStrength, 0.0, 1.0);
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; porting it to another pack, selling or de-obfuscating is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. This binds automated tools and software agents as much as people. Full terms: LICENSE.txt.
#else
return clamp(texelFetch(colortex14, ivec2(7, 0), 0).b, 0.0, 1.0);
#endif
}

float _he0p2x(float _t2zyyw, float _63m3ul) {
float _6xizlb = _v5bkio();
return _6xizlb > 0.0 ? mix(_t2zyyw, _63m3ul, _6xizlb) : _t2zyyw;
}

#define _yj42341(NORMAL, RAIN, SAME_BELOW) \
(float(RAIN) < (SAME_BELOW) ? float(NORMAL) : _he0p2x(float(NORMAL), float(RAIN)))
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; reverse engineering, modifying, redistributing or decompiling is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Full terms: LICENSE.txt.
#define _vjldvop _yj42341(HAZE_FOG_DENSITY, HAZE_RAIN_DENSITY, -0.5)
#define _yufg0r2 _yj42341(HAZE_FOG_BRIGHTNESS, HAZE_RAIN_BRIGHTNESS, -0.5)
#define _lpsk1gz _yj42341(HAZE_FOG_ABOVE_DENSITY, HAZE_RAIN_ABOVE_DENSITY, -0.5)
#define _to6kcue _yj42341(HAZE_FOG_ABOVE_BRIGHTNESS, HAZE_RAIN_ABOVE_BRIGHTNESS, -0.5)
#define _ry4gqxb _yj42341(HAZE_FOG_DIST_START, HAZE_RAIN_DIST_START, -0.5)
#define _dorz3b5 _yj42341(HAZE_FOG_DIST_END, HAZE_RAIN_DIST_END, -0.5)
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; reverse engineering or de-obfuscating is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
#define _j44hebv _yj42341(HAZE_FOG_MIN_Y, HAZE_RAIN_MIN_Y, -9000.0)
#define _rsniv73 _yj42341(HAZE_FOG_MAX_Y, HAZE_RAIN_MAX_Y, -9000.0)
#define _cfazdr4 _yj42341(HAZE_FOG_EDGE_FADE, HAZE_RAIN_EDGE_FADE, -0.5)
#define _gu8tjag _yj42341(HAZE_FOG_SEA_LEVEL, HAZE_RAIN_SEA_LEVEL, -9000.0)
#define _l7icifd _yj42341(HAZE_FOG_AIR_AMOUNT, HAZE_RAIN_AIR_AMOUNT, -0.5)
#define _1ao9n00 _yj42341(HAZE_FOG_MIST_AMOUNT, HAZE_RAIN_MIST_AMOUNT, -0.5)
#define _fzo68pg _yj42341(HAZE_FOG_AIR_START, HAZE_RAIN_AIR_START, -0.5)
#define _fit23zo _yj42341(HAZE_FOG_MIST_START, HAZE_RAIN_MIST_START, -0.5)
#define _8jrz65j _yj42341(HAZE_FOG_AIR_FALLOFF, HAZE_RAIN_AIR_FALLOFF, -0.5)
#define _uvx343j _yj42341(HAZE_FOG_MIST_FALLOFF, HAZE_RAIN_MIST_FALLOFF, -0.5)
#define _m0u8br1 _yj42341(HAZE_FOG_PATCH_STRENGTH, HAZE_RAIN_PATCH_STRENGTH, -0.5)
#endif
