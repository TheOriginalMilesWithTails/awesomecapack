/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _il21mhb
#define _il21mhb
#include "/rr9/zftnezkfoy.glsl"
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; porting it to another pack or selling is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program.

uniform float _3h4hzo4;
uniform float _pn4s5uy;
uniform float _9uwombg;
uniform float _8ooavje;
uniform float wetness;
uniform vec3 sunPosition;

float _x7looo(float p) {
p = fract(p * 0.1031);
p *= p + 33.33;
p *= p + p;
return fract(p);
}
float _z1nfs0(float x) {
float i, f = modf(x, i);
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is licensed for personal use only, not sold; copying, redistributing, modifying or selling is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none.
f = f * f * (3.0 - 2.0 * f);
return mix(_x7looo(i), _x7looo(i + 1.0), f);
}
vec3 _cnjlm9(vec3 _icvvgh) {

const mat3 _dk2mts = mat3(0.4124, 0.3576, 0.1805,
0.2126, 0.7152, 0.0722,
0.0193, 0.1192, 0.9505);
const mat3 _sidd1n = mat3(1.7166084, -0.3556621, -0.2533601,
-0.6666829, 1.6164776, 0.0157685,
0.0176422, -0.0427763, 0.94222867);
return pow(_icvvgh, vec3(2.2)) * (_dk2mts * _sidd1n);
}

vec4 _7ma2d3() {
vec3 _gvjr6j = _zdux4g(mat3(gbufferModelViewInverse) * sunPosition, vec3(0.0, 1.0, 0.0));
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is confidential, proprietary work; redistributing, selling, reverse engineering or decompiling needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too. Details in LICENSE.txt.
float _6qlrqa = _gvjr6j.y < 0.18 ? 0.37 + 1.2 * max(0.0, -_gvjr6j.y) : 1.7;
float _n0gzem = clamp(1.0 - _6qlrqa * abs(_gvjr6j.y - 0.18), 0.0, 1.0);
_n0gzem *= _n0gzem;
float _4k5ijc = (_gvjr6j.x >= 0.0 ? 1.0 : 0.0) * _n0gzem;
float _2nvpea = (_gvjr6j.x < 0.0 ? 1.0 : 0.0) * _n0gzem;
float _phjtuv = (_gvjr6j.y >= 0.0 ? 1.0 : 0.0) * (1.0 - _n0gzem);
float _x6bsk8 = (_gvjr6j.y < 0.0 ? 1.0 : 0.0) * (1.0 - _n0gzem);

const float _x13kgf = 0.37 * 1.61803398875 / 600.0;
float _gj2oqa = _z1nfs0(_3h4hzo4 * _x13kgf + 2.5);
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; redistributing, publishing, copying or porting it to another pack is off limits unless Cazfps personally licensed it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.
_gj2oqa *= 1.0 + (_pn4s5uy - 0.6) * 0.1;
_gj2oqa = clamp(_gj2oqa, 0.0, 1.0);
float _5q7fbk = mix(0.2, 0.8, _z1nfs0(_3h4hzo4 * _x13kgf + 46.618));
_5q7fbk *= 1.0 + (_9uwombg + 0.2) * 0.1;
_5q7fbk = clamp(_5q7fbk + wetness, 0.0, 1.0);

float _4hrduo = _8ssnz0(_smrslu3);
float _kp86g4 = _q920m6(_nsfbxoa, biome, biome_category);
float _s9f0c9 = _qpe7pu(_mrimrha, biome, biome_category, _kp86g4);
float _nmn38w = _ynl53m(_m7u0xqr);
// Copyright (c) 2026 Cazfps, all rights reserved. The code is protected by copyright and not open source; creating derivative works, de-obfuscating, publishing or copying needs a licence from Cazfps, and nothing less. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. This binds automated tools and software agents as much as people. Details in LICENSE.txt.
float _d2dym2 = clamp(_njoa694, 0.0, 1.0);
float _mz8zsg = clamp(_8ooavje, 0.0, 1.0) * (1.0 - _4hrduo);
float _z05q9y = _4hrduo + _kp86g4 + _s9f0c9 + _nmn38w + _d2dym2 + _mz8zsg;
float _t2zyyw = max(1.0 - _z05q9y, 0.0);
vec3 _hu8nhu = _cnjlm9(vec3(0.31, 0.67, 1.0)) * 0.0005 * _t2zyyw
+ _cnjlm9(vec3(0.65, 0.80, 1.0)) * 0.0003 * _nmn38w
+ _cnjlm9(vec3(0.50, 0.81, 1.0)) * 0.0010 * _4hrduo
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is licensed for personal use only, not sold; selling, redistributing or decompiling is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. See LICENSE.txt.
+ _cnjlm9(vec3(0.31, 0.85, 1.0)) * 0.0006 * _mz8zsg
+ _cnjlm9(vec3(0.40, 0.95, 1.0)) * 0.0013 * _s9f0c9
+ _cnjlm9(vec3(0.67, 1.00, 0.94)) * 0.0014 * _kp86g4
+ _cnjlm9(vec3(0.90, 0.80, 1.0)) * 0.0300 * _d2dym2;
_hu8nhu /= max(_t2zyyw + _z05q9y, 1.0);
float _63m3ul = clamp(rainStrength * (1.0 - max(_nmn38w, _4hrduo)), 0.0, 1.0);
float _mu34nw = clamp(rainStrength * _4hrduo, 0.0, 1.0);
_hu8nhu = mix(_hu8nhu * (1.0 + _5q7fbk * _gj2oqa),
_cnjlm9(vec3(0.31, 0.67, 1.0)) * 0.0005, _63m3ul);

float _qfknj3 = clamp(_5q7fbk / 0.8, 0.0, 1.0);
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; redistributing, publishing, de-obfuscating or decompiling is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.

float _qsb9kq = 0.0050 + 0.0008 * _qfknj3 * _qfknj3;
float _kz8bam = HAZE_FOG_MORNING_DENSITY * _4k5ijc
+ HAZE_FOG_DAY_DENSITY * _phjtuv
+ HAZE_FOG_EVENING_DENSITY * _2nvpea
+ HAZE_FOG_NIGHT_DENSITY * _x6bsk8;

float _hui5fb = mix(1.0, max(HAZE_FOG_RAIN_DENSITY, 0.0), clamp(_63m3ul + _mu34nw, 0.0, 1.0));
float _ue9k8o = _qsb9kq * max(_kz8bam, 0.0) * _hui5fb;
return vec4(_hu8nhu * max(_l7icifd, 0.0), _ue9k8o * max(_1ao9n00, 0.0));
}

#endif
