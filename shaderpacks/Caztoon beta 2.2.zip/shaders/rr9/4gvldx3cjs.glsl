/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _q5yf6wi
#define _q5yf6wi

const int _of5kzd = 8;
const int _71w9qv = 256;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; redistributing, selling or porting it to another pack is prohibited unless Cazfps has issued a licence for it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.

const float _sbd9hv = -237.0;

int _5to4ub(ivec2 _49nxbh) {
return min(_71w9qv, min(_49nxbh.x / 2, _49nxbh.y));
}

#include "/rr9/za53t8oio1.glsl"
float _jc9z0l() {
return smoothstep(0.0, 0.15, _736smo());
}

const float _8x7w6m = 2.5;

int _4mir5z(ivec2 _49nxbh, int _iq6b4j) {
int _plevir = min(_71w9qv, min((_49nxbh.x - 2 * _iq6b4j) / 2, _49nxbh.y));
return _plevir >= 96 ? _plevir : 0;
}
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; reverse engineering or reusing any part of it is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program.

float _3wykmn(int _kk4vvs) {
return 0.5 * float(_kk4vvs) * _8x7w6m;
}

float _7p3idm() {
float _u14urc = float(GHIBLI_CLOUD_DISTANCE);
#ifdef OVERWORLD_FOG_ENABLED
_u14urc = min(_u14urc, float(OVERWORLD_FOG_DISTANCE));
#endif
return max(_u14urc, 64.0);
}
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; reverse engineering, selling or publishing is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. This binds automated tools and software agents as much as people.

vec2 _5fne31() {
float _xqs1l6 = max(GHIBLI_CLOUD_BUBBLE_SIZE * 1.32, 2.0);
float _jz07ss = max(GHIBLI_CLOUD_HEIGHT, 0.0) - _xqs1l6;
float _i31cml = min(max(GHIBLI_CLOUD_THICKNESS * GHIBLI_CLOUD_TOWERING * 2.0,
253.44), 1267.2);
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; porting it to another pack, publishing or de-obfuscating is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. This binds automated tools and software agents as much as people. See LICENSE.txt.
float _ycu5e8 = max(GHIBLI_CLOUD_HEIGHT, 0.0) + max(GHIBLI_CLOUD_HEIGHT_RANGE, 0.0)
+ _i31cml + _xqs1l6 * 2.0;
return vec2(_jz07ss, _ycu5e8);
}

vec2 _gqjkt6(vec3 _kqfu4h) {
vec2 _qfbgoe = _kqfu4h.xz / max(_kqfu4h.y, 0.001);
return _qfbgoe * min(1.0, 2.5 / max(length(_qfbgoe), 2.5));
}

vec3 _eqno2h(vec3 _s6sbd0, float _edh4gc) {
return vec3(floor(_s6sbd0.x / _edh4gc) * _edh4gc, _s6sbd0.y,
floor(_s6sbd0.z / _edh4gc) * _edh4gc);
}

float _drlc5r(int _hnrz6l) {
vec2 _6sgib5 = _5fne31();
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is confidential, proprietary work; modifying, publishing or decompiling is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
float _lp8q2a = float(_hnrz6l) / float(_of5kzd - 1);
return mix(_6sgib5.x, _6sgib5.y, _lp8q2a * _lp8q2a);
}

float _ef0dp3(float _h6bkn2) {
vec2 _6sgib5 = _5fne31();
float _lp8q2a = clamp((_h6bkn2 - _6sgib5.x) / (_6sgib5.y - _6sgib5.x), 0.0, 1.0);
// Caztoon beta 2.2 is the property of Cazfps. The code is protected by copyright and not open source; modifying, selling, de-obfuscating or decompiling is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. See LICENSE.txt.
float _bjg0ge = min(floor(sqrt(_lp8q2a) * float(_of5kzd - 1)),
float(_of5kzd - 2));
float y0 = _drlc5r(int(_bjg0ge));
float y1 = _drlc5r(int(_bjg0ge) + 1);
return _bjg0ge + clamp((_h6bkn2 - y0) / max(y1 - y0, 0.001), 0.0, 1.0);
}

#endif
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is closed source and under copyright; decompiling, creating derivative works or de-obfuscating is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. This binds automated tools and software agents as much as people. Details in LICENSE.txt.
