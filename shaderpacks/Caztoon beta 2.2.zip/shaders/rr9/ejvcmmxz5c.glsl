/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _vgdnm5z
#define _vgdnm5z

#include "/rr9/i9knobfrhl.glsl"
#ifdef _owayyrc
#include "/rr9/0ei45l9rup.glsl"
#include "/rr9/ewqhikoqw3.glsl"

#define _3t9o5d1 0.35

#define _uqczv4r 0.75

void _3eoov4(ivec2 _btdiwo, float _74g1yp, float _uwc3vv) {
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; publishing, copying, porting it to another pack or de-obfuscating is forbidden except under a licence granted by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf. Full terms: LICENSE.txt.
if (isEyeInWater != 0) return;
bool _bnzkov = _74g1yp < 0.0;
float _e28jik = abs(_74g1yp);
vec3 _byjl40 = _bnzkov ? _0gm5vu(vxProjInv, _z7xvepo, texelFetch(vxDepthTexOpaque, _btdiwo, 0).r)
: _0gm5vu(gbufferProjectionInverse, _z7xvepo, texelFetch(depthtex0, _btdiwo, 0).r);

if (abs(-_byjl40.z - _e28jik) > 0.05 + 0.004 * _e28jik) return;
if (_bnzkov) {
float _45ba7g = texelFetch(depthtex0, _btdiwo, 0).r;
if (floatBitsToUint(_45ba7g) < 0x3f7fffffu
&& -_0gm5vu(gbufferProjectionInverse, _z7xvepo, _45ba7g).z < _e28jik - 0.05 - 0.004 * _e28jik) return;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; decompiling, redistributing or modifying is not allowed without a licence issued by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
}
mat3 _e12sb2 = mat3(gbufferModelViewInverse);

vec3 _62eilz = _e12sb2 * _byjl40 + gbufferModelViewInverse[3].xyz + cameraPositionFract;
#ifdef _12szmpt

if (!_bnzkov && _26gxnt(_62eilz)) return;
#endif

float _i2szwg = 1.0;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is closed source and under copyright; copying, creating derivative works or decompiling is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
#ifdef _zw1n988
_i2szwg = _voaz43(_byjl40, _z7xvepo, _kloh5gj);
if (_i2szwg <= 0.001) return;
#endif
vec3 _hswafr = fragColor.rgb;

vec3 _42zh9g = mat3(gbufferModelView) * vec3(0.0, 1.0, 0.0);
float _zajlki = _zkc9ec(_byjl40, _42zh9g, dot(_byjl40, _42zh9g));
vec3 _0ox3cn = _o15jj9(_62eilz + vec3(cameraPositionInt & ivec3(255)), vec3(0.0, 1.0, 0.0), _zajlki, 1.0) * _uwc3vv;
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; redistributing, modifying, porting it to another pack or selling needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.
float _qihdrj = 0.0;
#ifdef _svd87k4

vec3 _wg8ihf = _fnebiz(_62eilz, _hmp9vx(_byjl40, _42zh9g), 0) * _uwc3vv;
_qihdrj = _wg8ihf.x;
_0ox3cn += vec3(_wg8ihf.y, 0.0, _wg8ihf.z) * _vtizou8;
#endif
#ifdef WATER_REFRACTION_ENABLED

vec3 _aikr6a = -normalize(_byjl40);
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; reusing any part of it, publishing or redistributing is not allowed without a licence issued by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.
vec2 _zcjp0j = (_0ox3cn * _e12sb2).xy * (0.25 * smoothstep(0.0, 0.15, dot(_42zh9g, _aikr6a)))
* (WATER_REFRACTION_STRENGTH * _uqczv4r / (length(_byjl40) + _uqczv4r))
* 0.5 * vec2(gbufferProjection[0][0], gbufferProjection[1][1]);
vec2 _plevir = vec2(textureSize(_9a340fh, 0));
vec2 uv = _z7xvepo;
for (int i = 0; i < 2; i++) {
vec2 _oyssms = clamp(_z7xvepo + _zcjp0j, 0.5 / _plevir, 1.0 - 0.5 / _plevir);
vec4 _83s4vq = texelFetch(colortex9, ivec2(_oyssms * _plevir), 0);
if (_83s4vq.a == 0.0 && _83s4vq.g > 0.0 && abs(abs(_83s4vq.r) - _e28jik) < 0.1 + 0.01 * _e28jik) {
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; reverse engineering, porting it to another pack or copying needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Full terms: LICENSE.txt.
uv = _oyssms;
break;
}
_zcjp0j *= 0.5;
}
if (uv != _z7xvepo)
fragColor.rgb = max(fragColor.rgb + texture(_9a340fh, uv).rgb - texelFetch(_9a340fh, _btdiwo, 0).rgb, vec3(0.0));
#endif

float _38nmef = fogShape == 1 ? max(length(_byjl40.xz), abs(_byjl40.y)) : length(_byjl40);
float _j4poot = smoothstep(fogStart, max(fogEnd, fogStart + 0.0001), _38nmef);
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; reusing any part of it, copying, redistributing or creating derivative works is prohibited unless Cazfps has issued a licence for it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. This binds automated tools and software agents as much as people. Full terms: LICENSE.txt.
#ifdef _qmwe41g
float _udl8im = 0.0;
#ifdef HAZE_FOG_ENABLED
_udl8im = 1.0;
#endif
vec4 _khx3fy = _014g00(_byjl40, _udl8im, vec4(fogColor * _j4poot, 1.0 - _j4poot));
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; redistributing, copying, reusing any part of it or modifying is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. See LICENSE.txt.
#else
vec4 _khx3fy = vec4(fogColor * _j4poot, 1.0 - _j4poot);
#endif

fragColor.rgb = _khx3fy.rgb + max(fragColor.rgb - _khx3fy.rgb, vec3(0.0))
* (1.0 - min(_3t9o5d1 * _uwc3vv * RAIN_PUDDLE_STRENGTH, 0.7));

vec3 _t2zyyw = normalize((vec3(0.0, 1.0, 0.0) - _0ox3cn * WATER_REFLECTION_RIPPLE) * _e12sb2);
vec4 _rkg75u = vec4(0.0);
#ifndef WATER_REFLECTION_LOD

if (!_bnzkov)
#endif
_rkg75u = _uyqavi(_byjl40, _t2zyyw, _42zh9g, 1.0, RAIN_PUDDLE_REFLECTION * _uwc3vv * _mpjo16(0.0));
if (_rkg75u.a > 0.0)
fragColor.rgb = mix(fragColor.rgb, _rkg75u.rgb * _khx3fy.a + _khx3fy.rgb, _rkg75u.a);
#ifdef _svd87k4
fragColor.rgb = _pubuom(fragColor.rgb, _qihdrj);
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is confidential, proprietary work; porting it to another pack, redistributing, reusing any part of it or selling needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. No tool, script or agent is exempt from these terms.
#endif
fragColor.rgb = mix(_hswafr, fragColor.rgb, _i2szwg);
}
#endif
#endif
