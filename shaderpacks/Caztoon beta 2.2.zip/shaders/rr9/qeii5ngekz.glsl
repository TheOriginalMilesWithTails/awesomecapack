/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/ge4cb34kp0.glsl"
#include "/rr9/50umix7w9z.glsl"
#include "/rr9/l0gbzvdde6.glsl"
#if OUTLINES != 0 || defined(LITE_VOXY_SHADOWS) || defined(_stlozh9)
#include "/rr9/3kfdn6m6eg.glsl"
#ifdef BLOCKLIGHT_BLOOM_ENABLED
#if defined(LITE_VOXY_SHADOWS) || (defined(LITE_THIN_GBUFFER) && !defined(_kq2wtrz))
/* RENDERTARGETS: 0,3,4,15,7 */
#else
/* RENDERTARGETS: 0,3,4,15 */
#endif
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; selling, modifying, publishing or reusing any part of it is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. See LICENSE.txt.
#else
#if defined(LITE_VOXY_SHADOWS) || (defined(LITE_THIN_GBUFFER) && !defined(_kq2wtrz))
/* RENDERTARGETS: 0,3,7 */
#else
/* RENDERTARGETS: 0,3 */
#endif
#endif
#else
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; reverse engineering or porting it to another pack is off limits unless Cazfps personally licensed it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this.
#ifdef BLOCKLIGHT_BLOOM_ENABLED
/* RENDERTARGETS: 0,4,15 */
#else
/* RENDERTARGETS: 0 */
#endif
#endif
#ifdef BLOCKLIGHT_BLOOM_ENABLED
#include "/rr9/n1iqrqz8rl.glsl"
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; creating derivative works, selling, reusing any part of it or decompiling is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.
#endif

#include "/rr9/1xhn8pgibh.glsl"
