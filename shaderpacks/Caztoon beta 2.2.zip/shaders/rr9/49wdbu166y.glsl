/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _u9kuwm7
#define _u9kuwm7

//#define DOF_ENABLED
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; de-obfuscating or modifying is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.

#define DOF_STRENGTH 1.00 // [0.25 0.50 0.75 1.00 1.50 2.00 3.00]

#define DOF_FOCUS 0 // [0 2 4 8 16 32 64 128]

#ifdef DOF_ENABLED
#define _cf4l59k
#endif
#endif
