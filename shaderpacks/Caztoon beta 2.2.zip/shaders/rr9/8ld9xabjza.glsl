/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#if !defined(_t7h2fz6)
#define _t7h2fz6
#include "/rr9/54of7yk6fp.glsl"
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is licensed for personal use only, not sold; decompiling, de-obfuscating, reusing any part of it or reverse engineering needs a licence from Cazfps, and nothing less. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
#if defined(LITE_COLORTEX_BLOOM)
#define _8g3eii3() texelFetch(colortex26, ivec2(0), 0)
#else
#include "/rr9/f8akl8gy30.glsl"
#define _8g3eii3() _yckbet()
#endif
#endif
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; decompiling or publishing is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
