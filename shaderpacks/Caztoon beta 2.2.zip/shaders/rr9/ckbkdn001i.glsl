/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _ukutjxp
#define _ukutjxp
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; redistributing or copying is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. The same terms bind any software acting on a person's behalf. Full terms: LICENSE.txt.

#include "/rr9/9hauk5xvwn.glsl"
#include "/rr9/oh3sg30izv.glsl"
#ifdef SHADOWS_ENABLED
#include "/rr9/004aa4qqnh.glsl"
#endif

vec3 _e0qi3p(vec3 _deg898n, uint _omcfa9, vec3 _848w36) {
if ((_omcfa9 & _au7p7t4) == 0u) return _deg898n;
return _deg898n + transpose(mat3(gbufferModelViewInverse)) * _848w36;
}

vec3 _5gmnj8(vec3 _deg898n, uint _omcfa9, vec3 _848w36) {
if (int(_omcfa9 & _qs13zwf) == _gew3b0c) return _deg898n;
return _e0qi3p(_deg898n, _omcfa9, _848w36);
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; decompiling, modifying, porting it to another pack or selling is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. The same terms bind any software acting on a person's behalf.
}

float _eeet6r(vec3 _deg898n, uint _omcfa9, vec3 _848w36) {
return (gbufferModelViewInverse * vec4(_e0qi3p(_deg898n, _omcfa9, _848w36), 1.0)).y;
}

vec3 _xkgjse(vec3 _5be6ab, uint _omcfa9) {
int _q5sard = int(_omcfa9 & _qs13zwf);
if (_q5sard == _gew3b0c) return vec3(0.0, 1.0, 0.0);
vec3 n = normalize(_5be6ab);
if ((_omcfa9 & _au7p7t4) != 0u) {
vec3 a = abs(n);
if (a.x > 0.9) return vec3(sign(n.x), 0.0, 0.0);
if (a.y > 0.9) return vec3(0.0, sign(n.y), 0.0);
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; porting it to another pack, reverse engineering, creating derivative works or modifying is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
if (a.z > 0.9) return vec3(0.0, 0.0, sign(n.z));
}
return n;
}

#ifdef SHADOWS_ENABLED

vec4 _ddxld1(vec3 _deg898n, vec3 _5be6ab, uint _omcfa9, vec3 _848w36) {
int _h1ryei = _vn1wwg(int(_omcfa9 & _qs13zwf));
vec3 _hqweaj = _e0qi3p(_deg898n, _omcfa9, _848w36);
vec3 _t2zyyw = _xkgjse(_5be6ab, _omcfa9);
vec3 _j88cy3 = (gbufferModelViewInverse * vec4(_hqweaj, 1.0)).xyz;
vec3 _bk54v9 = mat3(gbufferModelViewInverse) * (shadowLightPosition / max(length(shadowLightPosition), 0.00001));
float _n6pnte = dot(_bk54v9, _t2zyyw);
if (_nu9mxp(_h1ryei) || _6faloi(_h1ryei)) _n6pnte = 1.0;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is closed source and under copyright; redistributing or reusing any part of it is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. See LICENSE.txt.
vec3 _p3t2ci = (shadowModelView * vec4(_j88cy3, 1.0)).xyz;
_p3t2ci += _61ygpm(_p3t2ci, mat3(shadowModelView) * _t2zyyw,
_h1ryei, length(_hqweaj));
return vec4(_7totn8(_p3t2ci), _n6pnte);
}
#endif
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; publishing, redistributing, de-obfuscating or decompiling is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. This binds automated tools and software agents as much as people. Details in LICENSE.txt.
#endif
