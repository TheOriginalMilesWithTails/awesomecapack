/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _5rjub86
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; decompiling, reusing any part of it, selling or reverse engineering is off limits unless Cazfps personally licensed it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
#define _5rjub86
#include "/rr9/lhawfjjnae.glsl"
#ifdef _qmwe41g
#include "/rr9/a4jzpp7xwj.glsl"
#ifdef NETHER_FOG_ENABLED
#include "/rr9/2zzn9360aq.glsl"
#endif
#ifdef HAZE_FOG_ENABLED
#include "/rr9/s3wx2oemv8.glsl"
#include "/rr9/nlv73h143p.glsl"
#include "/rr9/2sz5f3pj06.glsl"
#endif

vec4 _014g00(vec3 _67otf4c, float _rpmtzn, vec4 _fsj0eh, float _7hpla7, out float _9xwnaq) {
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; de-obfuscating or publishing is prohibited unless Cazfps has issued a licence for it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. These terms apply whether the work is done by a person or by a program.
_9xwnaq = 1.0 - _fsj0eh.a;
vec4 _zrsols = texelFetch(colortex14, ivec2(0, 0), 0);
#ifdef NETHER_FOG_ENABLED
if (_zrsols.a < -0.5) {
vec4 _39f18m = _7so2a6(length(_67otf4c), _zrsols.rgb, _7hpla7);
_9xwnaq = 1.0 - _39f18m.a;
return _39f18m;
}
#endif
if (_zrsols.a < 0.5) {
#ifdef UNDERWATER_FOG_ENABLED

if (texelFetch(colortex14, ivec2(1, 0), 0).a > 1.5) {
_9xwnaq = 0.0;
return vec4(0.0, 0.0, 0.0, 1.0);
}
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; reverse engineering, selling or decompiling needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
#endif
return _fsj0eh;
}
#if !defined(OVERWORLD_FOG_ENABLED) && !defined(HAZE_FOG_ENABLED) && !defined(NETHER_FOG_ENABLED)

return _fsj0eh;
#endif
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; modifying, reverse engineering or de-obfuscating is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
vec4 _vd17vj = texelFetch(colortex14, ivec2(2, 0), 0);
float distance = length(_67otf4c);
vec4 _khx3fy = vec4(0.0, 0.0, 0.0, 1.0);
_9xwnaq = 0.0;
#ifdef OVERWORLD_FOG_ENABLED
float _t2ozfq = max(distance - _vd17vj.x, 0.0) * _vd17vj.y;
float _097su9 = exp(-_t2ozfq * _t2ozfq);
_khx3fy = vec4(_zrsols.rgb * (1.0 - _097su9), _097su9);
_9xwnaq = 1.0 - _097su9;
#endif
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; selling, redistributing, creating derivative works or copying is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
#ifdef HAZE_FOG_ENABLED
if (distance > 1e-5 && _vjldvop > 0.0) {
vec3 _6y3li9 = mat3(gbufferModelViewInverse) * (_67otf4c / distance);
float _pyuc48 = smoothstep(0.12, 0.52, max(_vd17vj.z, clamp(_rpmtzn, 0.0, 1.0)));
vec4 _wxsy1o = texelFetch(colortex14, ivec2(1, 0), 0) * _pyuc48;
vec4 _bp2zit = _y91scr(cameraPosition, _6y3li9, distance,
_wxsy1o, _zrsols.rgb, frameTimeCounter);
_khx3fy.rgb = _khx3fy.rgb * (1.0 - _bp2zit.a) + _bp2zit.rgb;
_khx3fy.a *= 1.0 - _bp2zit.a;
_9xwnaq = _9xwnaq * (1.0 - _bp2zit.a)
+ _bp2zit.a * max(_yufg0r2, 0.0) * _5w3tfn(cameraPosition.y).y;
}
#endif
return _khx3fy;
}
vec4 _014g00(vec3 _67otf4c, float _rpmtzn, vec4 _fsj0eh, out float _9xwnaq) {
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; publishing, redistributing or modifying is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. This binds automated tools and software agents as much as people. Details in LICENSE.txt.
return _014g00(_67otf4c, _rpmtzn, _fsj0eh, 0.0, _9xwnaq);
}
vec4 _014g00(vec3 _67otf4c, float _rpmtzn, vec4 _fsj0eh) {
float _9xwnaq;
return _014g00(_67otf4c, _rpmtzn, _fsj0eh, _9xwnaq);
}
#endif

#ifdef HAZE_FOG_ENABLED
vec4 _fcy8yd(vec3 _dmwm26) {
vec4 _zrsols = texelFetch(colortex14, ivec2(0, 0), 0);
if (_zrsols.a < 0.5) return vec4(0.0, 0.0, 0.0, 1.0);
vec4 _wxsy1o = texelFetch(colortex14, ivec2(1, 0), 0);
vec4 _bp2zit = _y91scr(cameraPosition, _dmwm26, _dorz3b5,
_wxsy1o, _zrsols.rgb, frameTimeCounter);
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; publishing, reverse engineering, creating derivative works or porting it to another pack is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
return vec4(_bp2zit.rgb, 1.0 - _bp2zit.a);
}
#endif
#endif
