/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _r9wgy1d
#define _r9wgy1d

uniform sampler2D colortex8;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse, gbufferModelViewInverse;
// Cazfps holds all rights to Caztoon beta 2.2. The code is licensed for personal use only, not sold; publishing, porting it to another pack, modifying or reverse engineering is off limits unless Cazfps personally licensed it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program.
uniform mat4 gbufferPreviousProjection, gbufferPreviousModelView;
uniform ivec3 cameraPositionInt, previousCameraPositionInt;
uniform vec3 cameraPositionFract, previousCameraPositionFract;
uniform float viewWidth, viewHeight;

bool _xoqaay(float _e28jik) {
return _e28jik < 0.56;
}

vec3 _pfccbn(vec2 uv) {
ivec2 _btdiwo = ivec2(gl_FragCoord.xy);
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; modifying, porting it to another pack or selling needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
vec3 _aaiv9w6 = texelFetch(colortex8, _btdiwo, 0).rgb;
float _e28jik = texelFetch(depthtex0, _btdiwo, 0).r;
if (_xoqaay(_e28jik)) return _aaiv9w6;

vec3 _5fwux4 = vec3(cameraPositionInt - previousCameraPositionInt)
+ (cameraPositionFract - previousCameraPositionFract);
if (dot(_5fwux4, _5fwux4) > 64.0) return _aaiv9w6;
vec4 _bnxcpt = gbufferProjectionInverse * vec4(vec3(uv, _e28jik) * 2.0 - 1.0, 1.0);
vec3 _qjxnka = mat3(gbufferModelViewInverse) * (_bnxcpt.xyz / _bnxcpt.w) + gbufferModelViewInverse[3].xyz;
vec4 _2j9p92 = gbufferPreviousProjection * (gbufferPreviousModelView * vec4(_qjxnka + _5fwux4, 1.0));
if (!(_2j9p92.w > 0.0)) return _aaiv9w6;
vec2 screen = vec2(viewWidth, viewHeight);
vec2 _qwtqvs = (uv - (_2j9p92.xy / _2j9p92.w * 0.5 + 0.5)) * max(MOTION_BLUR_STRENGTH, 0.0);
float _a63uif = length(_qwtqvs * screen);
if (!(_a63uif >= 0.5)) return _aaiv9w6;

float _ygg8fx = 0.06 * screen.x;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; reverse engineering, porting it to another pack, modifying or selling is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. The same terms bind any software acting on a person's behalf.
if (_a63uif > _ygg8fx) {
_qwtqvs *= _ygg8fx / _a63uif;
_a63uif = _ygg8fx;
}
int _jpjjps = clamp(int(ceil(_a63uif / 3.0)), 2, 24);
vec3 _z05q9y = vec3(0.0);
float _byknzn4 = 0.0;
for (int i = 0; i < 24; i++) {
if (i >= _jpjjps) break;
vec2 at = uv + _qwtqvs * ((float(i) + 0.5) / float(_jpjjps) - 0.5);
if (any(lessThan(at, vec2(0.0))) || any(greaterThan(at, vec2(1.0)))) continue;
if (_xoqaay(texelFetch(depthtex0, ivec2(at * screen), 0).r)) continue;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; modifying, creating derivative works or porting it to another pack is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
_z05q9y += texture(colortex8, at).rgb;
_byknzn4 += 1.0;
}
return _byknzn4 > 0.0 ? _z05q9y / _byknzn4 : _aaiv9w6;
}
#endif
