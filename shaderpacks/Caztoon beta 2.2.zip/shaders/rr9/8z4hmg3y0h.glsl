/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _jp39yq9
#define _jp39yq9
#include "/rr9/7bf18bntxa.glsl"
// Copyright (c) 2026 Cazfps, all rights reserved. The code is licensed for personal use only, not sold; decompiling, reverse engineering, de-obfuscating or modifying is off limits unless Cazfps personally licensed it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. These terms apply whether the work is done by a person or by a program.

#define LIGHT_FOG_ENABLED

#define LIGHT_FOG_DENSITY 0.75 // [0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]

#define LIGHT_FOG_SPREAD 1.00 // [0.50 0.75 1.00 1.25 1.50 2.00]

#define LIGHT_FOG_BRIGHTNESS 1.00 // [0.50 0.75 1.00 1.25 1.50]

#define LIGHT_FOG_STEPS 16 // [8 12 16 24 32]
#ifdef LIGHT_FOG_ENABLED
// Caztoon beta 2.2 is the property of Cazfps. The code is protected by copyright and not open source; copying or creating derivative works is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. No tool, script or agent is exempt from these terms. See LICENSE.txt.
#ifdef _23cancj
#define _hlbwdo8
#endif
#endif
#endif
