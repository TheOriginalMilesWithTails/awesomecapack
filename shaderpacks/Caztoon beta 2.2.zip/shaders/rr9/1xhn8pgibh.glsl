/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#if defined(LITE_VOXY_SHADOWS) || (defined(LITE_THIN_GBUFFER) && !defined(_kq2wtrz))
/*
const int colortex7Format = RGBA16F;
const bool colortex7Clear = true;
const vec4 colortex7ClearColor = vec4(0.0, 0.0, 0.0, -1.0);
*/

#if defined(_huvj528) && defined(_bsxnmy6) && defined(_kq2wtrz) && !defined(_9tbngxa)
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; de-obfuscating, copying or porting it to another pack needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.

vec4 liteVoxyShadowData;
#elif defined(_9tbngxa) || defined(BLOCKLIGHT_BLOOM_ENABLED)
layout(location = 4) out vec4 liteVoxyShadowData;
#else
layout(location = 2) out vec4 liteVoxyShadowData;
#endif
#endif
