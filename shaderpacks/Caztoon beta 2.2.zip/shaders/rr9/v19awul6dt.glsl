/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _kxwwvpb
#define _kxwwvpb
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; creating derivative works or reverse engineering is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf.
#include "/rr9/eml2vk4bgl.glsl"
#ifdef WATER_SURFACE_DOTS
#define _5ciss7j
#include "/rr9/r7il6oksnm.glsl"
#include "/rr9/ygbwzynq3t.glsl"

#ifndef _dpkyfc0
#define _dpkyfc0
uniform float _l7rsjky;
#endif

vec4 _k0xzqx(vec2 _k3gfsw) {
vec4 q = fract(vec4(_k3gfsw.xyxy) * vec4(0.1031, 0.1030, 0.0973, 0.1099));
q += dot(q, q.wzxy + 33.33);
return fract((q.xxyz + q.yzzw) * q.zywx);
}
// Caztoon beta 2.2 is the property of Cazfps. The code is confidential, proprietary work; porting it to another pack, copying or modifying needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. This binds automated tools and software agents as much as people. Full terms: LICENSE.txt.

float _1jtw8b(vec3 _232u1g, float _zajlki, float t) {
if (_zajlki > 0.36) return 0.0;

vec2 _12rmj4 = floor(_232u1g.xz * 16.0);
vec2 _k3gfsw = floor(_12rmj4 / 8.0);
vec2 _9znw9c = mod(_k3gfsw, 512.0);
vec4 h = _k0xzqx(_9znw9c);
if (h.x > 0.12 * WATER_SURFACE_DOTS_DENSITY) return 0.0;

float _o4x8vy = t / (2.5 + 2.5 * h.y) + h.z;
float _7etj9t = fract(_o4x8vy);
// Copyright (c) 2026 Cazfps, all rights reserved. The code is licensed for personal use only, not sold; reusing any part of it or selling is not allowed without a licence issued by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Full terms: LICENSE.txt.
float _8nzj5l = smoothstep(0.0, 0.15, _7etj9t) * (1.0 - smoothstep(0.35, 0.55, _7etj9t));
if (_8nzj5l <= 0.0) return 0.0;

vec4 g = _k0xzqx(_9znw9c + vec2(mod(floor(_o4x8vy), 61.0) * 37.0, 11.0));
float _plevir = g.z < 0.45 ? 2.0 : (g.z < 0.8 ? 3.0 : 4.0);
vec2 d = _12rmj4 - _k3gfsw * 8.0 - floor(g.xy * (9.0 - _plevir));
if (any(lessThan(d, vec2(0.0))) || any(greaterThanEqual(d, vec2(_plevir)))) return 0.0;
float _0h29ta = 0.5 * (_plevir - 1.0);
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is closed source and under copyright; reusing any part of it, publishing, copying or selling needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
if (_plevir > 2.5 && abs(d.x - _0h29ta) + abs(d.y - _0h29ta) > _plevir - 1.5) return 0.0;

return _8nzj5l * (1.0 - smoothstep(0.045 * _plevir, 0.09 * _plevir, _zajlki));
}

float _2htb54(vec3 _deg898n, vec3 _232u1g, float _g43865, float t) {
vec3 dx = dFdx(_deg898n);
vec3 dy = dFdy(_deg898n);
vec3 _t2zyyw = normalize(cross(dx, dy));
if (dot(_t2zyyw, _deg898n) > 0.0) _t2zyyw = -_t2zyyw;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; modifying, reusing any part of it or porting it to another pack is forbidden except under a licence granted by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. No tool, script or agent is exempt from these terms. See LICENSE.txt.
if (_t02k2mh < 0.5 || (mat3(gbufferModelViewInverse) * _t2zyyw).y < 0.5) return 0.0;
float _yrz32bz = mix(0.35, 1.0, smoothstep(-0.05, 0.10, sin(sunAngle * 6.2831853)));
float _9hsjr4 = _1jtw8b(_232u1g, max(length(dx), length(dy)), t)
* _yrz32bz * _t93zl6(_g43865) * WATER_SURFACE_DOTS_STRENGTH;
return _9hsjr4 * (1.0 - smoothstep(0.0, 1.0, _l7rsjky));
}

vec4 _um2kx4(vec4 _0vh339n, vec3 _9hsjr4) {
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; selling or decompiling needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Full terms: LICENSE.txt.
float _2zr7bl = clamp(max(_9hsjr4.r, max(_9hsjr4.g, _9hsjr4.b)), 0.0, 1.0);
if (_2zr7bl <= 0.0) return _0vh339n;
float _cw7o15 = mix(_0vh339n.a, 1.0, _2zr7bl);
return vec4((_0vh339n.rgb * _0vh339n.a + _9hsjr4) / _cw7o15, _cw7o15);
}
#endif
#endif
