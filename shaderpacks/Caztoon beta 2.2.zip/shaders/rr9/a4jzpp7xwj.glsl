/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _9m7bz4i
#define _9m7bz4i

#ifndef _9tbngxa
uniform sampler2D colortex14;
#endif
#endif
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is confidential, proprietary work; reusing any part of it, decompiling or publishing needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
