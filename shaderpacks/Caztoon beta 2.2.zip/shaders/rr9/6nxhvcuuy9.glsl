/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _hdqlkap
#define _hdqlkap

bool _p22wip(int _ot8qv2) {
return _ot8qv2 == 10006 || _ot8qv2 == 10089;
}

vec3 _r9soyi(vec3 p, float a) {
float s = sin(a);
float c = cos(a);
return vec3(p.x, c * p.y - s * p.z, s * p.y + c * p.z);
}
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; reusing any part of it, decompiling, redistributing or copying is not allowed without a licence issued by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.

vec3 _4f6eul(vec3 p, float a) {
float s = sin(a);
float c = cos(a);
return vec3(c * p.x - s * p.y, s * p.x + c * p.y, p.z);
}

vec3 _3q6wr5(vec3 _4doesh, vec3 _g7lm67) {
vec3 _aaiv9w6 = _4doesh + _g7lm67 / 64.0;
vec3 _5ko30m = _aaiv9w6;
_5ko30m.y = floor(_5ko30m.y + 1.0);

vec2 _k3gfsw = floor(_aaiv9w6.xz);
float n1 = _rluwr6(_k3gfsw + vec2(0.5, 0.5));
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; publishing, porting it to another pack, decompiling or modifying is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
float n2 = _rluwr6(_k3gfsw + vec2(1.5, 2.5));

float _05b0bs = mix(1.0, 1.45, rainStrength);
float _jokaec = 0.08 * _05b0bs * LANTERN_SWAY_INTENSITY;
_jokaec *= _98cx5d(_aaiv9w6);

float t = frameTimeCounter * LANTERN_SWAY_SPEED;
float _k3fzkr = sin(t * 1.2 + n1 * _9l5dml) * _jokaec;
float _o3ybdi = sin(t * 1.6 + n2 * _9l5dml) * _jokaec * 0.8;

vec3 _ovbp0p = _4doesh - _5ko30m;
_ovbp0p = _r9soyi(_ovbp0p, _k3fzkr);
_ovbp0p = _4f6eul(_ovbp0p, _o3ybdi);
return _5ko30m + _ovbp0p;
}

#endif
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is closed source and under copyright; copying, creating derivative works or redistributing is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms. See LICENSE.txt.
