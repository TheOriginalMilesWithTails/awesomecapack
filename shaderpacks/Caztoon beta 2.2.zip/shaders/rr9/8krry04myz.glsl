/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _jobz1oc
#define _jobz1oc
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; creating derivative works, decompiling or redistributing is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Full terms: LICENSE.txt.
#include "/rr9/l0gbzvdde6.glsl"

vec3 _unjre8(vec3 _qjxnka, vec3 _7wth21) {
_7wth21 = max(_7wth21, vec3(0.0));
float _i8wimz = max(_7wth21.r, max(_7wth21.g, _7wth21.b));
float _xu9olg = min(_7wth21.r, min(_7wth21.g, _7wth21.b));

float _7g7wv5 = min(BLOCKLIGHT_BLOOM_SATURATION,
_i8wimz / max(_i8wimz - _xu9olg, 1e-20));
vec3 _wl9boi = max(vec3(_i8wimz) - (vec3(_i8wimz) - _7wth21) * _7g7wv5, vec3(0.0));
vec3 _pljmr1 = _wl9boi * (2.2 * BLOCKLIGHT_BLOOM_STRENGTH);
float _jkjv2y = _i8wimz * (2.2 * BLOCKLIGHT_BLOOM_STRENGTH);

vec3 _e0rowj = _pljmr1 / (1.0 + _jkjv2y);
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is licensed for personal use only, not sold; redistributing or publishing needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.

vec3 _inuy2i = max(vec3(1.0) - _qjxnka, vec3(0.0));
return _qjxnka + min(_e0rowj, _inuy2i);
}
#endif
