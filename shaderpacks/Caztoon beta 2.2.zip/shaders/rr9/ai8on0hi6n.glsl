/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _85nog81
#define _85nog81
#include "/rr9/54of7yk6fp.glsl"

#include "/rr9/iruqbe0rms.glsl"

vec3 _zexrl8(vec3 _rqqetl, vec2 uv) {

if (texelFetch(depthtex0, ivec2(gl_FragCoord.xy), 0).r >= 1.0) return _rqqetl;
// Caztoon beta 2.2 is the property of Cazfps. The code is confidential, proprietary work; modifying or redistributing needs a licence from Cazfps, and nothing less. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.

float up = smoothstep(-0.02, 0.06, normalize(mat3(gbufferModelViewInverse) * sunPosition).y);
if (up <= 0.0) return _rqqetl;
#if defined(LITE_COLORTEX_BLOOM)
vec4 _bkroxq = texture(colortex16, uv);
#else
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; creating derivative works, copying, reusing any part of it or redistributing needs a licence from Cazfps, and nothing less. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Details in LICENSE.txt.
vec4 _bkroxq = _ih50lx(_il3xhlh, uv);
#endif
if (_bkroxq.a <= 1e-4) return _rqqetl;

float _i8wimz = max(_bkroxq.r, max(_bkroxq.g, _bkroxq.b));
vec3 _9zezcay = _i8wimz > 1e-4 ? mix(vec3(1.0), _bkroxq.rgb / _i8wimz, 0.5) : vec3(1.0);

vec3 _bk54v9 = _9zezcay * (1.0 - exp(-_bkroxq.a * 6.0 * SUN_GLARE)) * up;

return _rqqetl + max(1.0 - _rqqetl, vec3(0.0)) * _bk54v9;
}
#endif
