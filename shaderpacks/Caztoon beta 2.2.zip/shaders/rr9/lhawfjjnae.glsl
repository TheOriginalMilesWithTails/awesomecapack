/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _f6z2drk
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; decompiling or publishing is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false.
#define _f6z2drk

#define NETHER_FOG_ENABLED
#define NETHER_FOG_DISTANCE 128 // [0 32 48 64 96 128 160 192 256 320 384 512]
#define NETHER_DISTANCE_FOG_START 32.0 // [0.0 8.0 16.0 24.0 32.0 48.0 64.0 80.0 96.0 112.0 128.0 160.0 192.0 224.0 256.0 320.0 384.0 512.0]
#define NETHER_DISTANCE_FOG_OPACITY 1.50 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.25 1.50 2.00 3.00 5.00]
#define NETHER_BRIGHTNESS 0.30 // [0.00 0.05 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.25 1.50 2.00 2.50 3.00 4.00 5.00]
#define NETHER_FOG_R 0.96 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define NETHER_FOG_G 0.28 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define NETHER_FOG_B 0.50 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is confidential, proprietary work; reusing any part of it, redistributing, porting it to another pack or publishing is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.

#define NETHER_BIOME_FADE 4 // [0 1 2 3 4 5 6 8 10 15]

#define OVERWORLD_FOG_ENABLED
#define OVERWORLD_FOG_DISTANCE 12288 // [64 96 128 192 256 384 512 768 1024 1536 2048 3072 4096 6144 8192 12288 16384 20480]
#define OVERWORLD_FOG_START 48.0 // [0.0 8.0 16.0 32.0 48.0 64.0 96.0 128.0]
#define OVERWORLD_FOG_DENSITY 2.00 // [0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.25 1.50 2.00 3.00]
#define OVERWORLD_FOG_RAIN_BOOST 0.50 // [0.00 0.10 0.20 0.30 0.40 0.50 0.75 1.00 1.50 2.00]
#define HAZE_FOG_ENABLED
//#define HAZE_FOG_SHADOWS_ENABLED
#define HAZE_FOG_SHADOW_QUALITY 1 // [0 1 2]
#ifdef HAZE_FOG_SHADOWS_ENABLED
const bool _xi3e5hb = true;
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; selling, reusing any part of it, porting it to another pack or modifying is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. Automated tools, scripts and agents are bound by these terms too. Details in LICENSE.txt.
#else
const bool _xi3e5hb = false;
#endif
#define HAZE_FOG_DENSITY 1.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60 0.75 1.00 1.25 1.50 2.00 3.00]
#define HAZE_FOG_BRIGHTNESS 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]

#define HAZE_FOG_ABOVE_DENSITY 4.00 // [0.25 0.50 0.75 1.00 1.50 2.00 3.00 4.00 5.00 6.00 8.00 10.00]
#define HAZE_FOG_ABOVE_BRIGHTNESS 1.00 // [0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]

#define HAZE_FOG_ABOVE_TRANSITION 4.0 // [0.0 0.5 1.0 1.5 2.0 3.0 4.0 5.0 6.0 8.0 10.0]
#define HAZE_FOG_AIR_AMOUNT 1.00 // [0.00 0.10 0.20 0.25 0.30 0.40 0.50 0.60 0.75 1.00 1.25 1.50 2.00]
#define HAZE_FOG_MIST_AMOUNT 1.00 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.75 1.00 1.25 1.50 2.00]

#define HAZE_FOG_HEIGHT_PROFILE 2 // [0 1 2]
#define HAZE_FOG_EDGE_FADE 96 // [0 1 2 4 8 16 24 32 48 64 96 128]
#define HAZE_FOG_SEA_LEVEL 63 // [-64 -32 0 16 32 48 63 64 80 96 128 160 192 256 320]
#define HAZE_FOG_MIN_Y -640 // [-640 -64 -48 -32 -16 0 16 24 32 39 48 63 64 80 96 112 128 160 192 256 320 384 512]
#define HAZE_FOG_MAX_Y 112 // [-64 -48 -32 -16 0 16 24 32 39 48 63 64 80 96 112 128 160 192 256 320 384 512]
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is protected by copyright and not open source; porting it to another pack, redistributing, reverse engineering or modifying is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too.
#define HAZE_FOG_AIR_START 30 // [0 4 7 8 12 16 24 30 32 40 48 64 80 96 128 160 192 256]
#define HAZE_FOG_MIST_START 7 // [0 4 7 8 12 16 24 30 32 40 48 64 80 96 128 160 192 256]
#define HAZE_FOG_AIR_FALLOFF 30 // [1 2 4 7 8 12 16 24 30 32 48 64 96 128 192 256]
#define HAZE_FOG_MIST_FALLOFF 7 // [1 2 4 7 8 12 16 24 30 32 48 64 96 128 192 256]
#define HAZE_FOG_DIST_START 0 // [0 8 16 32 48 64 96 128 192 256 384 512]
#define HAZE_FOG_DIST_END 4096 // [64 96 128 192 256 384 512 768 1024 1536 2048 4096 8192 16384]
#define HAZE_FOG_MORNING_DENSITY 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; creating derivative works, porting it to another pack, reverse engineering or copying needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
#define HAZE_FOG_DAY_DENSITY 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]
#define HAZE_FOG_EVENING_DENSITY 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]
#define HAZE_FOG_NIGHT_DENSITY 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]
#define HAZE_FOG_RAIN_DENSITY 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]
//#define HAZE_FOG_PATCHES_ENABLED
#define HAZE_FOG_STEPS 25 // [8 12 16 20 25 32]
#define HAZE_FOG_PATCH_STRENGTH 1.00 // [0.00 0.10 0.20 0.25 0.35 0.50 0.65 0.75 1.00]
#define HAZE_FOG_PATCH_SIZE 1000 // [64 96 128 192 256 384 512 768 1000 1536 2048 4096]
#define HAZE_FOG_WIND_SPEED 1.00 // [0.00 0.25 0.50 0.75 1.00 1.50 2.00 3.00 4.00]

#define HAZE_RAIN_DENSITY -1.00 // [-1.00 0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60 0.75 1.00 1.25 1.50 2.00 3.00 4.00 5.00]
#define HAZE_RAIN_BRIGHTNESS -1.00 // [-1.00 0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]
#define HAZE_RAIN_ABOVE_DENSITY -1.00 // [-1.00 0.25 0.50 0.75 1.00 1.50 2.00 3.00 4.00 5.00 6.00 8.00 10.00]
#define HAZE_RAIN_ABOVE_BRIGHTNESS -1.00 // [-1.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]
#define HAZE_RAIN_DIST_START -1 // [-1 0 8 16 32 48 64 96 128 192 256 384 512]
#define HAZE_RAIN_DIST_END -1 // [-1 64 96 128 192 256 384 512 768 1024 1536 2048 4096 8192 16384]
#define HAZE_RAIN_MIN_Y -9999 // [-9999 -64 -48 -32 -16 0 16 24 32 39 48 63 64 80 96 112 128 160 192 256 320 384 512]
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; reverse engineering, selling, de-obfuscating or modifying is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. No tool, script or agent is exempt from these terms. See LICENSE.txt.
#define HAZE_RAIN_MAX_Y -9999 // [-9999 -64 -48 -32 -16 0 16 24 32 39 48 63 64 80 96 112 128 160 192 256 320 384 512]
#define HAZE_RAIN_EDGE_FADE -1 // [-1 0 1 2 4 8 16 24 32 48 64 96 128]
#define HAZE_RAIN_SEA_LEVEL -9999 // [-9999 -64 -32 0 16 32 48 63 64 80 96 128 160 192 256 320]
#define HAZE_RAIN_AIR_AMOUNT -1.00 // [-1.00 0.00 0.10 0.20 0.25 0.30 0.40 0.50 0.60 0.75 1.00 1.25 1.50 2.00 3.00]
#define HAZE_RAIN_MIST_AMOUNT -1.00 // [-1.00 0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.75 1.00 1.25 1.50 2.00 3.00]
#define HAZE_RAIN_AIR_START -1 // [-1 0 4 7 8 12 16 24 30 32 40 48 64 80 96 128 160 192 256]
#define HAZE_RAIN_MIST_START -1 // [-1 0 4 7 8 12 16 24 30 32 40 48 64 80 96 128 160 192 256]
#define HAZE_RAIN_AIR_FALLOFF -1 // [-1 1 2 4 7 8 12 16 24 30 32 48 64 96 128 192 256]
#define HAZE_RAIN_MIST_FALLOFF -1 // [-1 1 2 4 7 8 12 16 24 30 32 48 64 96 128 192 256]
#define HAZE_RAIN_PATCH_STRENGTH -1.00 // [-1.00 0.00 0.10 0.20 0.25 0.35 0.50 0.65 0.75 1.00]
#define HAZE_RAIN_PATCH_SIZE -1 // [-1 64 96 128 192 256 384 512 768 1000 1536 2048 4096]
#define HAZE_RAIN_WIND_SPEED -1.00 // [-1.00 0.00 0.25 0.50 0.75 1.00 1.50 2.00 3.00 4.00]

#define UNDERWATER_FOG_ENABLED
#define UNDERWATER_FOG_DENSITY 1.00 // [0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]
#define UNDERWATER_FOG_BRIGHTNESS 1.00 // [0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; redistributing, decompiling or reusing any part of it is off limits unless Cazfps personally licensed it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
#define UNDERWATER_SUN_GLOW 1.00 // [0.00 0.25 0.50 0.75 1.00 1.50 2.00 3.00]

#define UNDERWATER_FOG_PATCHES 1.00 // [0.00 0.25 0.50 0.75 1.00 1.50 2.00]
#define UNDERWATER_TERRAIN_TINT 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00]
#define UNDERWATER_SHAFTS_ENABLED
#define UNDERWATER_SHAFTS_INTENSITY 2.0 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.2 1.5 2.0 2.5 3.0]
#define UNDERWATER_SHAFTS_DENSITY 0.3 // [0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define UNDERWATER_SHAFTS_SCALE 0.15 // [0.02 0.03 0.04 0.05 0.06 0.08 0.10 0.12 0.15]
#define UNDERWATER_SHAFTS_SPEED 0.3 // [0.0 0.1 0.2 0.3 0.4 0.5 0.7 1.0]
#define UNDERWATER_FOG_R 0.05 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define UNDERWATER_FOG_G 0.20 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define UNDERWATER_FOG_B 0.60 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]

#if defined(OVERWORLD_FOG_ENABLED) || defined(HAZE_FOG_ENABLED) || defined(NETHER_FOG_ENABLED) || defined(UNDERWATER_FOG_ENABLED)
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is confidential, proprietary work; reverse engineering, reusing any part of it, creating derivative works or publishing is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false.
#define _qmwe41g
#endif
#endif
