/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _419fimm
#define _419fimm
#include "/rr9/9e2clhoqfs.glsl"
#include "/rr9/j3usxxpv1y.glsl"

#define WATER_REFRACTION_ENABLED
#define WATER_REFRACTION_STRENGTH 3.00 // [0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]

#define WATER_OPACITY 0.60 // [0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

#define WATER_WAVE_STYLE 3 // [0 1 2 3 4 5]

#define WATER_SPARKLE_ENABLED
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; de-obfuscating, creating derivative works, reverse engineering or decompiling is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
#define WATER_SPARKLE_STRENGTH 1.00 // [0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]

#define WATER_SPARKLE_SMOOTHING 0.20 // [0.00 0.20 0.40 0.60 0.80]

#define WATER_SURFACE_DOTS
#define WATER_SURFACE_DOTS_STRENGTH 1.00 // [0.25 0.50 0.75 1.00 1.50 2.00 3.00]
#define WATER_SURFACE_DOTS_DENSITY 1.00 // [0.25 0.50 0.75 1.00 1.50 2.00 3.00]

#define WATER_REFLECTIONS_ENABLED
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is proprietary and confidential; reverse engineering, reusing any part of it, modifying or copying is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.

#define WATER_REFLECTION_QUALITY 2 // [1 2 3]

#define WATER_REFLECTION_HALF_RES

#define WATER_REFLECTION_OPACITY 1.00 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50]

#define WATER_REFLECTION_DOWN 0.15 // [0.00 0.02 0.05 0.10 0.15 0.20 0.25 0.30 0.40 0.50 0.60]
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is licensed for personal use only, not sold; creating derivative works, modifying or porting it to another pack is not allowed without a licence issued by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. These terms apply whether the work is done by a person or by a program.
#define WATER_REFLECTION_LOW_ANGLE 0.90 // [0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

#define WATER_REFLECTION_ANGLE_FALLOFF 3.0 // [1.0 1.5 2.0 2.5 3.0 3.5 4.0 5.0]

#define WATER_REFLECTION_SKY 1.50 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50]
#define WATER_REFLECTION_BLOCKS 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50]

#define WATER_REFLECTION_CLOUDS 0 // [0 1 2]

#define WATER_REFLECTION_COVER_FADE 2 // [1 2 3]

#define WATER_REFLECTION_NIGHT 1.00 // [0.00 0.25 0.50 0.70 0.85 1.00]
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; porting it to another pack or copying is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. The same terms bind any software acting on a person's behalf. Full terms: LICENSE.txt.
#define WATER_REFLECTION_RAIN 0.60 // [0.00 0.25 0.40 0.60 0.80 1.00]

#define WATER_REFLECTION_RIPPLE 0.25 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00]

#define WATER_REFLECTION_DISTANCE 512.0 // [32.0 64.0 128.0 256.0 512.0 1024.0 2048.0]

#define WATER_REFLECTION_EDGE_FADE 0.15 // [0.05 0.10 0.15 0.20 0.30]

#define WATER_REFLECTION_LOD
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; redistributing, reusing any part of it, publishing or decompiling is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf. See LICENSE.txt.

#if defined(WATER_REFRACTION_ENABLED) || defined(WATER_REFLECTIONS_ENABLED) || defined(_xhfi8ph) || defined(_nyfa0t3)
#define _wvnpeme
#endif

#if defined(WATER_REFRACTION_ENABLED) || defined(WATER_SPARKLE_ENABLED) || defined(_20sh0tn) || defined(_nyfa0t3)
#define _ksr8o1r
#endif
#ifdef WATER_REFLECTIONS_ENABLED
#ifndef _ksr8o1r
#define _ksr8o1r
#endif
#endif

#ifndef _ksr8o1r
#define _ksr8o1r
#endif

#ifdef WATER_REFLECTIONS_ENABLED
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; porting it to another pack, decompiling, reusing any part of it or reverse engineering is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. See LICENSE.txt.
#ifdef WATER_REFLECTION_HALF_RES
#define _2ohghe4
#endif
#endif

#include "/rr9/irwglp0tpj.glsl"
#endif
