/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _cjbd77z
#define _cjbd77z

#include "/rr9/o5vuo4rhm7.glsl"

//#define FLOATING_TEXT_SHADOWS
#define SHADOW_DISTANCE_CHUNKS 10 // [2 3 4 5 6 8 10 12 14 16 20 24 28 32 40 48 64 80 96 128 160 192 256 320 384 512 625]
#define SHADOW_DISTORTION 0.10// [0.02 0.03 0.04 0.05 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.40 0.50 0.60 0.70 0.85]
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; publishing or modifying needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says.
#define _fuqhpqz 0.2
#define SHADOW_NORMAL_BIAS 2.0 // [0.00 0.50 1.00 1.50 2.0 2.50 3.00 4.00 5.00]
#define SHADOW_OPACITY 0.50// [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define TWILIGHT_SHADOW_DARKENING 1.25 // [1.00 1.25 1.50 2.00 2.50 3.00 4.00 5.00]
#define BLOCKLIGHT_SHADOW_OVERRIDE 1.00// [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define SHADOW_PCF_RADIUS 2.5 // [0.5 1.0 1.5 2.0 2.5 3.0 3.5 4.0 5.0 6.0 8.0]
const int shadowMapResolution = 2048; // [512 1024 2048 3072 4096 6144 8192 12288 16384]
#define SHARP_SHADOWS
#ifdef SHARP_SHADOWS
const bool _ujshfcp = true;
#else
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; redistributing, porting it to another pack or decompiling is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
const bool _ujshfcp = false;
#endif

#ifdef PIXELATED_SHADOWS
const bool _wjibebb = true;
#else
const bool _wjibebb = false;
#endif

#include "/rr9/42xwprqbx1.glsl"
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; reusing any part of it or de-obfuscating needs a licence from Cazfps, and nothing less. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
#ifdef BLOCK_TRACED_SHADOWS
#if defined(_bsxnmy6) && defined(IRIS_FEATURE_CUSTOM_IMAGES)
#define _2afvqz3
#endif
#endif

#define PIXELATED_SHADOW_GRID 16 // [16 32 64]
#define PIXELATED_SHADOW_STRENGTH 1.00 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define PIXELATED_SHADOW_BLUR 0.30 // [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.75 1.00 1.25 1.50 2.00 3.00 4.00]

#define SHADOW_DISTANCE_BLUR_ENABLED
#define SHADOW_DISTANCE_BLUR_START 0.05 // [0.00 0.05 0.10 0.15 0.20 0.25 0.35 0.50 0.65 0.80]
#define SHADOW_DISTANCE_BLUR_STRENGTH 2.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00]

#define VOXY_SSS_ENABLED

#define VOXY_FACE_SHADING
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is confidential, proprietary work; porting it to another pack or decompiling is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. Details in LICENSE.txt.
#ifdef VOXY_FACE_SHADING
#define _sf44nc1
#endif

#define TERRAIN_SHADOWS
#ifdef TERRAIN_SHADOWS
#ifdef SHADOWS_ENABLED
#define _mv74nhn
#endif
#endif
#define TERRAIN_SHADOW_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00]
#define TERRAIN_SHADOW_SOFTNESS 1.00 // [0.25 0.50 0.75 1.00 1.50 2.00 3.00 4.00]

#define VOXY_SHADOW_DITHER 0.75 // [0.00 0.25 0.50 0.75 1.00]
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; reverse engineering, publishing or selling is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
#define VOXY_SHADOW_FILTER 3 // [0 1 2 3]
#define VOXY_SHADOW_OPACITY 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0]
#define LEAF_SHADOW_SOFTNESS 3.0 // [0.0 1.0 2.0 3.0 4.0 6.0 8.0]

#define VANILLA_LEAF_SHADOW_BLUR 3 // [0 1 2 3 4 6 8]

#define CARTOONY_SHADOWS

#define _v680mws (float(SHADOW_DISTANCE_CHUNKS) * 16.0)
#if SHADOW_DISTANCE_CHUNKS == 2
const float shadowDistance = 32.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 3
const float shadowDistance = 48.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 4
const float shadowDistance = 64.0;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is proprietary and confidential; copying, publishing, decompiling or redistributing is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too.
#else
#if SHADOW_DISTANCE_CHUNKS == 5
const float shadowDistance = 80.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 6
const float shadowDistance = 96.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 8
const float shadowDistance = 128.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 10
const float shadowDistance = 160.0;
#else
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; reusing any part of it or reverse engineering is not allowed without a licence issued by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
#if SHADOW_DISTANCE_CHUNKS == 12
const float shadowDistance = 192.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 14
const float shadowDistance = 224.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 16
const float shadowDistance = 256.0;
#else
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; creating derivative works, selling or de-obfuscating is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf.
#if SHADOW_DISTANCE_CHUNKS == 20
const float shadowDistance = 320.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 24
const float shadowDistance = 384.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 28
const float shadowDistance = 448.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 32
const float shadowDistance = 512.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 40
const float shadowDistance = 640.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 48
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; de-obfuscating, selling or redistributing is off limits unless Cazfps personally licensed it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. The same terms bind any software acting on a person's behalf.
const float shadowDistance = 768.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 64
const float shadowDistance = 1024.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 80
const float shadowDistance = 1280.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 96
const float shadowDistance = 1536.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 128
const float shadowDistance = 2048.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 160
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; porting it to another pack, modifying, redistributing or de-obfuscating needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. This binds automated tools and software agents as much as people. Details in LICENSE.txt.
const float shadowDistance = 2560.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 192
const float shadowDistance = 3072.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 256
const float shadowDistance = 4096.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 320
const float shadowDistance = 5120.0;
#else
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is confidential, proprietary work; publishing, copying or decompiling is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. Details in LICENSE.txt.
#if SHADOW_DISTANCE_CHUNKS == 384
const float shadowDistance = 6144.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 512
const float shadowDistance = 8192.0;
#else
#if SHADOW_DISTANCE_CHUNKS == 625
const float shadowDistance = 10000.0;
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; selling, publishing, copying or reverse engineering is off limits unless Cazfps personally licensed it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. Automated tools, scripts and agents are bound by these terms too.
#endif
#endif
#endif
#endif
#endif
#endif
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; creating derivative works, modifying or publishing is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
#endif
const float shadowDistanceRenderMul = 1.0;
const bool shadowtex0Nearest = false;
const bool shadowtex1Nearest = false;
/*
const int shadowcolor0Format = RGBA8;
const int shadowcolor1Format = RGBA8;
*/
// Copyright (c) 2026 Cazfps, all rights reserved. The code is licensed for personal use only, not sold; decompiling or porting it to another pack is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. See LICENSE.txt.
const bool shadowcolor0Nearest = false;
const bool shadowcolor1Nearest = false;

#ifdef SHADOWS_ENABLED
#define LITE_VOXY_SHADOWS
#ifdef VOXY_SSS_ENABLED
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; selling, creating derivative works, modifying or de-obfuscating is forbidden except under a licence granted by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
#define _zwuq5lq
#endif
#endif
#endif
