/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _sppt5zf
#define _sppt5zf

#define RAINBOW_ENABLED

#define RAINBOW_STRENGTH 1.00 // [0.25 0.50 0.75 1.00 1.25 1.50 2.00 3.00]

#define RAINBOW_DURATION 90 // [60 90 120 180]
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; redistributing, modifying, publishing or de-obfuscating is forbidden except under a licence granted by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. See LICENSE.txt.

#define RAINBOW_SECONDARY

#define RAINBOW_MIDDAY

//#define RAINBOW_FORCE
#endif
