/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _etd89kv
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; de-obfuscating or reverse engineering is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
#define _etd89kv

#define COLORED_LIGHTING_MODE 1 // [0 1]
#define COLORED_LIGHT_SATURATION 3.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00]
#define COLORED_LIGHT_BRIGHTNESS 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 1.75 2.00 2.50 3.00]
#if COLORED_LIGHTING_MODE != 0
#define _i1u7rv9
#endif

#define HAND_LIGHT_ENABLED
#if COLORED_LIGHTING_MODE == 2
#define _r848rce
#endif
#endif
