/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _xrkbq8n
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; modifying or reusing any part of it is forbidden except under a licence granted by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Full terms: LICENSE.txt.
#define _xrkbq8n
#define WATER_SHORE_FOAM_ENABLED
#define WATER_SHORE_FOAM_DEPTH 0.60 // [0.10 0.20 0.30 0.40 0.50 0.60 0.80 1.00 1.50 2.00]
#define WATER_SHORE_FOAM_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00 1.50 2.00 3.00 4.00]
#define WATER_CAUSTICS_ENABLED

#define WATER_CAUSTICS_STRENGTH 0.50 // [0.00 0.25 0.50 0.75 1.00 1.50 2.00 3.00]
#define WATER_CAUSTICS_ABOVE_STRENGTH 0.50 // [0.00 0.25 0.50 0.75 1.00 1.50 2.00 3.00]

#define WATER_CAUSTICS_GLOW 1.00 // [0.00 0.25 0.50 0.75 1.00 1.50 2.00 3.00]
#define WATER_CAUSTICS_SPEED 4.0 // [0.0 0.4 0.6 0.8 1.0 1.2 1.5 2.0 3.0 4.0]

#define WATER_EDGE_OUTLINE
#define WATER_EDGE_OUTLINE_WIDTH 4 // [1 2 3 4 5 6 8]
#define WATER_EDGE_OUTLINE_OPACITY 0.35 // [0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.50 0.60 0.70 0.85 1.00]

#define WATER_EDGE_FOAM_STYLE 1 // [0 1]
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; redistributing, publishing, selling or reusing any part of it is forbidden except under a licence granted by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. This binds automated tools and software agents as much as people. Details in LICENSE.txt.

#define WATER_EDGE_FOAM_SHAPE 1 // [0 1]

#define WATER_WAKE_OPACITY 0.90 // [0.00 0.25 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#ifdef WATER_SHORE_FOAM_ENABLED
#define _nyfa0t3
#endif
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is closed source and under copyright; decompiling, modifying, redistributing or publishing is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf.
#ifdef WATER_CAUSTICS_ENABLED
#ifndef _nyfa0t3
#define _nyfa0t3
#endif
#endif
#ifdef WATER_EDGE_OUTLINE
#ifndef _nyfa0t3
#define _nyfa0t3
#endif
#endif
#endif
