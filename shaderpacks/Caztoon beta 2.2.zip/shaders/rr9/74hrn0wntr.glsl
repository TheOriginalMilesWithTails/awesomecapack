/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _6b3d0kp
#define _6b3d0kp
#include "/rr9/dfa4h4xbki.glsl"
#include "/rr9/hewmhqioeh.glsl"
#include "/rr9/lj0wpa5iqz.glsl"
#include "/rr9/l3t8ltb510.glsl"

vec3 _0d934z(vec3 _0vh339n) {
return clamp(_0vh339n / max(dot(_0vh339n, vec3(0.299, 0.587, 0.114)), 0.35),
vec3(0.0), vec3(2.0));
}
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; porting it to another pack, reusing any part of it or decompiling is not allowed without a licence issued by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. The same terms bind any software acting on a person's behalf. See LICENSE.txt.

vec3 _axohv4(vec3 _0vh339n, float _o4mdk3) {
_0vh339n = max(_0vh339n, vec3(0.0));
float _sey8i8 = dot(_0vh339n, vec3(0.299, 0.587, 0.114));

vec3 _8fchsm = _oho4cy(clamp(mix(vec3(_sey8i8), _0vh339n, max(_o4mdk3, 0.0)),
vec3(0.0), vec3(10.0)));
_8fchsm.y = clamp(_8fchsm.y, 0.0, 1.0);
return _nyrbxr(_8fchsm);
}

vec4 _8uifet(int _5rq78p, float _yjfvs5, vec3 _l5jief) {
// Copyright (c) 2026 Cazfps, all rights reserved. The code is licensed for personal use only, not sold; decompiling, copying or reusing any part of it is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. See LICENSE.txt.
float a = fract(_yjfvs5);
float _ta23bz = smoothstep(0.38, 0.45, a) * (1.0 - smoothstep(0.48, 0.55, a))
+ smoothstep(0.95, 1.0, a) + (1.0 - smoothstep(0.0, 0.05, a));
float _ddue8z = smoothstep(0.07, 0.15, a) * (1.0 - smoothstep(0.40, 0.46, a));
float _xa2aft = smoothstep(0.58, 0.66, a) * (1.0 - smoothstep(0.92, 0.98, a));
float _074t2q = SKYLIGHT_COLOR_TINT * (1.0 - _ddue8z * 0.6) * (1.0 - _xa2aft * 0.7);
float _xj1b7t = clamp(_074t2q + _ta23bz * SUNSET_TERRAIN_TINT, 0.0, 1.0) * 0.68;

if (_5rq78p == 5) {

vec3 _05g1ln = vec3(1.0);
if (abs(SHADOW_HUE) > 0.001) {
float degrees = SHADOW_HUE > 0.0 ? 180.0 + SHADOW_HUE : 360.0 + SHADOW_HUE;
_05g1ln = _nyrbxr(vec3(fract(degrees / 360.0), 1.0, 1.0));
_05g1ln = min(_05g1ln / max(dot(_05g1ln, vec3(0.299, 0.587, 0.114)), 0.3), vec3(2.0));
}
return vec4(_05g1ln, _xj1b7t);
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is proprietary and confidential; creating derivative works, de-obfuscating, copying or reverse engineering needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
}

vec3 _291wyd = vec3(1.0);
#ifdef SURFACE_TIME_TINT_ENABLED
_2tcfn38 _9m624z = _9xsrk1n(_yjfvs5);
vec3 _hbg2j9 = vec3(DAY_ZENITH_R, DAY_ZENITH_G, DAY_ZENITH_B) * _9m624z._0cgf1nh
+ vec3(SUNSET_ZENITH_R, SUNSET_ZENITH_G, SUNSET_ZENITH_B) * _9m624z._3namkzq
+ vec3(BLUEHOUR_ZENITH_R, BLUEHOUR_ZENITH_G, BLUEHOUR_ZENITH_B) * _9m624z._kr2ul1s
+ vec3(NIGHT_ZENITH_R, NIGHT_ZENITH_G, NIGHT_ZENITH_B) * _9m624z._pft4abr
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; publishing, selling or creating derivative works is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Details in LICENSE.txt.
+ vec3(_cnjr11m, _hueobi5, _wln7nan) * _9m624z._dxud89z
+ vec3(_lpve53t, _3iw5hml, _w4f8q0r) * _9m624z._ko18a5p;
_hbg2j9 = mix(_hbg2j9, vec3(0.9, 0.15, 0.85), min(_9m624z._0cgf1nh, _9m624z._3namkzq));
_hbg2j9 = mix(_hbg2j9, vec3(0.4, 0.1, 1.0), min(_9m624z._3namkzq, _9m624z._kr2ul1s));
vec3 _c33l46 = dot(_l5jief, vec3(0.299, 0.587, 0.114)) > 0.0005
? _0d934z(_l5jief) : vec3(1.0);
vec3 _3tojq5 = _0d934z(_0d934z(_hbg2j9)
* mix(vec3(1.0), _c33l46, smoothstep(0.5, 0.9, _9m624z._0cgf1nh)));
_3tojq5 = mix(_3tojq5, vec3(dot(_3tojq5, vec3(0.299, 0.587, 0.114))), _xa2aft * 0.85);
float _o4mdk3 = SKYLIGHT_TINT_SATURATION * (1.0 + _ta23bz * SUNSET_TERRAIN_TINT * 1.09);
if (_5rq78p == 3) _o4mdk3 = mix(1.0, _o4mdk3, clamp(SKYLIGHT_TINT_LIGHT_SATURATION, 0.0, 1.0));
vec3 _9zezcay = _0d934z(_axohv4(_3tojq5, _o4mdk3));
_291wyd = _0d934z(mix(vec3(1.0), _9zezcay, _xj1b7t));
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; redistributing, creating derivative works or selling is off limits unless Cazfps personally licensed it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.
#endif
float _uofoam = smoothstep(0.0, 0.20, _g4yknb(_yjfvs5).x);
return vec4(_291wyd, _uofoam);
}
#endif
