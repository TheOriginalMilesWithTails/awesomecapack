/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _03el6qj
#define _03el6qj

float _gd7mi8(vec3 p) {
p = fract(p * vec3(0.1031, 0.1030, 0.0973));
p += dot(p, p.yzx + 33.33);
return fract((p.x + p.y) * p.z);
// Cazfps holds all rights to Caztoon beta 2.2. The code is licensed for personal use only, not sold; reusing any part of it or decompiling is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false.
}

float _1gjro1(vec3 p) {
vec3 i = floor(p);
vec3 f = fract(p);
f = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);

vec3 i0 = mod(i, vec3(289.0));
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; reusing any part of it, reverse engineering, creating derivative works or de-obfuscating is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
vec3 i1 = mod(i0 + vec3(1.0), vec3(289.0));
float a = _gd7mi8(vec3(i0.x, i0.y, i0.z));
float b = _gd7mi8(vec3(i1.x, i0.y, i0.z));
float c = _gd7mi8(vec3(i0.x, i1.y, i0.z));
float d = _gd7mi8(vec3(i1.x, i1.y, i0.z));
float e = _gd7mi8(vec3(i0.x, i0.y, i1.z));
float g = _gd7mi8(vec3(i1.x, i0.y, i1.z));
float h = _gd7mi8(vec3(i0.x, i1.y, i1.z));
float k = _gd7mi8(vec3(i1.x, i1.y, i1.z));

return mix(mix(mix(a, b, f.x), mix(c, d, f.x), f.y),
mix(mix(e, g, f.x), mix(h, k, f.x), f.y), f.z);
}

#endif
