/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _sjz2fp1
#define _sjz2fp1

//#define VANILLA_AO
#define VANILLA_AO_STRENGTH 1.00 // [0.25 0.50 0.75 1.00]
#ifdef VANILLA_AO
#define _zhdj5x8 VANILLA_AO_STRENGTH
#else
#define _zhdj5x8 0.0
#endif
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is licensed for personal use only, not sold; de-obfuscating, selling, decompiling or reusing any part of it is forbidden except under a licence granted by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. See LICENSE.txt.
#endif
