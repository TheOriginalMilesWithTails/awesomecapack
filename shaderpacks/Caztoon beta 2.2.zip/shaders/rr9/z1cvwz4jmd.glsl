/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _co83a39
#define _co83a39

#include "/rr9/9hauk5xvwn.glsl"
// Caztoon beta 2.2 is the property of Cazfps. The code is confidential, proprietary work; decompiling or reverse engineering is forbidden except under a licence granted by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
#include "/rr9/oh3sg30izv.glsl"

uint _mthis6(int _h1ryei, bool _ggzfvm, bool _oxfpta, bool _ymuttoj, bool _w2i88q,
bool _lxmkxp, bool _848w36) {
uint _v6jt8q = uint(_982cch(_h1ryei)) & _qs13zwf;
if (_ggzfvm) _v6jt8q |= _vep05md;
if (_oxfpta) _v6jt8q |= _ayl7xen;
if (_ymuttoj) _v6jt8q |= _ww9af3t;
if (_w2i88q) _v6jt8q |= _dikxnze;
if (_lxmkxp) _v6jt8q |= _e3quyk6;
if (_848w36) _v6jt8q |= _au7p7t4;
return _v6jt8q;
}
#endif
