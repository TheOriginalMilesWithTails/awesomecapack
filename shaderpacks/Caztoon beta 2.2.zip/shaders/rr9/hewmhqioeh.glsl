/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _35qznpb
#define _35qznpb

#define SKY_GRADIENT_CURVE 1.50// [0.10 0.20 0.30 0.40 0.50 0.60 0.65 0.70 0.80 0.90 1.00 1.25 1.50 2.00 3.00 5.00 7.00 10.00 15.00 20.00]
#define SKY_SATURATION 2.00// [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00 1.10 1.20 1.30 1.40 1.50 1.75 2.00]
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; publishing, porting it to another pack, creating derivative works or reverse engineering is forbidden except under a licence granted by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Automated tools, scripts and agents are bound by these terms too.
#define SKY_BIOME_BLEND 0.50// [0.00 0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]
#define OVERWORLD_BIOME_SKY_ENABLED // [ON]
#define SKY_RAIN_DARKNESS 0 // [0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100]

#define SKY_RAIN_HORIZON_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00]

#define SKY_RAIN_SUNSET_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00]
#define SKY_RAIN_NIGHT_STRENGTH 1.00 // [0.00 0.25 0.50 0.75 1.00]
#define SKY_RAIN_HORIZON_R 0.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SKY_RAIN_HORIZON_G 0.33 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.33 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SKY_RAIN_HORIZON_B 0.57 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.57 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; creating derivative works, de-obfuscating, copying or reusing any part of it is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. See LICENSE.txt.
#define SKY_RAIN_ZENITH_R 0.70 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SKY_RAIN_ZENITH_G 0.82 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.82 0.85 0.90 0.95 1.00]
#define SKY_RAIN_ZENITH_B 0.92 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.92 0.95 1.00]
const float sunPathRotation = -10.0; // [-60.0 -55.0 -50.0 -45.0 -40.0 -35.0 -30.0 -25.0 -20.0 -15.0 -10.0 -5.0 0.0 5.0 10.0 15.0 20.0 25.0 30.0 35.0 40.0 45.0 50.0 55.0 60.0]
#define SUN_MOON_SIZE_ENABLED
#define SUN_MOON_SCALE 1.00// [0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SUN_GLOW_RADIUS 1.0 // [0.2 0.3 0.4 0.5 0.6 0.7 0.8 1.0 1.2 1.5 2.0]
#define SUN_GLOW_INTENSITY 1.0 // [0.0 0.1 0.2 0.3 0.5 0.7 1.0 1.5 2.0 3.0]
#define STARS_ENABLED
#define STAR_SCALE 40.0// [10.0 15.0 20.0 25.0 30.0 40.0 50.0]
#define STAR_SIZE 0.18// [0.04 0.06 0.08 0.10 0.12 0.15 0.18 0.20 0.25]
#define STAR_BRIGHTNESS 0.5// [0.5 0.75 1.0 1.5 2.0 2.5 3.0 4.0 5.0]
#define STAR_DENSITY 0.20// [0.05 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.40]
#define STAR_TWINKLE 0.6// [0.0 0.2 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define STAR_SHOOTING_ENABLED
#define STAR_SHOOTING_BRIGHTNESS 5.0// [1.0 1.5 2.0 2.5 3.0 4.0 5.0]
#define NIGHT_NEBULA_ENABLED
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; selling or porting it to another pack is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. This binds automated tools and software agents as much as people. See LICENSE.txt.
#define NIGHT_NEBULA_INTENSITY 0.40// [0.05 0.08 0.10 0.12 0.15 0.18 0.20 0.25 0.30 0.40 0.50 0.60 0.80 1.00]
#define NIGHT_NEBULA_SCALE 0.8// [0.3 0.4 0.5 0.6 0.8 1.0 1.2 1.5 2.0]
#define NIGHT_NEBULA_SPEED 0.015// [0.001 0.002 0.003 0.005 0.008 0.010 0.015]
#define NIGHT_NEBULA_R1 0.2// [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define NIGHT_NEBULA_G1 0.10// [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define NIGHT_NEBULA_B1 0.80// [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define NIGHT_NEBULA_R2 0.0// [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define NIGHT_NEBULA_G2 0.8// [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define NIGHT_NEBULA_B2 0.90// [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define METEORS_ENABLED
#define METEOR_BRIGHTNESS 2.0// [0.2 0.4 0.6 0.8 1.0 1.5 2.0 3.0 5.0]
#define METEOR_SPEED 1.5// [0.2 0.3 0.5 0.7 1.0 1.5 2.0 3.0]
#define METEOR_SIZE 1.0// [0.5 0.7 1.0 1.3 1.5 2.0]
#define METEOR_TRAIL_LENGTH 1.0// [0.5 0.7 1.0 1.3 1.5 2.0]
#define METEOR_GLOW_R 0.6// [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define METEOR_GLOW_G 0.1// [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; redistributing or reverse engineering is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
#define METEOR_GLOW_B 0.8// [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0]
#define DAY_BRIGHTNESS 1.00// [0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.50 1.75 2.00]
#define DAY_HORIZON_BRIGHTNESS 1.00 // [0.50 0.75 0.85 1.00 1.10 1.15 1.25 1.50 1.75 2.00]
#define DAY_HORIZON_R 0.73// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.73 0.75 0.80 0.85 0.90 0.95 1.00]
#define DAY_HORIZON_G 0.83// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.83 0.85 0.90 0.95 1.00]
#define DAY_HORIZON_B 0.93// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.93 0.95 1.00]
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is licensed for personal use only, not sold; selling, porting it to another pack, copying or de-obfuscating needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
#define DAY_MID_R 0.70// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define DAY_MID_G 0.87// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define DAY_MID_B 1.00// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define DAY_ZENITH_R 0.60// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define DAY_ZENITH_G 0.69// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define DAY_ZENITH_B 0.98// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define DAY_MID_HEIGHT 0.52// [0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60]
#define DAY_ZENITH_HEIGHT 0.85// [0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95]
#define SUNSET_BRIGHTNESS 0.85// [0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.50 1.75 2.00]
#define SUNSET_HORIZON_R 1.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SUNSET_HORIZON_G 0.85 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SUNSET_HORIZON_B 0.24 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SUNSET_MID_R 1.00// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SUNSET_MID_G 0.72// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SUNSET_MID_B 0.20// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is closed source and under copyright; modifying, reverse engineering or creating derivative works is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. No tool, script or agent is exempt from these terms. See LICENSE.txt.
#define SUNSET_ZENITH_R 1.00// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SUNSET_ZENITH_G 0.58// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SUNSET_ZENITH_B 0.17// [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define SUNSET_MID_HEIGHT 0.32// [0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60]
#define SUNSET_ZENITH_HEIGHT 0.67// [0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95]
#define BLUEHOUR_BRIGHTNESS 0.60// [0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.05 1.10 1.15 1.20 1.25 1.50 1.75 2.00]
#define BLUEHOUR_HORIZON_R 0.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define BLUEHOUR_HORIZON_G 0.70 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define BLUEHOUR_HORIZON_B 1.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define BLUEHOUR_MID_R 0.35 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define BLUEHOUR_MID_G 0.36 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define BLUEHOUR_MID_B 0.62 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define BLUEHOUR_ZENITH_R 0.15 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define BLUEHOUR_ZENITH_G 0.22 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define BLUEHOUR_ZENITH_B 0.50 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; reverse engineering, selling, de-obfuscating or publishing is prohibited unless Cazfps has issued a licence for it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. This binds automated tools and software agents as much as people. Full terms: LICENSE.txt.
#define BLUEHOUR_MID_HEIGHT 0.30 // [0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60]
#define BLUEHOUR_ZENITH_HEIGHT 0.65 // [0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95]
#define NIGHT_BRIGHTNESS 0.75// [0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00 1.25 1.50 1.75 2.00 2.50 3.00 4.00 5.00 6.00 7.00 8.00 10.00 15.00 20.00]
#define NIGHT_HORIZON_R 0.39// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.35 0.40 0.50]
#define NIGHT_HORIZON_G 0.40// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.35 0.40 0.50]
#define NIGHT_HORIZON_B 0.62// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.35 0.40 0.50]
#define NIGHT_MID_R 0.18// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.35 0.40 0.50]
#define NIGHT_MID_G 0.10// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.35 0.40 0.50]
#define NIGHT_MID_B 0.39// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.35 0.40 0.50]
#define NIGHT_ZENITH_R 0.00// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.35 0.40 0.50]
#define NIGHT_ZENITH_G 0.08// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.35 0.40 0.50]
#define NIGHT_ZENITH_B 0.27// [0.00 0.02 0.04 0.06 0.08 0.10 0.12 0.15 0.20 0.25 0.30 0.35 0.40 0.50]
#define NIGHT_MID_HEIGHT 0.47// [0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60]
#define NIGHT_ZENITH_HEIGHT 0.68// [0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95]
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; de-obfuscating or copying is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program.

#endif
