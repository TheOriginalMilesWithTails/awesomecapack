/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _b8w8u60
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; copying or porting it to another pack is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
#define _b8w8u60
#include "/rr9/0frrosz9tw.glsl"
#ifdef FLAT_FAR_SHADOWS

vec3 _eerufk(vec3 _j88cy3, vec3 _t2zyyw, vec3 _4feio1) {
vec3 a = abs(_t2zyyw);
vec3 n = a.x > a.y && a.x > a.z ? vec3(sign(_t2zyyw.x), 0.0, 0.0)
: a.y > a.z ? vec3(0.0, sign(_t2zyyw.y), 0.0) : vec3(0.0, 0.0, sign(_t2zyyw.z));
vec3 _etq2ri = floor(_j88cy3 + _4feio1 - n * 0.05);
return _etq2ri + 0.5 + n * 0.55 + vec3(0.0, 1.0, 0.0) - _4feio1;
}

bool _ecp68q(vec3 _36evey, float _2pm9mr, float _yz6hsm) {
return _2pm9mr / max(length(_36evey), 0.001) < _yz6hsm * float(FLAT_FAR_SHADOW_PIXELS);
}
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; porting it to another pack, decompiling or reverse engineering is off limits unless Cazfps personally licensed it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com.

float _9fkw75(float _n6pnte) {
float _wt0qvt = 1.0 - FLAT_FAR_FACE_SHADING * (1.0 - smoothstep(0.02, 0.30, _n6pnte));
if (_wt0qvt >= 0.9999) return 1.0;
return 0.02 + 0.28 * (0.5 - sin(asin(clamp(1.0 - 2.0 * _wt0qvt, -1.0, 1.0)) / 3.0));
}
#endif
#endif
