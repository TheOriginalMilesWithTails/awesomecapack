/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _75sb7d8
#define _75sb7d8

#include "/rr9/iruqbe0rms.glsl"
float _0cn1qb(ivec2 _btdiwo, vec2 uv) {
float _e28jik = texelFetch(depthtex0, _btdiwo, 0).r;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is confidential, proprietary work; redistributing, modifying, reverse engineering or reusing any part of it is not allowed without a licence issued by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
if (_e28jik < 0.99999994) {
vec4 _bnxcpt = gbufferProjectionInverse * vec4(vec3(uv, _e28jik) * 2.0 - 1.0, 1.0);
return length(_bnxcpt.xyz / _bnxcpt.w);
}
if (abs(vxProjInv[0][0]) + abs(vxProjInv[1][1]) > 0.0) {
float _e8pi2y = texelFetch(vxDepthTexOpaque, _btdiwo, 0).r;
float _fqlhpe = texelFetch(vxDepthTexTrans, _btdiwo, 0).r;
float _bnzkov = _e8pi2y > 0.0 && _e8pi2y < 1.0 ? _e8pi2y : 1.0;
if (_fqlhpe > 0.0 && _fqlhpe < _bnzkov) _bnzkov = _fqlhpe;
if (_bnzkov < 1.0) {
vec4 _bnxcpt = vxProjInv * vec4(vec3(uv, _bnzkov) * 2.0 - 1.0, 1.0);
return length(_bnxcpt.xyz / _bnxcpt.w);
}
}
return 4096.0;
}
#endif
// Cazfps holds all rights to Caztoon beta 2.2. The code is licensed for personal use only, not sold; creating derivative works, de-obfuscating, copying or reverse engineering is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
