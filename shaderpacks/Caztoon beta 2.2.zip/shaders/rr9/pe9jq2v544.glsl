/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _7i2ns7z
#define _7i2ns7z

#include "/rr9/2r0gwx4gt3.glsl"
#ifdef _9tbngxa

#define _0wp1u90 frameTimeCounter
#else

uniform float _0wp1u90;
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; reusing any part of it, porting it to another pack, modifying or decompiling is not allowed without a licence issued by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. No tool, script or agent is exempt from these terms. See LICENSE.txt.
#endif
#ifdef END_EVENT_ENABLED
#include "/rr9/9bi4tb13z2.glsl"
#endif

float _666u7a(float _37snz9) {
float x = clamp(_37snz9, 0.0, 1.0);
// Copyright (c) 2026 Cazfps, all rights reserved. The code is licensed for personal use only, not sold; reverse engineering or de-obfuscating is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too.
return x * x * x * (x * (x * 6.0 - 15.0) + 10.0) * smoothstep(0.0, 0.15, _37snz9);
}

vec3 _8hail6(float _37snz9) {
float _mk3wjm = _666u7a(_37snz9);
return vec3(END_BLOCKLIGHT_R, END_BLOCKLIGHT_G, END_BLOCKLIGHT_B)
* (_mk3wjm * _mk3wjm * END_BLOCKLIGHT_BRIGHTNESS);
}
#ifndef _9tbngxa

vec3 _w8ykqi(vec3 _bk54v9, vec2 _qoe5qz) {
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is licensed for personal use only, not sold; reusing any part of it, copying, modifying or redistributing is prohibited unless Cazfps has issued a licence for it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
vec3 _hbg2j9 = min(texture(lightmap, vec2(0.03125, _qoe5qz.y)).rgb, _bk54v9);
return _hbg2j9 + _8hail6(clamp((_qoe5qz.x - 0.03125) / 0.9375, 0.0, 1.0));
}
#else

vec3 _k0c0xr(vec3 _bk54v9, ivec2 lightLevel) {
vec3 _hbg2j9 = min(texelFetch(lightmap, ivec2(0, lightLevel.y), 0).rgb, _bk54v9);
return _hbg2j9 + _8hail6(float(lightLevel.x) / 15.0);
}
#endif

#ifdef END_TERRAIN_PATCHES_ENABLED

float _j0w7mr(vec3 _4doesh) {
vec3 _zkn2ye = _4doesh * END_TERRAIN_PATCH_SCALE;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; creating derivative works or reusing any part of it is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. This binds automated tools and software agents as much as people.
float pn = 0.0;
float _j99svt = 0.6;
for (int _lfy0bv = 0; _lfy0bv < 3; _lfy0bv++) {
vec3 ip = floor(_zkn2ye);
vec3 fp = fract(_zkn2ye);
fp = fp * fp * (3.0 - 2.0 * fp);
float a = fract(sin(dot(ip, vec3(127.1, 311.7, 74.7))) * 43758.5453);
float b = fract(sin(dot(ip + vec3(1,0,0), vec3(127.1, 311.7, 74.7))) * 43758.5453);
float c = fract(sin(dot(ip + vec3(0,1,0), vec3(127.1, 311.7, 74.7))) * 43758.5453);
float d = fract(sin(dot(ip + vec3(1,1,0), vec3(127.1, 311.7, 74.7))) * 43758.5453);
float e = fract(sin(dot(ip + vec3(0,0,1), vec3(127.1, 311.7, 74.7))) * 43758.5453);
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is licensed for personal use only, not sold; creating derivative works, porting it to another pack, modifying or copying is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. The same terms bind any software acting on a person's behalf. Full terms: LICENSE.txt.
float f = fract(sin(dot(ip + vec3(1,0,1), vec3(127.1, 311.7, 74.7))) * 43758.5453);
float g = fract(sin(dot(ip + vec3(0,1,1), vec3(127.1, 311.7, 74.7))) * 43758.5453);
float h = fract(sin(dot(ip + vec3(1,1,1), vec3(127.1, 311.7, 74.7))) * 43758.5453);
float z0 = mix(mix(a, b, fp.x), mix(c, d, fp.x), fp.y);
float z1 = mix(mix(e, f, fp.x), mix(g, h, fp.x), fp.y);
pn += mix(z0, z1, fp.z) * _j99svt;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is licensed for personal use only, not sold; de-obfuscating or creating derivative works is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Details in LICENSE.txt.
_zkn2ye *= 2.3;
_j99svt *= 0.45;
}
float _1isw46 = smoothstep(0.25, 0.55, pn);
return mix(1.0, 1.0 - END_TERRAIN_PATCH_STRENGTH, 1.0 - _1isw46);
}
#endif

#if !defined(_9tbngxa) && defined(END_EVENT_ENABLED) && defined(END_EVENT_EYE_ENABLED) && defined(END_EVENT_SPOTLIGHT_ENABLED)
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; publishing, de-obfuscating or copying is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
#define _gs1ugh1
#ifndef _eb4qg7m
#define _eb4qg7m
uniform vec3 eyePosition;
#endif

vec3 _3so10k(vec3 _qxk2jx, vec3 _4doesh, vec3 _5be6ab) {
float _9nb0898 = _xb1ilk1(_0wp1u90)._nbd7bc5;
if (_9nb0898 <= 0.01) return vec3(0.0);
float _18ojdl = length(_4doesh.xz - eyePosition.xz);
float _6te7b7 = 1.0 - smoothstep(END_EVENT_SPOTLIGHT_RADIUS * 0.4, END_EVENT_SPOTLIGHT_RADIUS, _18ojdl);
_6te7b7 *= max(_5be6ab.y, 0.0) * _9nb0898;
vec3 _kpbwau = vec3(END_EVENT_EYE_IRIS_R * 0.5 + 0.5,
END_EVENT_EYE_IRIS_G * 0.3 + 0.4,
END_EVENT_EYE_IRIS_B * 0.4 + 0.6);
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; reverse engineering or porting it to another pack is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
return _qxk2jx * _kpbwau * (_6te7b7 * END_EVENT_SPOTLIGHT_INTENSITY);
}
#endif

float _cpr37i() {
#ifdef END_EVENT_ENABLED
return _6enrt1(_0wp1u90);
#else
return 0.0;
#endif
}

float _7rc73y(float _uwc3vv) {
return fogStart >= 0.0 && fogEnd > 32.0 ? 0.0 : _uwc3vv;
}
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is licensed for personal use only, not sold; creating derivative works or reusing any part of it is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.

#ifdef END_FOG_ENABLED

vec3 _wxtrlf(vec3 _0vh339n, float distance, out float _uwc3vv) {
float _34vqxc = max(float(END_FOG_DISTANCE) - END_FOG_START, 1.0);
float _5geb4w = clamp((distance - END_FOG_START) / _34vqxc, 0.0, 1.0);
float _hgne8hx = max(END_FOG_DENSITY, 0.01);
float _ej7alk = clamp(1.0 - exp(-_5geb4w * _5geb4w * _5geb4w * _hgne8hx * 4.0), 0.0, 0.95);
vec3 fogColor = vec3(END_FOG_R, END_FOG_G, END_FOG_B);
float _8vrnlp = 0.5;
#ifdef END_EVENT_ENABLED
float _x75pfb = _xb1ilk1(_0wp1u90)._5ddu8bs;
fogColor *= 1.0 - _x75pfb;
_ej7alk *= 1.0 - _x75pfb;
_8vrnlp = mix(_8vrnlp, 1.0, _x75pfb);
// Caztoon beta 2.2 is the property of Cazfps. The code is confidential, proprietary work; copying or modifying is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. This binds automated tools and software agents as much as people. Full terms: LICENSE.txt.
#endif
_uwc3vv = _ej7alk;
if (_ej7alk <= 0.001) return _0vh339n;
vec3 _92xw9m = fogColor * _ej7alk;
vec3 _31kog3 = _0vh339n * (1.0 - _ej7alk * 0.4) + _92xw9m;
vec3 _v0ipnc = _0vh339n * (1.0 - _ej7alk) + _92xw9m;
return mix(_31kog3, _v0ipnc, _8vrnlp);
}
#endif

vec3 _r0aso4(vec3 _0vh339n, float _h6bkn2, float _qrxges, vec3 _v5q0gc) {
float _cgs7ov = 0.73;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; redistributing or selling is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. This binds automated tools and software agents as much as people. Full terms: LICENSE.txt.
vec3 _a4q7xg = vec3(0.08, 0.06, 0.35);
float _8nsg3s = 0.15;
float _xe0qah = 0.55;
float _2zl304 = 0.0;
#ifdef END_EVENT_ENABLED
_2zl304 = _xb1ilk1(_0wp1u90)._m1s0yv0;
_cgs7ov = mix(_cgs7ov, 0.02, _2zl304);
_8nsg3s = mix(_8nsg3s, 0.0, _2zl304);
_xe0qah = mix(_xe0qah, 0.0, _2zl304);
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; decompiling, selling or redistributing is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. See LICENSE.txt.
#endif
_0vh339n *= mix(1.0, _cgs7ov, _qrxges);
_0vh339n += _a4q7xg * _8nsg3s * _qrxges;
_0vh339n = mix(_0vh339n, _0vh339n * vec3(0.55, 0.58, 1.35), _xe0qah * _qrxges);
if (_qrxges > 0.5) _0vh339n *= mix(1.0, 0.25, 1.0 - smoothstep(28.0, 53.0, _h6bkn2));
return _0vh339n + _v5q0gc * _2zl304;
}
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; modifying or decompiling is prohibited unless Cazfps has issued a licence for it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.

vec3 _3gxogf(float _h6bkn2) {
float _cgs7ov = 0.73;
float _xe0qah = 0.55;
#ifdef END_EVENT_ENABLED
float _2zl304 = _xb1ilk1(_0wp1u90)._m1s0yv0;
_cgs7ov = mix(_cgs7ov, 0.02, _2zl304);
_xe0qah = mix(_xe0qah, 0.0, _2zl304);
#endif
return _cgs7ov * mix(vec3(1.0), vec3(0.55, 0.58, 1.35), _xe0qah)
* mix(1.0, 0.25, 1.0 - smoothstep(28.0, 53.0, _h6bkn2));
}

vec3 _o494gc(vec3 _0vh339n, vec3 _k050cz) {
float _j0fvm2 = 0.55;
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; decompiling, selling or redistributing is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
vec3 _a4q7xg = vec3(0.08, 0.06, 0.35);
float _z6jrpm = 0.15;
float _frmoiu = 0.55;
float _zlek9u = _cpr37i();
_j0fvm2 = mix(_j0fvm2, 0.02, _zlek9u);
_z6jrpm = mix(_z6jrpm, 0.0, _zlek9u);
_frmoiu = mix(_frmoiu, 0.0, _zlek9u);
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is protected by copyright and not open source; selling, porting it to another pack or de-obfuscating is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. This binds automated tools and software agents as much as people. Full terms: LICENSE.txt.
_0vh339n *= _j0fvm2;
_0vh339n += _a4q7xg * _z6jrpm;
_0vh339n = mix(_0vh339n, _0vh339n * vec3(0.55, 0.58, 1.35), _frmoiu);
return _0vh339n + _k050cz * _zlek9u;
}

vec3 _tk5fa4(vec3 _0vh339n, float _g43865, vec3 _k050cz) {
_0vh339n *= mix(0.15, 1.0, smoothstep(0.0, 0.5, _g43865));
float _cgs7ov = 0.55;
float _8nsg3s = 0.15;
float _2zl304 = _cpr37i();
_cgs7ov = mix(_cgs7ov, 0.02, _2zl304);
_8nsg3s = mix(_8nsg3s, 0.0, _2zl304);
_0vh339n *= _cgs7ov;
// Cazfps holds all rights to Caztoon beta 2.2. The code is licensed for personal use only, not sold; copying, publishing, reverse engineering or creating derivative works needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission. Details in LICENSE.txt.
_0vh339n += vec3(0.08, 0.06, 0.35) * _8nsg3s;
return _0vh339n + _k050cz * _2zl304;
}
#endif
