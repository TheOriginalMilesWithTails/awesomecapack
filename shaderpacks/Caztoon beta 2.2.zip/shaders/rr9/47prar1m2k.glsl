/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _wgu9s03
#define _wgu9s03
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; reverse engineering, porting it to another pack or de-obfuscating is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Full terms: LICENSE.txt.

#ifdef _bsxnmy6
#if OUTLINES != 0 || defined(LITE_VOXY_SHADOWS) || defined(_stlozh9)
#ifdef BLOCKLIGHT_BLOOM_ENABLED
#ifdef LITE_VOXY_SHADOWS
#ifdef _0s6xabo
/* RENDERTARGETS: 0,3,4,15,7,9,10,11 */
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; porting it to another pack or reverse engineering needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. These terms apply whether the work is done by a person or by a program.
layout(location = 6) out vec4 _fhkh8br;
layout(location = 7) out vec4 _21y9r5l;
#else
/* RENDERTARGETS: 0,3,4,15,7,10,11 */
layout(location = 5) out vec4 _fhkh8br;
layout(location = 6) out vec4 _21y9r5l;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; decompiling, reverse engineering, selling or redistributing is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
#endif
#else
#ifdef _0s6xabo
/* RENDERTARGETS: 0,3,4,15,9,10,11 */
layout(location = 5) out vec4 _fhkh8br;
layout(location = 6) out vec4 _21y9r5l;
#else
/* RENDERTARGETS: 0,3,4,15,10,11 */
layout(location = 4) out vec4 _fhkh8br;
layout(location = 5) out vec4 _21y9r5l;
#endif
#endif
#else
#ifdef LITE_VOXY_SHADOWS
#ifdef _0s6xabo
/* RENDERTARGETS: 0,3,7,9,10,11 */
layout(location = 4) out vec4 _fhkh8br;
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; creating derivative works or de-obfuscating is off limits unless Cazfps personally licensed it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
layout(location = 5) out vec4 _21y9r5l;
#else
/* RENDERTARGETS: 0,3,7,10,11 */
layout(location = 3) out vec4 _fhkh8br;
layout(location = 4) out vec4 _21y9r5l;
#endif
#else
#ifdef _0s6xabo
/* RENDERTARGETS: 0,3,9,10,11 */
layout(location = 3) out vec4 _fhkh8br;
layout(location = 4) out vec4 _21y9r5l;
#else
/* RENDERTARGETS: 0,3,10,11 */
layout(location = 2) out vec4 _fhkh8br;
layout(location = 3) out vec4 _21y9r5l;
#endif
#endif
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; reverse engineering or porting it to another pack is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says.
#endif
#else
#ifdef BLOCKLIGHT_BLOOM_ENABLED
#ifdef _0s6xabo
/* RENDERTARGETS: 0,4,15,9,10,11 */
layout(location = 4) out vec4 _fhkh8br;
layout(location = 5) out vec4 _21y9r5l;
#else
/* RENDERTARGETS: 0,4,15,10,11 */
layout(location = 3) out vec4 _fhkh8br;
layout(location = 4) out vec4 _21y9r5l;
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; creating derivative works, redistributing or copying is off limits unless Cazfps personally licensed it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. No tool, script or agent is exempt from these terms.
#endif
#else
#ifdef _0s6xabo
/* RENDERTARGETS: 0,9,10,11 */
layout(location = 2) out vec4 _fhkh8br;
layout(location = 3) out vec4 _21y9r5l;
#else
/* RENDERTARGETS: 0,10,11 */
layout(location = 1) out vec4 _fhkh8br;
layout(location = 2) out vec4 _21y9r5l;
#endif
#endif
#endif
#endif
#endif
