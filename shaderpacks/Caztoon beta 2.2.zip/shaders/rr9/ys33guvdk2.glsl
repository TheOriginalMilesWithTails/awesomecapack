/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _3z4zwaf
#define _3z4zwaf

#define SWAMP_MUD_ENABLED

#define SWAMP_MUD_AMOUNT 1.00 // [0.25 0.50 0.75 1.00 1.25 1.50 2.00]
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is confidential, proprietary work; copying, reusing any part of it, reverse engineering or redistributing is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.

#define SWAMP_MUD_STRENGTH 1.00 // [0.25 0.50 0.75 1.00 1.25 1.50]

#define SWAMP_MUD_PIXEL_SIZE 16 // [4 8 16 32]

#define SWAMP_MUD_DRIFT_SPEED 1.00 // [0.00 0.25 0.50 0.75 1.00 1.50 2.00 3.00]

#define SWAMP_UNDERWATER_FOG 1.00 // [0.00 0.25 0.50 0.75 1.00]
#endif
