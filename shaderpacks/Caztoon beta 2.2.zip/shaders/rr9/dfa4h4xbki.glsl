/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _m5c19g3
#define _m5c19g3
#define SURFACE_TIME_TINT_ENABLED
#define SHADOW_COLOR_TINT_ENABLED

#define SHADOW_HUE 45.0 // [-180.0 -165.0 -150.0 -135.0 -120.0 -105.0 -90.0 -75.0 -60.0 -45.0 -30.0 -15.0 0.0 15.0 30.0 45.0 60.0 75.0 90.0 105.0 120.0 135.0 150.0 165.0 180.0]
#define SHADOW_SATURATION 1.75 // [0.0 0.1 0.2 0.3 0.4 0.5 0.6 0.7 0.8 0.9 1.0 1.25 1.5 1.75 2.0 2.5 3.0 4.0 5.0]
#define SKYLIGHT_COLOR_TINT 0.25 // [0.0 0.25 0.50 0.65 0.75 0.85 1.0 1.25 1.5 2.0]
#define SKYLIGHT_TINT_SATURATION 1.10 // [0.0 0.25 0.5 0.75 1.0 1.10 1.25 1.5 1.75 2.0 2.5 3.0 4.0 5.0]
#define SKYLIGHT_TINT_LIGHT_SATURATION 0.50 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]
#define SUNSET_TERRAIN_TINT 0.30 // [0.0 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 1.0 1.1 1.2 1.3 1.4 1.5]

#define SUNSET_SHADE_TINT 1.00 // [0.00 0.25 0.50 0.75 1.00 1.25 1.50 2.00 2.50 3.00]
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; porting it to another pack, decompiling or modifying is off limits unless Cazfps personally licensed it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. No tool, script or agent is exempt from these terms.
#if defined(SURFACE_TIME_TINT_ENABLED) || defined(SHADOW_COLOR_TINT_ENABLED)
#define _7lc484e
#endif
#endif
