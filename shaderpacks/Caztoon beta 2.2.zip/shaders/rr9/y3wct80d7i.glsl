/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _cb1d0r6
#define _cb1d0r6
#include "/rr9/0frrosz9tw.glsl"

vec4 _26em6t(vec4 _pje07k) {
return _pje07k;
}
mat4 _kozk5q(mat4 _4y3e5z) {
return _4y3e5z;
}
mat4 _3lmhxs(mat4 _kgzubp) {
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; redistributing or publishing needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
return _kgzubp;
}
#endif
