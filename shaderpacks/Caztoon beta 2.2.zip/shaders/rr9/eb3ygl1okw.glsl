/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _6ci4p9h
#define _6ci4p9h
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is confidential, proprietary work; redistributing, porting it to another pack, selling or decompiling needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. No tool, script or agent is exempt from these terms.

#include "/rr9/uneyo5e641.glsl"
#if (defined(_zwco3j1) && defined(GHIBLI_CLOUD_RAIN_FORMATION)) || (defined(_rukwfly) && defined(VANILLA_CLOUD_RAIN_FORMATION))
#define _z7nndpl
#endif
#endif
