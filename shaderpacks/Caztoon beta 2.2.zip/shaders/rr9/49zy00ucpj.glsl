/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _qaqjp6r
#define _qaqjp6r

#include "/rr9/vwgjca5fa4.glsl"
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; publishing, reverse engineering, de-obfuscating or porting it to another pack is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Full terms: LICENSE.txt.
#include "/rr9/hewmhqioeh.glsl"
#include "/rr9/lhawfjjnae.glsl"
#include "/rr9/a4jzpp7xwj.glsl"
uniform float rainStrength;
uniform float wetness;
uniform vec3 fogColor;
uniform vec3 skyColor;
uniform int biome;
uniform int biome_category;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is confidential, proprietary work; de-obfuscating, copying or porting it to another pack is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
uniform float _mrimrha;
uniform float _nsfbxoa;
uniform float _smrslu3;
uniform float _m7u0xqr;
uniform float _1otw83g;
uniform float _nzm4xgr;
uniform float _njoa694;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; selling, porting it to another pack or publishing is not allowed without a licence issued by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Automated tools, scripts and agents are bound by these terms too. Details in LICENSE.txt.
#include "/rr9/l3t8ltb510.glsl"
#include "/rr9/atvv33fcg3.glsl"
#include "/rr9/sholfvxovm.glsl"
#include "/rr9/lj0wpa5iqz.glsl"
#include "/rr9/2sp95x393x.glsl"

vec3 _w0t9m4() {
float _bhxgb0;
vec3 _u5elab = _y7b8vc(1.0, _bhxgb0);
if (_bhxgb0 > 0.001) _u5elab *= mix(1.0, 0.6, _bhxgb0);
vec4 _zrsols = texelFetch(colortex14, ivec2(0, 0), 0);
vec3 _hbg2j9 = _zrsols.a > 0.5 ? mix(_zrsols.rgb, _u5elab, 0.7) : _u5elab;
return clamp(max(_hbg2j9, vec3(0.0)) * RAIN_MIST_BRIGHTNESS, vec3(0.0), vec3(1.0));
}
#endif
