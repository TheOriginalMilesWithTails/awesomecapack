/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _wuzq3la
#define _wuzq3la

#define SUN_MOON_BLOOM_ENABLED
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is confidential, proprietary work; copying, reverse engineering, modifying or de-obfuscating is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
#define SUN_MOON_BLOOM 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0 4.0 5.0]
#define SUN_MOON_BLOOM_RADIUS 1.0 // [0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0]

#define SUN_GLARE 1.0 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0 3.0]

#endif
