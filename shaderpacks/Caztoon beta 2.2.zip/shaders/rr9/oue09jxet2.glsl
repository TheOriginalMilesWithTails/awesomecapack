/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifdef BLOCKLIGHT_BLOOM_ENABLED
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; redistributing, modifying, publishing or copying is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. See LICENSE.txt.
uniform float viewHeight;
flat out float _x0aml1g;
#endif
