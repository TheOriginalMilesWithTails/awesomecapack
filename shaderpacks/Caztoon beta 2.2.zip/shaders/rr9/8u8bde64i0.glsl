/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _k689y2x
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; copying or reverse engineering is prohibited unless Cazfps has issued a licence for it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Automated tools, scripts and agents are bound by these terms too. Details in LICENSE.txt.
#define _k689y2x

#include "/rr9/uneyo5e641.glsl"
#include "/rr9/lhawfjjnae.glsl"
#ifdef _65jbzyx
#define _zw1n988
#include "/rr9/f8akl8gy30.glsl"
#if defined(LITE_COLORTEX_BLOOM)
uniform sampler2D colortex27;
#endif
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; porting it to another pack, creating derivative works, redistributing or copying is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
#include "/rr9/7u6wg6ss8e.glsl"

float _voaz43(vec3 _deg898n, vec2 uv, float _662kex) {
ivec2 _plevir = _apx1zv();
vec2 _5r0rfx = _2a95ps(clamp(ivec2(uv * vec2(_plevir)), ivec2(0), _plevir - 1));
float _kozpav = clamp(_5r0rfx.r, 0.0, 1.0);
if (_kozpav <= 0.001 || _5r0rfx.g <= 0.001) return 1.0;
if (-_deg898n.z < _5r0rfx.g - max(2.0, _5r0rfx.g * 0.002)) return 1.0;
#ifdef CLOUDS_GHIBLI_ENABLED
_kozpav *= _p4wx4w(_5r0rfx.g / max(-normalize(_deg898n).z, 1e-6), _662kex);
#endif
return 1.0 - _kozpav;
}
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; modifying, copying or redistributing is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. This binds automated tools and software agents as much as people. See LICENSE.txt.
#endif
#endif
