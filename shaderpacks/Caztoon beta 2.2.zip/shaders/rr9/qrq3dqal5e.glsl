/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _q95oaqg
#define _q95oaqg

#include "/rr9/ys33guvdk2.glsl"
#ifdef SWAMP_MUD_ENABLED
#define _99cjr4g
#include "/rr9/28ibwlxer0.glsl"
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; modifying, reusing any part of it, creating derivative works or decompiling is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf. See LICENSE.txt.

float _x191o6(vec3 _9zezcay) {
return smoothstep(0.4, 0.9, (1.2 * _9zezcay.g - _9zezcay.b) / max(0.35 * _9zezcay.g, 1e-4));
}

float _v5u4po(vec2 _qqn63q, vec2 _etq2ri, float _n1ypfm, float _ep2p32) {
float _jfqkum = float(SWAMP_MUD_PIXEL_SIZE);
vec2 _k3gfsw = floor(_qqn63q * _jfqkum);
vec2 _btdiwo = _etq2ri + (_k3gfsw + 0.5) / _jfqkum;
float _eek883 = 6.2831853 * _n1ypfm / 3600.0;
float _lgekxc = max(SWAMP_MUD_DRIFT_SPEED, 0.0);
vec2 p = _btdiwo - (0.12 * 3600.0 / 6.2831853 * _lgekxc) * vec2(cos(_eek883), sin(_eek883));
float _8u3zxd = 20.0 * _lgekxc * sin(_eek883 + 1.3);
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; publishing, porting it to another pack, redistributing or selling is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf. Full terms: LICENSE.txt.

p += 3.0 * (vec2(_1gjro1(vec3(p * 0.05, 3.1 + 0.3 * _8u3zxd)), _1gjro1(vec3(p * 0.05, 7.7 + 0.3 * _8u3zxd))) - 0.5);

float n = 0.0;
float _6xizlb = 0.5;
float _yz6hsm = 0.09;
for (int i = 0; i < 4; i++) {
n += _6xizlb * _1gjro1(vec3(p * _yz6hsm, 11.0 + 4.0 * float(i) + (1.0 + 0.3 * float(i)) * _8u3zxd));
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; creating derivative works, modifying, decompiling or reverse engineering is off limits unless Cazfps personally licensed it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too.
_6xizlb *= 0.5;
_yz6hsm *= 2.03;
}
n /= 0.9375;
float _ticp8b = 0.58 - 0.04 * (SWAMP_MUD_AMOUNT - 1.0);

uvec2 id = uvec2(ivec2(_k3gfsw) + ivec2(_etq2ri) * SWAMP_MUD_PIXEL_SIZE) * uvec2(1597334673u, 3812015801u);
uint _u5lbo7 = (id.x ^ id.y) * 1597334673u;
_u5lbo7 = (_u5lbo7 ^ (_u5lbo7 >> 16)) * 2246822519u;
_u5lbo7 ^= _u5lbo7 >> 13;
float _vmnoie = 0.7 * float(_u5lbo7 & 65535u) / 65535.0 + 0.3 * _1gjro1(vec3(_btdiwo * (0.25 * _jfqkum), 23.0)) - 0.5;
float _fotkmo = 1.0 - smoothstep(0.35, 0.7, _ep2p32);
float _hnrz6l = 0.0;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; copying, modifying, redistributing or publishing is forbidden except under a licence granted by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Automated tools, scripts and agents are bound by these terms too.
for (int k = 0; k < 3; k++) {
float _37snz9 = n - _ticp8b - 0.07 * float(k);
_hnrz6l += mix(clamp(_37snz9 / 0.025 + 0.5, 0.0, 1.0), step(0.0, _37snz9 + 0.045 * _vmnoie), _fotkmo);
}
return _hnrz6l;
}

float _7paj6v(float _hnrz6l, float _kp86g4) {
return min(_hnrz6l, 1.0) * _kp86g4 * min(SWAMP_MUD_STRENGTH, 1.0);
}

vec4 _xwbam9(float _hnrz6l, bool _mp6qa5) {
vec4 _anpq69 = vec4(0.30, 0.285, 0.145, 0.88);
vec4 _0h29ta = vec4(0.26, 0.235, 0.11, 0.94);
vec4 _6yis5e = vec4(0.22, 0.19, 0.085, 0.97);
vec4 _p75dwq = _hnrz6l < 2.0 ? mix(_anpq69, _0h29ta, clamp(_hnrz6l - 1.0, 0.0, 1.0)) : mix(_0h29ta, _6yis5e, _hnrz6l - 2.0);
return _mp6qa5 ? vec4(_p75dwq.rgb * 0.55, min(_p75dwq.a + 0.06, 1.0)) : _p75dwq;
}
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is confidential, proprietary work; publishing, selling, creating derivative works or de-obfuscating is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.

vec4 _rpd6ix(vec4 _czrnnz, float _hnrz6l, float _uwc3vv, bool _mp6qa5) {
vec4 _p75dwq = _xwbam9(_hnrz6l, _mp6qa5);
return vec4(mix(_czrnnz.rgb, _p75dwq.rgb, _uwc3vv), mix(_czrnnz.a, _p75dwq.a, _uwc3vv));
}
#endif
#endif
