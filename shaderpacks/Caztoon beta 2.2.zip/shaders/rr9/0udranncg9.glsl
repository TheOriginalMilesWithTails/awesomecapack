/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _l16qrhg
#define _l16qrhg

#define CLOUDS_VANILLA_ENABLED
#define VANILLA_CLOUD_HEIGHT 200.0 // [80.0 100.0 128.0 150.0 192.0 200.0 250.0 300.0 400.0 500.0]
#define VANILLA_CLOUD_THICKNESS 4.0 // [2.0 4.0 6.0 8.0 12.0 16.0 24.0 32.0]
#define VANILLA_CLOUD_SPEED 2.0 // [0.0 2.0 4.0 6.0 8.0 12.0 16.0 24.0 32.0]
#define VANILLA_CLOUD_BRIGHTNESS 2.0 // [0.5 0.7 0.8 0.9 1.0 1.1 1.2 1.4 1.6 1.8 2.0]
#define VANILLA_CLOUD_DISTANCE 3000 // [2000 3000 4000 5000 6000 8000 10000 16000 30000]
#define VANILLA_CLOUD_NIGHT_OPACITY_REDUCTION 95 // [0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100]
#define VANILLA_CLOUD_SIDE_DARKNESS 20 // [0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100]
#define VANILLA_CLOUD_BOTTOM_DARKNESS 5 // [0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100]
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is licensed for personal use only, not sold; porting it to another pack, redistributing, reverse engineering or selling is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program.
#define VANILLA_CLOUD_R 1.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define VANILLA_CLOUD_G 1.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define VANILLA_CLOUD_B 1.00 // [0.00 0.05 0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.75 0.80 0.85 0.90 0.95 1.00]
#define VANILLA_CLOUD_LAYER_SPACING 128.0 // [2.0 4.0 6.0 8.0 12.0 16.0 24.0 32.0 48.0 64.0 96.0 128.0 192.0 256.0]
#define VANILLA_CLOUD_L1_COVERAGE 0.80 // [0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.70 0.80]
#define VANILLA_CLOUD_L1_PIXEL_SIZE 6.0 // [4.0 6.0 8.0 10.0 12.0 16.0 20.0 24.0 32.0]
#define VANILLA_CLOUD_L1_OPACITY 100 // [0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100]
#define VANILLA_CLOUD_L2_COVERAGE 0.50 // [0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.70 0.80]
#define VANILLA_CLOUD_L2_PIXEL_SIZE 4.0 // [4.0 6.0 8.0 10.0 12.0 16.0 20.0 24.0 32.0]
#define VANILLA_CLOUD_L2_OPACITY 25 // [0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100]
#define VANILLA_CLOUD_L3_COVERAGE 0.65 // [0.10 0.15 0.20 0.25 0.30 0.35 0.40 0.45 0.50 0.55 0.60 0.65 0.70 0.80]
#define VANILLA_CLOUD_L3_PIXEL_SIZE 4.0 // [4.0 6.0 8.0 10.0 12.0 16.0 20.0 24.0 32.0]
#define VANILLA_CLOUD_L3_OPACITY 5 // [0 5 10 15 20 25 30 35 40 45 50 55 60 65 70 75 80 85 90 95 100]

#define VANILLA_CLOUD_RAIN_FORMATION
#define VANILLA_CLOUD_RAIN_COVER 1.00 // [0.25 0.40 0.55 0.70 0.85 1.00]
#define VANILLA_CLOUD_RAIN_GAP_SIZE 1 // [1 2 3]

#define VANILLA_CLOUD_SHADOWS 1 // [0 1 2]
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; de-obfuscating or reusing any part of it is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too. Details in LICENSE.txt.
#define VANILLA_CLOUD_SHADOW_STRENGTH 0.40 // [0.10 0.20 0.30 0.40 0.50 0.60 0.70 0.80 0.90 1.00]

#define VANILLA_CLOUD_SHADOW_SOFTNESS 1.00 // [0.00 0.25 0.50 0.75 1.00]

#ifdef CLOUDS_VANILLA_ENABLED
#ifndef CLOUDS_GHIBLI_ENABLED
#define _eflkbd5
#endif
#endif
#if defined(CLOUDS_GHIBLI_ENABLED) || defined(_eflkbd5)
#define _65jbzyx
#endif
#ifdef _eflkbd5

#define _rukwfly
#if VANILLA_CLOUD_SHADOWS > 0
#define _iy7t50j
#endif
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is licensed for personal use only, not sold; de-obfuscating, reverse engineering, publishing or decompiling is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.
#endif
#endif
