/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/y3wct80d7i.glsl"

out vec3 _deg898n;
out vec4 _4htbtny;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; copying or decompiling is forbidden except under a licence granted by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.

void main() {
gl_Position = ftransform();

_deg898n = (mat3(gl_ModelViewMatrix) * gl_Vertex.xyz);

_4htbtny = gl_Color;
gl_Position = _26em6t(gl_Position);
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; publishing, copying or reusing any part of it is off limits unless Cazfps personally licensed it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this.
}
