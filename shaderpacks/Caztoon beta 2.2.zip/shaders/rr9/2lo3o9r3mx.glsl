/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _wwxonxb
#define _wwxonxb

#include "/rr9/i9knobfrhl.glsl"
#ifdef _owayyrc
// Copyright (c) 2026 Cazfps, all rights reserved. The code is protected by copyright and not open source; redistributing, decompiling, selling or creating derivative works needs a licence from Cazfps, and nothing less. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.

#define _dlnwbej 3
#define _2m8jhhn 2.0
#define _jo1arhv 0.15
#define _4jisp0q 0.63
#define _uenoj83 5.0
#define _vnyl4eb 1.6
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; selling, decompiling, redistributing or publishing is prohibited unless Cazfps has issued a licence for it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. Automated tools, scripts and agents are bound by these terms too.

bool _aqbwqo(int id) {
return id == 10001 || id == 10039 || id == 10005 || id == 10082 || id == 10201
|| (id >= 10002 && id <= 10004) || (id >= 10102 && id <= 10104) || id == 10202 || id == 10203
|| (id >= 10205 && id <= 10207) || id == 10018 || id == 10019 || (id >= 10060 && id <= 10062)
|| id == 10006 || (id >= 10020 && id <= 10022) || id == 10094
|| (id >= 10131 && id <= 10139) || id == 10008 || id == 10260 || id == 10261 || id == 10262;
}

#if (defined(_0s6xabo) && defined(_q1mg2jt)) || (defined(_9tbngxa) && !defined(_bbr0ecr))
#define _jgty2ky
#ifndef _9tbngxa

uniform float _5dyniss;
#endif

float _bmgrp9(ivec2 i) {
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is protected by copyright and not open source; selling or reverse engineering is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
uvec2 q = uvec2(i) * uvec2(1597334673u, 3812015801u);
uint h = (q.x ^ q.y) * 1597334673u;
h ^= h >> 16;
h *= 2246822519u;
h ^= h >> 13;
return float(h >> 8) * (1.0 / 16777216.0);
}

vec3 _rwtbqh(ivec2 _etq2ri, vec2 _qqn63q, int k, vec2 _848w36) {
ivec2 b = _etq2ri * k;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; creating derivative works or decompiling needs a licence from Cazfps, and nothing less. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. This binds automated tools and software agents as much as people.
vec2 q = vec2(b & 15) * (1.0 / 16.0) + _qqn63q * (float(k) / 16.0) + _848w36;
vec2 _k3gfsw = floor(q);
ivec2 i = (b >> 4) + ivec2(_k3gfsw);
vec2 f = q - _k3gfsw;
vec2 u = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);
vec2 du = 30.0 * f * f * (f * (f - 2.0) + 1.0);
float a = _bmgrp9(i);
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; decompiling or publishing is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none.
float bx = _bmgrp9(i + ivec2(1, 0));
float bz = _bmgrp9(i + ivec2(0, 1));
float c = _bmgrp9(i + ivec2(1, 1));
float m = a - bx - bz + c;
return vec3(a + (bx - a) * u.x + (bz - a) * u.y + m * u.x * u.y,
du * (vec2(bx - a, bz - a) + m * u.yx) * (float(k) / 16.0));
}

float _uoyqe3(ivec2 _etq2ri, vec2 _j98mda, out vec2 _qfbgoe) {
vec3 _ezl5lw = _rwtbqh(_etq2ri, _j98mda, 1, vec2(0.31, 0.77));
vec3 _bols69 = _rwtbqh(_etq2ri, _j98mda, 1, vec2(5.63, 2.19));
vec3 _c0wisj = _rwtbqh(_etq2ri, _j98mda, 1, vec2(9.41, 7.13));
vec2 p = _j98mda + _2m8jhhn * (vec2(_ezl5lw.x, _bols69.x) - 0.5);
// Copyright (c) 2026 Cazfps, all rights reserved. The code is confidential, proprietary work; creating derivative works, selling or reusing any part of it needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
float n = 0.0;
_qfbgoe = vec2(0.0);
float _6xizlb = 0.5;
for (int i = 0; i < 4; i++) {
vec3 o = _rwtbqh(_etq2ri, p, _dlnwbej << i, vec2(0.17, 0.43) + 3.7 * float(i));
n += _6xizlb * o.x;
_qfbgoe += _6xizlb * o.yz;
_6xizlb *= 0.5;
}

_qfbgoe = vec2((1.0 + _2m8jhhn * _ezl5lw.y) * _qfbgoe.x + _2m8jhhn * _bols69.y * _qfbgoe.y,
_2m8jhhn * _ezl5lw.z * _qfbgoe.x + (1.0 + _2m8jhhn * _bols69.z) * _qfbgoe.y) / 0.9375
+ _jo1arhv * _c0wisj.yz;
return n / 0.9375 + _jo1arhv * (_c0wisj.x - 0.5);
}
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; modifying or decompiling is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.

float _jbxyg0(vec3 _62eilz, float _ehj8ad, float _ep2p32) {
float _b22xbq = _5dyniss;
vec2 _k3gfsw = floor(_62eilz.xz * 16.0);
vec2 _j98mda = (_k3gfsw + 0.5) / 16.0;

ivec2 _etq2ri = cameraPositionInt.xz;
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; decompiling, copying or publishing is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too. Details in LICENSE.txt.
vec2 _qfbgoe;
float n = _uoyqe3(_etq2ri, _j98mda, _qfbgoe);

float _ticp8b = _4jisp0q - 0.07 * (RAIN_PUDDLE_COVERAGE - 1.0) + 0.3 * (1.0 - _b22xbq);

float _8ahev6 = 16.0 * ((n - _ticp8b) / max(length(_qfbgoe), 0.05) - 1.5 * (1.0 - _ehj8ad));

ivec2 _12rmj4 = ivec2(_k3gfsw) + _etq2ri * 16;
float _vmnoie = 0.75 * _bmgrp9(_12rmj4) + 0.25 * _rwtbqh(_etq2ri, _j98mda, 64, vec2(0.5)).x - 0.5;
float _cv7lwm = clamp(floor(3.0 * _8ahev6 / _uenoj83 + 0.5 + _vnyl4eb * _vmnoie), 0.0, 3.0) / 3.0;
float _bit19a = clamp(_8ahev6 / _uenoj83, 0.0, 1.0);
return mix(_bit19a, _cv7lwm, 1.0 - smoothstep(0.35, 0.7, _ep2p32)) * smoothstep(0.0, 0.15, _b22xbq);
}
#endif
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is protected by copyright and not open source; reverse engineering, copying, de-obfuscating or porting it to another pack is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. The same terms bind any software acting on a person's behalf. See LICENSE.txt.

#if defined(_0s6xabo) && defined(_q1mg2jt)
#define _j93bl76

flat in float litePuddleGround;

float _7ez8ds(vec3 _deg898n, vec3 dx, vec3 dy, float _hbg2j9, vec2 _i0z2cx) {
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; copying, de-obfuscating, publishing or selling needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
if (_5dyniss <= 0.0 || litePuddleGround < 0.5) return 0.0;
mat3 _e12sb2 = mat3(gbufferModelViewInverse);

vec3 _62eilz = _e12sb2 * _deg898n + gbufferModelViewInverse[3].xyz + cameraPositionFract;
vec2 _j98mda = (floor(_62eilz.xz * 16.0) + 0.5) / 16.0;

vec3 _pq7svk = _e12sb2 * dx;
vec3 _kg9ida = _e12sb2 * dy;
float _cnfgc2 = _pq7svk.x * _kg9ida.z - _pq7svk.z * _kg9ida.x;
vec2 _1yrzmj = abs(_cnfgc2) > 1e-12
? vec2(_i0z2cx.x * _kg9ida.z - _i0z2cx.y * _pq7svk.z, _pq7svk.x * _i0z2cx.y - _kg9ida.x * _i0z2cx.x) / _cnfgc2 : vec2(0.0);
float _ehj8ad = smoothstep(14.5, 14.9, 16.0 * (_hbg2j9 + dot(_1yrzmj, _j98mda - _62eilz.xz)) - 0.5);
if (_ehj8ad <= 0.0) return 0.0;
return _jbxyg0(_62eilz, _ehj8ad, 16.0 * max(length(dx), length(dy)));
}
// Caztoon beta 2.2 is the property of Cazfps. The code is confidential, proprietary work; creating derivative works or selling is off limits unless Cazfps personally licensed it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. No tool, script or agent is exempt from these terms. See LICENSE.txt.
#endif
#endif
#endif
