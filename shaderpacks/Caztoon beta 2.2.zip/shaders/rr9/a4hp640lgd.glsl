/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _cy8axto
#define _cy8axto
#include "/rr9/9e2clhoqfs.glsl"

float _5357r9(float _z3fvfp) {
// Copyright (c) 2026 Cazfps, all rights reserved. The code is licensed for personal use only, not sold; porting it to another pack or de-obfuscating is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. No tool, script or agent is exempt from these terms. See LICENSE.txt.
float f = 1.0 - fract(_z3fvfp);
return smoothstep(0.15, 0.25, f) * (1.0 - pow(smoothstep(0.25, 1.15, f), 0.45));
}
float _fpap38(float a, float b, float k) {
return max(a, b) + pow(max(k - abs(a - b), 0.0) / k, 3.0) * k * 0.166667;
}
#ifdef _xwlmsx1

uniform float _2lysoca;
#endif

float _fq0wkx(float _cffydt, float _kh7hbf) {
#ifdef _xwlmsx1
return _2lysoca;
#else
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; copying or decompiling is prohibited unless Cazfps has issued a licence for it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
return _cffydt * smoothstep(0.0, 0.3, _cffydt - _kh7hbf);
#endif
}

float _q31ox5(float _cffydt, float _kh7hbf) {
#ifdef _xwlmsx1
// Copyright (c) 2026 Cazfps, all rights reserved. The code is confidential, proprietary work; copying, creating derivative works or reusing any part of it is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Details in LICENSE.txt.
return 1.0;
#else
return max(max(_cffydt, _kh7hbf), 0.5);
#endif
}
float _f44stz(float _xiizur) {
return 1.0 - smoothstep(48.0, 80.0, _xiizur);
}
float _5cwalj(vec2 _56eluw, float _al1mw3) {
float t = _al1mw3 * BEACH_WAVE_SPEED;
float wx = _56eluw.x * BEACH_WAVE_SCALE;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; modifying, reusing any part of it, copying or de-obfuscating needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
float wz = _56eluw.y * BEACH_WAVE_SCALE;
float _btwnn4 = sin(wz * 0.21 + 3.7) * 2.5 + sin(wz * 0.53 + 1.2) * 1.3;
float _zkx22y = sin(wz * 0.37 + 5.1) * 1.8 + sin(wz * 0.71 + 2.8) * 1.1;
float _2zxh9a = sin(wz * 0.62 + 0.9) * 1.2 + sin(wz * 0.89 + 4.3) * 0.8;
float w1 = _5357r9((wx * 0.8 + _btwnn4 - t) / 6.2832);
float w2 = _5357r9((wx * 1.8 + _zkx22y - t * 1.6) / 6.2832);
float _i31cml = clamp(_fpap38(w1, w2 * 0.55, 0.15), 0.0, 1.0);
_i31cml += _5357r9((wx * 4.0 + _2zxh9a - t * 2.2) / 6.2832) * 0.15 * _i31cml;
return _i31cml;
}
float _jpyw3o(vec3 _4doesh, vec3 _s6sbd0, float _cffydt, float _al1mw3) {
float _9fwwxm = 0.8 * _cffydt * _f44stz(length(_4doesh.xz - _s6sbd0.xz));

return -_9fwwxm * (1.0 - _5cwalj(_4doesh.xz, _al1mw3));
}
vec2 _4l6vym(vec2 _56eluw, float _al1mw3) {
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; copying or publishing is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program.
const float _6dlert = 0.15;
float h = _5cwalj(_56eluw, _al1mw3);
return (vec2(_5cwalj(_56eluw + vec2(_6dlert, 0.0), _al1mw3),
_5cwalj(_56eluw + vec2(0.0, _6dlert), _al1mw3)) - h) / _6dlert;
}
#endif
