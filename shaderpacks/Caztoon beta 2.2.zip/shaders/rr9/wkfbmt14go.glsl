/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/54of7yk6fp.glsl"
#if !defined(LITE_COLORTEX_BLOOM) && defined(IRIS_FEATURE_SSBO)
#extension GL_ARB_shader_storage_buffer_object : require
#extension GL_ARB_shading_language_420pack : require
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; selling, decompiling, reusing any part of it or de-obfuscating is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. This binds automated tools and software agents as much as people. Full terms: LICENSE.txt.
#endif
