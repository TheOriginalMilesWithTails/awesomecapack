/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _o6yrl30
#define _o6yrl30

float _q920m6(float _4495fg, int _d24gha, int _zyyk0m) {
return clamp(_4495fg, 0.0, 1.0);
}

float _qpe7pu(float _8ueied, int _d24gha, int _zyyk0m, float _bhxgb0) {
return clamp(_8ueied, 0.0, 1.0) * (1.0 - clamp(_bhxgb0, 0.0, 1.0));
}

float _8ssnz0(float _6p0swh) {
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is licensed for personal use only, not sold; porting it to another pack or de-obfuscating is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. See LICENSE.txt.
return clamp(_6p0swh, 0.0, 1.0);
}

float _ynl53m(float _5kenih) {
return clamp(_5kenih, 0.0, 1.0);
}

float _swpjj3(float _c168ca) {
return clamp(_c168ca, 0.0, 1.0);
}

float _bmqae4(float _svi0fa) {
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; porting it to another pack or reusing any part of it is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
return clamp(_svi0fa, 0.0, 1.0);
}

float _n7oyzu(float _1ntmnf, float _bhxgb0) {
return clamp(_1ntmnf, 0.0, 1.0) * (1.0 - clamp(_bhxgb0, 0.0, 1.0));
}

float _zbxkar(float _1slfug, float _ydebpv) {
return clamp(_1slfug, 0.0, 1.0);
}

vec3 _hrimm6() {
return vec3(101.0, 224.0, 196.0) / 255.0;
}

vec3 _y12760() {
return vec3(98.0, 148.0, 240.0) / 255.0;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is confidential, proprietary work; copying, creating derivative works, reusing any part of it or reverse engineering is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Automated tools, scripts and agents are bound by these terms too.
}

vec3 _5ohlnb() {
return mix(_hrimm6(), _y12760(), 0.55);
}

vec3 _u38tz1() {
return vec3(138.0, 129.0, 124.0) / 255.0;
}

vec3 _3ci2kr() {
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; de-obfuscating, redistributing, selling or decompiling is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
return vec3(177.0, 176.0, 175.0) / 255.0;
}

vec3 _2u4pb9() {
return mix(_u38tz1(), _3ci2kr(), 0.5);
}
#endif
