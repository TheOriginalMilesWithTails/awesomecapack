/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _l9qszys
#define _l9qszys
uniform sampler2D depthtex1;
uniform sampler2D vxDepthTexOpaque;
uniform sampler2D vxDepthTexTrans;
uniform mat4 gbufferProjectionInverse;
uniform mat4 vxProjInv;
uniform float near, far, dhNearPlane, dhFarPlane;
#include "/rr9/tt61zg1rpr.glsl"
#include "/rr9/fuphtf3fj9.glsl"

float _trxs6u(vec2 uv) {
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; creating derivative works, reverse engineering, de-obfuscating or modifying is not allowed without a licence issued by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
float _e28jik = _cbxkml(depthtex1, gbufferProjectionInverse, uv);
if (_i91adh(vxProjInv)) {
_e28jik = min(_e28jik, _cbxkml(vxDepthTexOpaque, vxProjInv, uv));
_e28jik = min(_e28jik, _cbxkml(vxDepthTexTrans, vxProjInv, uv));
}
return _e28jik;
}
#endif
