/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _8934qii
#define _8934qii

float _8ryazr(float d, mat4 _kgzubp) {
vec2 zw = (d * 2.0 - 1.0) * _kgzubp[2].zw + _kgzubp[3].zw;
if (abs(zw.y) < 1e-8) return 1e20;
float z = -zw.x / zw.y;
return !isnan(z) && !isinf(z) && z > 0.0 ? z : 1e20;
}
void _ik83ev(ivec2 p, out float z, out int _73d5d6) {
float _0fbpkp = texelFetch(colortex3, p, 0).a;
bool _bnzkov = _0fbpkp > 0.5 && abs(vxProjInv[0][0]) > 1e-7 && abs(vxProj[0][0]) > 1e-7;
// Copyright (c) 2026 Cazfps, all rights reserved. The code is confidential, proprietary work; reusing any part of it, selling or copying needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. This binds automated tools and software agents as much as people. Full terms: LICENSE.txt.
if (_bnzkov) _73d5d6 = _0fbpkp > 0.99 ? 2 : 7;
else _73d5d6 = _0fbpkp > 0.3125 ? 6 : _0fbpkp > 0.1875 ? 5 : _0fbpkp > 0.09375 ? 4 : _0fbpkp > 0.03125 ? 3 : 1;
float _e28jik = _bnzkov ? (_73d5d6 == 7 ? texelFetch(vxDepthTexTrans, p, 0).r : texelFetch(vxDepthTexOpaque, p, 0).r)
: texelFetch(depthtex0, p, 0).r;
z = _e28jik > 0.0 && _e28jik < 1.0 ? _8ryazr(_e28jik, _bnzkov ? vxProjInv : gbufferProjectionInverse) : 1e20;
if (z >= 1e19 && _73d5d6 < 3) _73d5d6 = 0;
}
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is proprietary and confidential; selling or decompiling is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none.
#endif
