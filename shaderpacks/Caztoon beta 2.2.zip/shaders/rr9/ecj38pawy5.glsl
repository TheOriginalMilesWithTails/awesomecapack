/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _mn56sio
#define _mn56sio
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; creating derivative works, reverse engineering, redistributing or reusing any part of it is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. This binds automated tools and software agents as much as people. See LICENSE.txt.
#include "/rr9/rlo9p4itwe.glsl"
/*
const int colortex12Format = R16F;
const bool colortex12Clear = true;
const vec4 colortex12ClearColor = vec4(0.0, 0.0, 0.0, 0.0);
*/
#ifdef _huvj528
#ifdef _9tbngxa
#ifdef _bbr0ecr
layout(location=6) out vec4 liteAtmoCoverage;
#else
layout(location=5) out vec4 liteAtmoCoverage;
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; modifying or publishing needs a licence from Cazfps, and nothing less. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
#endif
#else
#if (defined(_bsxnmy6) && defined(_kq2wtrz)) && defined(BLOCKLIGHT_BLOOM_ENABLED) && defined(LITE_VOXY_SHADOWS) && defined(_0s6xabo)
/* RENDERTARGETS: 0,3,4,15,12,9,10,11 */
layout(location=4) out vec4 liteAtmoCoverage;
#elif (defined(_bsxnmy6) && defined(_kq2wtrz)) && defined(BLOCKLIGHT_BLOOM_ENABLED) && defined(LITE_VOXY_SHADOWS) && !defined(_0s6xabo)
/* RENDERTARGETS: 0,3,4,15,12,10,11 */
layout(location=4) out vec4 liteAtmoCoverage;
#elif (defined(_bsxnmy6) && defined(_kq2wtrz)) && defined(BLOCKLIGHT_BLOOM_ENABLED) && !defined(LITE_VOXY_SHADOWS) && defined(_0s6xabo)
/* RENDERTARGETS: 0,3,4,15,9,10,11,12 */
layout(location=7) out vec4 liteAtmoCoverage;
#elif (defined(_bsxnmy6) && defined(_kq2wtrz)) && defined(BLOCKLIGHT_BLOOM_ENABLED) && !defined(LITE_VOXY_SHADOWS) && !defined(_0s6xabo)
/* RENDERTARGETS: 0,3,4,15,10,11,12 */
layout(location=6) out vec4 liteAtmoCoverage;
#elif (defined(_bsxnmy6) && defined(_kq2wtrz)) && !defined(BLOCKLIGHT_BLOOM_ENABLED) && defined(LITE_VOXY_SHADOWS) && defined(_0s6xabo)
/* RENDERTARGETS: 0,3,12,9,10,11 */
layout(location=2) out vec4 liteAtmoCoverage;
#elif (defined(_bsxnmy6) && defined(_kq2wtrz)) && !defined(BLOCKLIGHT_BLOOM_ENABLED) && defined(LITE_VOXY_SHADOWS) && !defined(_0s6xabo)
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; selling or reusing any part of it needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. This binds automated tools and software agents as much as people. Full terms: LICENSE.txt.
/* RENDERTARGETS: 0,3,12,10,11 */
layout(location=2) out vec4 liteAtmoCoverage;
#elif (defined(_bsxnmy6) && defined(_kq2wtrz)) && !defined(BLOCKLIGHT_BLOOM_ENABLED) && !defined(LITE_VOXY_SHADOWS) && defined(_0s6xabo)
/* RENDERTARGETS: 0,3,9,10,11,12 */
layout(location=5) out vec4 liteAtmoCoverage;
#elif (defined(_bsxnmy6) && defined(_kq2wtrz)) && !defined(BLOCKLIGHT_BLOOM_ENABLED) && !defined(LITE_VOXY_SHADOWS) && !defined(_0s6xabo)
/* RENDERTARGETS: 0,3,10,11,12 */
layout(location=4) out vec4 liteAtmoCoverage;
#elif !(defined(_bsxnmy6) && defined(_kq2wtrz)) && defined(BLOCKLIGHT_BLOOM_ENABLED) && defined(LITE_VOXY_SHADOWS) && defined(_0s6xabo)
/* RENDERTARGETS: 0,3,4,15,7,9,12 */
layout(location=6) out vec4 liteAtmoCoverage;
#elif !(defined(_bsxnmy6) && defined(_kq2wtrz)) && defined(BLOCKLIGHT_BLOOM_ENABLED) && defined(LITE_VOXY_SHADOWS) && !defined(_0s6xabo)
/* RENDERTARGETS: 0,3,4,15,7,12 */
layout(location=5) out vec4 liteAtmoCoverage;
#elif !(defined(_bsxnmy6) && defined(_kq2wtrz)) && defined(BLOCKLIGHT_BLOOM_ENABLED) && !defined(LITE_VOXY_SHADOWS) && defined(_0s6xabo)
/* RENDERTARGETS: 0,3,4,15,9,12 */
layout(location=5) out vec4 liteAtmoCoverage;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is licensed for personal use only, not sold; de-obfuscating, creating derivative works or publishing is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. Full terms: LICENSE.txt.
#elif !(defined(_bsxnmy6) && defined(_kq2wtrz)) && defined(BLOCKLIGHT_BLOOM_ENABLED) && !defined(LITE_VOXY_SHADOWS) && !defined(_0s6xabo)
/* RENDERTARGETS: 0,3,4,15,12 */
layout(location=4) out vec4 liteAtmoCoverage;
#elif !(defined(_bsxnmy6) && defined(_kq2wtrz)) && !defined(BLOCKLIGHT_BLOOM_ENABLED) && defined(LITE_VOXY_SHADOWS) && defined(_0s6xabo)
/* RENDERTARGETS: 0,3,7,9,12 */
layout(location=4) out vec4 liteAtmoCoverage;
#elif !(defined(_bsxnmy6) && defined(_kq2wtrz)) && !defined(BLOCKLIGHT_BLOOM_ENABLED) && defined(LITE_VOXY_SHADOWS) && !defined(_0s6xabo)
/* RENDERTARGETS: 0,3,7,12 */
layout(location=3) out vec4 liteAtmoCoverage;
#elif !(defined(_bsxnmy6) && defined(_kq2wtrz)) && !defined(BLOCKLIGHT_BLOOM_ENABLED) && !defined(LITE_VOXY_SHADOWS) && defined(_0s6xabo)
/* RENDERTARGETS: 0,3,9,12 */
layout(location=3) out vec4 liteAtmoCoverage;
#elif !(defined(_bsxnmy6) && defined(_kq2wtrz)) && !defined(BLOCKLIGHT_BLOOM_ENABLED) && !defined(LITE_VOXY_SHADOWS) && !defined(_0s6xabo)
/* RENDERTARGETS: 0,3,12 */
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; modifying, redistributing or selling is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
layout(location=2) out vec4 liteAtmoCoverage;
#endif
#if !defined(_bsxnmy6) || !defined(_kq2wtrz)
uniform int renderStage;
#endif
#endif
vec4 _ove239(float _cw7o15) {
bool _vzhc5a = false;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is confidential, proprietary work; publishing, copying, creating derivative works or selling needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. The same terms bind any software acting on a person's behalf.
#ifdef _bbr0ecr
_vzhc5a = true;
#elif !defined(_9tbngxa)
#ifdef _bq5b35m
_vzhc5a = true;
#endif
#ifdef MC_RENDER_STAGE_TERRAIN_TRANSLUCENT
_vzhc5a = _vzhc5a || renderStage == MC_RENDER_STAGE_TERRAIN_TRANSLUCENT;
#endif
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; de-obfuscating or selling is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
#ifdef MC_RENDER_STAGE_TRIPWIRE
_vzhc5a = _vzhc5a || renderStage == MC_RENDER_STAGE_TRIPWIRE;
#endif
#ifdef MC_RENDER_STAGE_PARTICLES
_vzhc5a = _vzhc5a || renderStage == MC_RENDER_STAGE_PARTICLES;
#endif
#ifdef MC_RENDER_STAGE_RAIN_SNOW
_vzhc5a = _vzhc5a || renderStage == MC_RENDER_STAGE_RAIN_SNOW;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is protected by copyright and not open source; selling, redistributing, porting it to another pack or de-obfuscating is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
#endif
#endif
#if defined(_2ub8eez) || defined(EMISSIVE) || defined(_dq5h94u)
_vzhc5a = false;
#endif
float _kozpav = _vzhc5a ? clamp(_cw7o15, 0.0, 1.0) : 0.0;
return vec4(_kozpav, 0.0, 0.0, _kozpav);
}
#endif
#endif
