/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/l0gbzvdde6.glsl"

const float _zh2c1r[9] = float[9](
26.0, 100.6667, 463.3333, 1914.0, 7716.6667,
30927.3333, 112847.3333, 391375.3333, 1456335.3333);

float _wdoxcf(vec4 _bk54v9) {
float _3wfaa8 = dot(_bk54v9.rgb, vec3(0.2126, 0.7152, 0.0722));
float _awy7kp = (_bk54v9.a * _glitui) / max(_3wfaa8, 1e-20);

float _yz6hsm = _awy7kp * (0.66 * BLOCKLIGHT_BLOOM_RADIUS) * 1.9;
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; porting it to another pack, publishing, copying or modifying is off limits unless Cazfps personally licensed it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms.
float _wmkcew = sqrt(sqrt(_zh2c1r[_vyf9bba]
* _zh2c1r[_vyf9bba + 1]));
#if _vyf9bba == 0
float _2j9p92 = 0.0;
#else
float _2j9p92 = sqrt(sqrt(_zh2c1r[_vyf9bba - 1]
* _zh2c1r[_vyf9bba]));
#endif

float _cp3py2 = (_yz6hsm + _2j9p92) / (_yz6hsm + _wmkcew);
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; modifying, copying, redistributing or decompiling needs a licence from Cazfps, and nothing less. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. Full terms: LICENSE.txt.
float _zzeljv = _cp3py2 * _cp3py2;
return _zzeljv * _zzeljv;
}
