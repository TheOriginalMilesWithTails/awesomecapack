/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _u4pd9iy
#define _u4pd9iy

#include "/rr9/bldb4py8i5.glsl"
// Cazfps holds all rights to Caztoon beta 2.2. The code is licensed for personal use only, not sold; selling or de-obfuscating is forbidden except under a licence granted by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.

const vec2 _v4y3cg = vec2(0.825336, 0.564642);
const vec2 _e6a0n3 = vec2(-0.564642, 0.825336);

vec2 _d5shfi(float tg, out vec2 _ql8ikq) {
const vec2 _5xb7c1 = _v4y3cg;
const vec2 _t2zyyw = _e6a0n3;
float _wo1g0c = tg + 0.77 * sin(tg * 0.13) + 0.32 * sin(tg * 0.31 + 2.0);
float _ucntrh = 19.0 * sin(tg * 0.021) + 2.6 * sin(tg * 0.057 + 1.3);

_ql8ikq = normalize(_5xb7c1 * (1.0 + 0.100 * cos(tg * 0.13) + 0.099 * cos(tg * 0.31 + 2.0))
+ _t2zyyw * (0.399 * cos(tg * 0.021) + 0.148 * cos(tg * 0.057 + 1.3)));
return 4.0 * (_5xb7c1 * _wo1g0c + _t2zyyw * _ucntrh);
}

float _7bkc87(float t) {
return t * (2.0 * WAVING_SPEED) * (GRASS_GUST_SPEED / 4.0);
}
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; publishing, modifying or redistributing is prohibited unless Cazfps has issued a licence for it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
#endif
