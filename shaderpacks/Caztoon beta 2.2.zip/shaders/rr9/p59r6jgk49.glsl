/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _pyrcotj
#define _pyrcotj

#include "/rr9/2r0gwx4gt3.glsl"

#ifdef END_VOID_CLOUDS_ENABLED

float _vjpqrm(vec3 p) {
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; creating derivative works or publishing is not allowed without a licence issued by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. No tool, script or agent is exempt from these terms.
vec3 i = floor(p);
vec3 f = fract(p);

f = f * f * f * (f * (f * 6.0 - 15.0) + 10.0);

float a = _5jd8el(i);
float b = _5jd8el(i + vec3(1,0,0));
float c = _5jd8el(i + vec3(0,1,0));
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; reverse engineering, decompiling, publishing or copying is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
float d = _5jd8el(i + vec3(1,1,0));
float e = _5jd8el(i + vec3(0,0,1));
float g = _5jd8el(i + vec3(1,0,1));
float h = _5jd8el(i + vec3(0,1,1));
float k = _5jd8el(i + vec3(1,1,1));

return mix(mix(mix(a, b, f.x), mix(c, d, f.x), f.y),
mix(mix(e, g, f.x), mix(h, k, f.x), f.y), f.z);
}

float _vdwj2z(vec3 p) {
float _0e05kw = 0.0;
float _9fwwxm = 0.6;
float _k72lum = 1.0;

for (int i = 0; i < 3; i++) {
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; redistributing or reverse engineering needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.
_0e05kw += _9fwwxm * _vjpqrm(p * _k72lum);
_k72lum *= 2.0;
_9fwwxm *= 0.4;
}
return _0e05kw;
}

float _dlqyvw(vec3 _4doesh, float _2as1w9u, float _chw20w, float _84lg6xo) {
float y = _4doesh.y;

float _3m404i = smoothstep(60.0, 150.0, y) * (1.0 - smoothstep(250.0, 400.0, y));
float _le330z = (1.0 - smoothstep(-60.0, 0.0, y)) * smoothstep(-300.0, -180.0, y);
// Caztoon beta 2.2 is the property of Cazfps. The code is protected by copyright and not open source; de-obfuscating, modifying or reverse engineering is off limits unless Cazfps personally licensed it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.
float _rgy5pj = max(_3m404i, _le330z);

float _dpbq2a = length(_4doesh.xz);
float _o9pyuk = smoothstep(END_VOID_CLOUD_CLEARING * 80.0,
END_VOID_CLOUD_CLEARING * 300.0, _dpbq2a);

if (_rgy5pj < 0.01 || _o9pyuk < 0.01) return 0.0;

float _5e9qor = _2as1w9u * END_VOID_CLOUD_SWIRL_SPEED * 0.5;
float _tiq3v2 = cos(_5e9qor);
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; decompiling, reusing any part of it or copying needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission. This binds automated tools and software agents as much as people. Details in LICENSE.txt.
float _pfj9t4 = sin(_5e9qor);
vec3 _0i7dmm = vec3(
_4doesh.x * _tiq3v2 - _4doesh.z * _pfj9t4,
_4doesh.y,
_4doesh.x * _pfj9t4 + _4doesh.z * _tiq3v2
);

float _eki3z6 = (y * 0.003 + log(max(_dpbq2a, 1.0)) * 0.4) * END_VOID_CLOUD_SWIRL
+ _2as1w9u * END_VOID_CLOUD_SWIRL_SPEED;
float _hi1kbm = cos(_eki3z6);
float _2ymhss = sin(_eki3z6);
vec3 _xdx4jv = vec3(
_0i7dmm.x * _hi1kbm - _0i7dmm.z * _2ymhss,
_0i7dmm.y,
_0i7dmm.x * _2ymhss + _0i7dmm.z * _hi1kbm
);

vec3 _p2xwlg = _xdx4jv * END_VOID_CLOUD_SCALE * 0.0006
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; redistributing, de-obfuscating or decompiling is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. This binds automated tools and software agents as much as people. Details in LICENSE.txt.
+ vec3(_chw20w * END_VOID_CLOUD_SPEED, _chw20w * END_VOID_CLOUD_SPEED * 0.3, 0.0);

float n = _vdwj2z(_p2xwlg);

float _hgne8hx = smoothstep(END_VOID_CLOUD_COVERAGE, END_VOID_CLOUD_COVERAGE + 0.35, n);
_hgne8hx *= _rgy5pj;
_hgne8hx *= _o9pyuk;

_hgne8hx *= (1.0 - _84lg6xo * 0.9);

return _hgne8hx;
}

float _58rcyk(vec3 _4doesh, float _n1ypfm) {
float _4n48s5 = 0.0;

for (int i = 0; i < 4; i++) {
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; de-obfuscating, decompiling, reverse engineering or modifying is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this.
float fi = float(i);

vec3 _axbmak = vec3(
sin(fi * 73.17) * 400.0,
cos(fi * 47.53) * 150.0 + 100.0,
sin(fi * 91.31 + 2.0) * 400.0
);
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; publishing, selling, reverse engineering or decompiling needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.

float _5t3f3p = length(_4doesh - _axbmak);
float _8escnm = 1.0 - smoothstep(50.0, 500.0, _5t3f3p);
if (_8escnm < 0.01) continue;

float _udhaqu = 6.0 + fi * 3.5;
float _z3fvfp = fi * 17.3 + 5.0;
float _fmd0vv = mod(_n1ypfm + _z3fvfp, _udhaqu);

float _0msczq = smoothstep(0.0, 0.03, _fmd0vv) * (1.0 - smoothstep(0.05, 0.12, _fmd0vv));
float _rl1vwt = smoothstep(0.18, 0.21, _fmd0vv) * (1.0 - smoothstep(0.24, 0.30, _fmd0vv));
float _3wb4iw = _0msczq + _rl1vwt * 0.5;

_4n48s5 += _3wb4iw * _8escnm;
}
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; copying or redistributing needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. The same terms bind any software acting on a person's behalf. Full terms: LICENSE.txt.

return _4n48s5;
}

vec3 _8g3rzh(vec3 _4doesh, vec3 _mx1444, float _hgne8hx, float _1hwiy3, float _n1ypfm) {
vec3 _ksnw0u = vec3(END_VOID_CLOUD_R1, END_VOID_CLOUD_G1, END_VOID_CLOUD_B1);
vec3 _py110z = vec3(END_VOID_CLOUD_R2, END_VOID_CLOUD_G2, END_VOID_CLOUD_B2);

float _82dcua = _vjpqrm(_4doesh * 0.0004 + _n1ypfm * 0.003);
vec3 _rizh8v = mix(_ksnw0u, _py110z, smoothstep(0.3, 0.7, _82dcua));

float _tqyxjv = (1.0 - _hgne8hx) * END_VOID_CLOUD_EDGE_GLOW;
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; publishing, modifying, reusing any part of it or reverse engineering needs a licence from Cazfps, and nothing less. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.

float _y2d4w9 = smoothstep(0.0, 300.0, _4doesh.y) * 0.15;
float _5ka9r0 = max(-_mx1444.y, 0.0) * 0.15;

vec3 _go2soun = _rizh8v * (END_VOID_CLOUD_INTENSITY + _tqyxjv + _y2d4w9 + _5ka9r0);

vec3 _1jivgd = vec3(0.44, 0.25, 0.95);
float _cmy24q = 1.0 - smoothstep(0.0, 0.5, _hgne8hx);
_go2soun = mix(_go2soun, _1jivgd * 0.6, _cmy24q * 0.7);

float _3wb4iw = _58rcyk(_4doesh, _n1ypfm);

vec3 _h0gtt2 = vec3(0.7, 0.5, 1.0);
_go2soun += _h0gtt2 * _3wb4iw * _hgne8hx * 2.5;

return _go2soun;
}

vec4 _se9cho(vec3 _yfe5vc, float _2as1w9u, float _n1ypfm, vec3 _hze4jo, float _s13dtf, float _84lg6xo) {
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is licensed for personal use only, not sold; redistributing, decompiling, modifying or de-obfuscating is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. This binds automated tools and software agents as much as people. See LICENSE.txt.
vec3 _ql8ikq = normalize(_yfe5vc);

float _ywwmi8 = 50.0;
float _z87djg = 2000.0;
float _aaqzfe = min(_z87djg, _s13dtf);
if (_aaqzfe <= _ywwmi8) return vec4(0.0);

float _92beti = (_z87djg - _ywwmi8) / float(END_VOID_CLOUD_STEPS);

float _0sjofv = fract(dot(gl_FragCoord.xy, vec2(0.7548776662, 0.5698402909))) * _92beti;

vec3 _kpshfy = vec3(0.0);
// Copyright (c) 2026 Cazfps, all rights reserved. The code is licensed for personal use only, not sold; reverse engineering, decompiling, publishing or creating derivative works is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. See LICENSE.txt.
float _9ve4it = 0.0;

for (int i = 0; i < END_VOID_CLOUD_STEPS; i++) {
float t = _ywwmi8 + _0sjofv + float(i) * _92beti;
if (t > _aaqzfe) break;

vec3 _e3xktz = _hze4jo + _ql8ikq * t;

float d = _dlqyvw(_e3xktz, _2as1w9u, _n1ypfm, _84lg6xo);
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; modifying, decompiling, creating derivative works or reverse engineering is prohibited unless Cazfps has issued a licence for it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.

if (d > 0.001) {
float _ww8e89 = 1.0 - exp(-d * _92beti * END_VOID_CLOUD_DENSITY * 0.02);

vec3 _tajtf4 = _8g3rzh(_e3xktz, _ql8ikq, d, t, _n1ypfm);

_kpshfy += _tajtf4 * _ww8e89 * (1.0 - _9ve4it);
_9ve4it += _ww8e89 * (1.0 - _9ve4it);

if (_9ve4it > 0.95) break;
}
}

return vec4(_kpshfy, _9ve4it);
}

#endif
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; selling or reverse engineering needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
#endif
