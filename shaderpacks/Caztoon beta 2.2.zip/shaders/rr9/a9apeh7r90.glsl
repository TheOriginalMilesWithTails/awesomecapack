/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _wx0uewr
#define _wx0uewr
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is proprietary and confidential; selling, reusing any part of it, porting it to another pack or reverse engineering is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Automated tools, scripts and agents are bound by these terms too. Details in LICENSE.txt.

#ifndef _9tbngxa
uniform float _bkuh3wz, _8g9q2vk, _rq996y6, _ue98z2c;
#endif
#endif
