/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _5cj7l19
#define _5cj7l19

const float _daw1yi = 0.6;
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; decompiling, copying, publishing or reverse engineering is off limits unless Cazfps personally licensed it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program.
const int _quhwla = 256;
const int _dblklr = 4;
const float _6l6qx5 = 5.0;
const float _f4brmo = 0.0;
const float _lub52k = -1.0e6;
const float _000dji = -419.0;

vec2 _rafpkm(vec3 _s6sbd0, vec2 _qfbgoe, vec2 _n97a1w) {
vec2 _5da0zu = _s6sbd0.xz + _qfbgoe * (_f4brmo - _s6sbd0.y) + _n97a1w;
return floor(_5da0zu / _6l6qx5) * _6l6qx5;
}

vec2 _yk7edm(ivec2 _12rmj4, vec2 _cohh6o, vec2 _n97a1w) {
return _cohh6o - _n97a1w + (vec2(_12rmj4) - 0.5 * float(_quhwla) + 0.5) * _6l6qx5;
}

#endif
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is licensed for personal use only, not sold; creating derivative works, copying or modifying is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
