/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#ifndef _kx6pocf
#define _kx6pocf
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; redistributing, selling or publishing is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms. See LICENSE.txt.

float _r8zrwj(float x) { return x * x * x * x; }

float _2phui6(vec2 v) {
return sqrt(sqrt(_r8zrwj(v.x) + _r8zrwj(v.y)));
}

vec3 _n0grq3(vec3 _hqrzjv) {
float _qr341h = _2phui6(_hqrzjv.xy) + SHADOW_DISTORTION;
return vec3(_hqrzjv.xy / _qr341h, _hqrzjv.z * _fuqhpqz);
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; copying, de-obfuscating, publishing or reverse engineering is off limits unless Cazfps personally licensed it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. Full terms: LICENSE.txt.
}

#endif
