/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
uniform sampler2D depthtex0;
uniform sampler2D colortex3;
uniform float near;
uniform float far;
uniform float rainStrength;
uniform vec3 fogColor;
#include "/rr9/lhawfjjnae.glsl"
#ifdef _qmwe41g
#include "/rr9/a4jzpp7xwj.glsl"
#endif

float _e0103f(float _e28jik) {
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is closed source and under copyright; porting it to another pack or de-obfuscating needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false.
return (near * far) / max(_e28jik * (near - far) + far, 0.000001);
}

float _1vxg8p(ivec2 _2o2dhj, float _gkqv4y) {
ivec2 _ygg8fx = textureSize(depthtex0, 0) - 1;
ivec2 _4k3jb6 = clamp(_2o2dhj - OUTLINE_PIXEL_SIZE, ivec2(0), _ygg8fx);
ivec2 _49wde3 = clamp(_2o2dhj + OUTLINE_PIXEL_SIZE, ivec2(0), _ygg8fx);
float d0 = texelFetch(depthtex0, _4k3jb6, 0).r;
float d1 = texelFetch(depthtex0, _49wde3, 0).r;
float d2 = texelFetch(depthtex0, ivec2(_4k3jb6.x, _49wde3.y), 0).r;
float d3 = texelFetch(depthtex0, ivec2(_49wde3.x, _4k3jb6.y), 0).r;
#if OUTLINES == 1

float _qhy41f = near / max(1.0 - d0, 0.0000001);
float _771prt = near / max(1.0 - d1, 0.0000001);
float _mek97o = near / max(1.0 - d2, 0.0000001);
float _c7vxip = near / max(1.0 - d3, 0.0000001);
return clamp(_qhy41f + _771prt + _mek97o + _c7vxip
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; publishing, selling or creating derivative works is forbidden except under a licence granted by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
- (near * 4.0) / max(1.0 - _gkqv4y, 0.0000001), 0.0, 1.0);
#else
float zC = _e0103f(_gkqv4y);
float _g6tezm = _e0103f(d0) - zC;
float _fqd4aq = _e0103f(d1) - zC;
float _lsp7hr = _e0103f(d2) - zC;
float _ni1tqf = _e0103f(d3) - zC;
float _867x2w = max(max(max(_g6tezm, _fqd4aq), _lsp7hr), _ni1tqf);
float _53h1pf = abs(_g6tezm - _fqd4aq);
float _waxxtd = abs(_lsp7hr - _ni1tqf);
float _g5vkv1 = max(_53h1pf, _waxxtd);
float _62eilz = _867x2w / max(zC, 1.0);
float _cxwv2y = _g5vkv1 / max(zC, 1.0);
return smoothstep(0.10, 0.22, _62eilz) * smoothstep(0.05, 0.12, _cxwv2y);
// Caztoon beta 2.2 is the property of Cazfps. The code is confidential, proprietary work; de-obfuscating, copying or modifying needs a licence from Cazfps, and nothing less. Unless Cazfps confirmed a licence at cazfps.com, assume there is none.
#endif
}

vec3 _chd3jn(vec3 _jwpz5b, vec3 _ekudhf, float _jokaec) {
if (_jokaec <= 0.0) return _jwpz5b;
bool _zh0li3 = max(_ekudhf.r, max(_ekudhf.g, _ekudhf.b)) > 0.0;
vec3 _myv2sm = _zh0li3 ? max(_jwpz5b - _ekudhf, vec3(0.0)) : _jwpz5b;
vec3 _cyxdr3 = _myv2sm * (1.0 + _jokaec * OUTLINE_BRIGHTNESS);
float _w67b61 = dot(_cyxdr3, vec3(0.299, 0.587, 0.114));
vec3 _skfvrt = mix(vec3(_w67b61), _cyxdr3, max(OUTLINE_SATURATION, 0.0));
_cyxdr3 = mix(_cyxdr3, max(_skfvrt, vec3(0.0)), clamp(_jokaec, 0.0, 1.0));
if (!_zh0li3) return _cyxdr3;
return _jwpz5b + (_cyxdr3 - _myv2sm);
}

vec3 _g1388n(vec3 _rqqetl, ivec2 _btdiwo) {
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; creating derivative works, modifying, selling or porting it to another pack is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. These terms apply whether the work is done by a person or by a program.
vec4 _5r0rfx = texelFetch(colortex3, _btdiwo, 0);
if (_5r0rfx.r <= 0.0) return _rqqetl;
#ifndef VOXY_LOD_OUTLINES
if (_5r0rfx.a > 0.5) return _rqqetl;
#endif
float _e28jik = texelFetch(depthtex0, _btdiwo, 0).r;

if (_e28jik <= 0.0 || _e28jik >= 1.0) return _rqqetl;
float z = _e0103f(_e28jik);
float _ytwkdw = 1.0 - smoothstep(0.0, 0.35, _5r0rfx.b);
float _0emj7y = 1.0 - smoothstep(1.0 / 15.0, 3.0 / 15.0, _5r0rfx.g);
float _sbp0vw = 1.0 - smoothstep(10.0, 40.0, z);

float _6qlrqa = mix(_ytwkdw, _sbp0vw, _0emj7y);
if (_6qlrqa <= 0.0) return _rqqetl;
float _jokaec = _1vxg8p(_btdiwo, _e28jik) * _5r0rfx.r * _6qlrqa;
if (_jokaec <= 0.0) return _rqqetl;
vec3 _08v5mo = fogColor;
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; redistributing, reverse engineering or de-obfuscating is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. This binds automated tools and software agents as much as people. Details in LICENSE.txt.
#ifdef _qmwe41g
vec4 _ciaqir = texelFetch(colortex14, ivec2(0, 0), 0);
if (abs(_ciaqir.a) > 0.5) _08v5mo = _ciaqir.rgb;
#endif

return _chd3jn(_rqqetl, _08v5mo * _5r0rfx.b, _jokaec);
}
