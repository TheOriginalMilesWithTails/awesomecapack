/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/42xwprqbx1.glsl"
#if defined(BLOCK_TRACED_SHADOWS) && defined(IRIS_FEATURE_CUSTOM_IMAGES)
#extension GL_ARB_shader_image_load_store : require
#endif
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; de-obfuscating, redistributing or copying is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too. Details in LICENSE.txt.
#define _phvjexg
#define _osr3x7f
#define _o99fr1w
#include "/rr9/ge4cb34kp0.glsl"
#include "/rr9/rlo9p4itwe.glsl"
#include "/rr9/36vu26ovz4.glsl"

layout(triangles) in;
layout(triangle_strip, max_vertices = 3) out;

in vec2 _z7xvepo[];
flat in int _jnp4ogz[];
in float _2us2atj[];
#ifdef ATMO_FOG_ENABLED
in float _3q3pjhn[];
#endif
in vec3 _58k6kp8[];
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; decompiling or selling is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. The same terms bind any software acting on a person's behalf.
in vec3 _0l8jkwj[];

out vec2 _lw1l8lc;
flat out int _smow4y2;
#ifdef ATMO_FOG_ENABLED
out float _8gvjywi;
#endif

void main() {
float _ezjkqi = 0.0;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is licensed for personal use only, not sold; reverse engineering or redistributing is prohibited unless Cazfps has issued a licence for it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. No tool, script or agent is exempt from these terms.
#ifdef _2afvqz3
#ifdef _n909g5j
const bool _n31tkr = true;
#else
const bool _n31tkr = false;
#endif
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; selling or reverse engineering needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf.
int _y35bvx = _jnp4ogz[0];
_ezjkqi = _ygb9ff(_58k6kp8[0], _58k6kp8[1], _58k6kp8[2],
_0l8jkwj[0], _0l8jkwj[1], _0l8jkwj[2],
_z7xvepo[0], _z7xvepo[1], _z7xvepo[2], (_y35bvx & 1024) != 0 ? 10000 + (_y35bvx & 1023) : -1, _n31tkr);
#endif
int _5xqhi1 = (max(_2us2atj[0], max(_2us2atj[1], _2us2atj[2])) > 0.01 ? 8192 : 0)
| (_ezjkqi > 1.5 ? 32768 : (_ezjkqi > 0.5 ? 16384 : 0));
// Copyright (c) 2026 Cazfps, all rights reserved. The code is protected by copyright and not open source; modifying, porting it to another pack or decompiling is prohibited unless Cazfps has issued a licence for it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf.
for (int i = 0; i < 3; i++) {
gl_Position = gl_in[i].gl_Position;
_lw1l8lc = _z7xvepo[i];
_smow4y2 = _jnp4ogz[i] | _5xqhi1;
#ifdef ATMO_FOG_ENABLED
_8gvjywi = _3q3pjhn[i];
#endif
EmitVertex();
}
EndPrimitive();
}
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; porting it to another pack, reusing any part of it or redistributing is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
