#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */

#define _bmkjfdl
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; decompiling, modifying, redistributing or de-obfuscating is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
#include "/rr9/dgynhddggq.glsl"
