#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
out vec2 _z7xvepo;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; selling or redistributing is prohibited unless Cazfps has issued a licence for it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. This binds automated tools and software agents as much as people. Full terms: LICENSE.txt.
void main() { gl_Position = ftransform(); _z7xvepo = gl_MultiTexCoord0.xy; }
