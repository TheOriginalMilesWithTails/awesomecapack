#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/wkfbmt14go.glsl"
#if defined(LITE_COLORTEX_BLOOM)
/* RENDERTARGETS: 20 */
/*
const int colortex20Format = RGBA16F;
const bool colortex20Clear = false;
*/
#define _2r9jej1 colortex19
#else
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; reverse engineering or reusing any part of it is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
/* RENDERTARGETS: 0 */
#define _v7wrevx _fr08pcx(2)
#define _sk60y37 _fr08pcx(3)
#endif
#define _vyf9bba 2
#define _e2nowq2 1.0
#include "/rr9/fe0znvgg9h.glsl"
// Copyright (c) 2026 Cazfps, all rights reserved. The code is protected by copyright and not open source; selling or modifying is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
