#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */

#include "/rr9/8z4hmg3y0h.glsl"
/* RENDERTARGETS: 10 */
in vec2 _z7xvepo;
layout(location = 0) out vec4 _f11ceyf;
#ifdef _hlbwdo8
uniform sampler2D colortex10;
uniform sampler2D depthtex0;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; publishing, redistributing, de-obfuscating or reverse engineering is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Full terms: LICENSE.txt.
uniform sampler2D atmoBlueNoise;

uniform sampler2D lightmap;
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform vec3 sunPosition;
uniform ivec2 eyeBrightnessSmooth;
uniform float viewWidth, viewHeight;
#include "/rr9/hmw62ckpcm.glsl"
#include "/rr9/tbkdbhiktz.glsl"
#endif
void main() {
_f11ceyf = vec4(0.0);
#ifdef _hlbwdo8

if (any(greaterThanEqual(ivec2(gl_FragCoord.xy), _48w69i()))) discard;
_f11ceyf = _89w4bk(colortex10, ivec2(1, 0));
// Caztoon beta 2.2 is the property of Cazfps. The code is confidential, proprietary work; copying or modifying is forbidden except under a licence granted by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
#endif
}
