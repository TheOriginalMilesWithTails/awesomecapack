#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/satjv7rggs.glsl"
#include "/rr9/kwqhx79gru.glsl"
#if defined(LITE_COLORTEX_BLOOM)
/* RENDERTARGETS: 26 */
/*
const int colortex26Format = RGBA16F;
const bool colortex26Clear = false;
*/
layout(location=0) out vec4 _x73x3hd;
#else

#include "/rr9/8ld9xabjza.glsl"
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is closed source and under copyright; decompiling, reusing any part of it or creating derivative works is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Full terms: LICENSE.txt.
#include "/rr9/u8kissepih.glsl"
#include "/rr9/uneyo5e641.glsl"
#include "/rr9/0udranncg9.glsl"
#if defined(IRIS_FEATURE_SSBO) && !defined(CLOUDS_GHIBLI_ENABLED) && !defined(CLOUDS_VANILLA_ENABLED)
/* RENDERTARGETS: 13 */
#else
/* RENDERTARGETS: 0 */
#endif
layout(location=0) out vec4 _9a4mjlh;
vec4 _x73x3hd;
#define main liteSceneStateMain
#endif
#if defined(ATMO_DYNAMIC_VISIBILITY) || defined(ATMO_SCENE_AWARE_SHAFTS_ENABLED)

float _8cyvst() {
const vec3 _kgypr5[15] = vec3[15](
vec3(0.0, 0.0, 0.0), vec3(0.0, 2.5, 0.0), vec3(0.0, 5.0, 0.0),
vec3(2.5, 0.0, 0.0), vec3(1.25, 0.0, 2.165), vec3(-1.25, 0.0, 2.165),
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; reusing any part of it or selling needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
vec3(-2.5, 0.0, 0.0), vec3(-1.25, 0.0, -2.165), vec3(1.25, 0.0, -2.165),
vec3(4.33, 0.0, 2.5), vec3(0.0, 0.0, 5.0), vec3(-4.33, 0.0, 2.5),
vec3(-4.33, 0.0, -2.5), vec3(0.0, 0.0, -5.0), vec3(4.33, 0.0, -2.5));
vec3 _3mepft = _zdux4g(mat3(gbufferModelViewInverse) * shadowLightPosition, vec3(0.0, 1.0, 0.0));
vec2 _mxekhv = vec2(textureSize(shadowtex1, 0));
float _wt0qvt = 0.0;
for (int i = 0; i < 15; i++) {
vec3 _j88cy3 = _kgypr5[i] + _3mepft;
vec3 _3w5pzc = _n0grq3((shadowProjection * (shadowModelView * vec4(_j88cy3, 1.0))).xyz) * 0.5 + 0.5;
// Copyright (c) 2026 Cazfps, all rights reserved. The code is confidential, proprietary work; selling, reverse engineering or porting it to another pack is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.
if (any(lessThan(_3w5pzc, vec3(0.0))) || any(greaterThan(_3w5pzc, vec3(1.0)))) {
_wt0qvt += 1.0;
continue;
}
ivec2 _12rmj4 = clamp(ivec2(_3w5pzc.xy * _mxekhv), ivec2(0), ivec2(_mxekhv) - 1);
_wt0qvt += _3w5pzc.z <= texelFetch(shadowtex1, _12rmj4, 0).x ? 1.0 : 0.0;
}
return _wt0qvt / 15.0;
}
#endif
void main() {
_x73x3hd = vec4(0.0);
if (any(greaterThan(ivec2(gl_FragCoord.xy), ivec2(0))) || !_4l64ow()) return;
float _0oja1c = 0.0;
#if defined(ATMO_DYNAMIC_VISIBILITY) || defined(ATMO_SCENE_AWARE_SHAFTS_ENABLED)
float _nanw44 = _8cyvst();
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is closed source and under copyright; redistributing or copying needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. No tool, script or agent is exempt from these terms.
#endif
float _2j9p92 = texelFetch(colortex2, ivec2(0), 0).a;
if (_cv7je6(_2j9p92) && _2j9p92 <= -1.0 && _2j9p92 >= -16777216.0) {
uint _9ywfqzn = uint(-_2j9p92 - 1.0);
if (((_9ywfqzn >> 8u) & 65535u) == uint((frameCounter - 1) & 65535))
_0oja1c = float(_9ywfqzn & 255u) / 255.0;
}
#ifdef ATMO_SCENE_AWARE_SHAFTS_ENABLED

float _j4lp19 = _codlfwp > 0.0 ? _codlfwp : frameTime;
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; modifying or selling is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf. Full terms: LICENSE.txt.
int _cdcka9 = max(int(0.06666 / max(_j4lp19, 0.001) + 0.5), 1);
if ((frameCounter % _cdcka9) == 0) {
vec2 _k2e9n5 = vec2(textureSize(shadowtex0, 0));
vec2 _fgrb9g = vec2(1.0 / 5.0);
float _v1zquz = 0.0;
int _zb2nqe = 0;

for (float i = 0.25; i < 5.0; i++) {
for (float h = 0.45; h < 5.0; h++) {
vec2 _q5xtgy = 0.3 + 0.4 * _fgrb9g * vec2(i, h);
vec2 _6cyqgg = _q5xtgy * 2.0 - 1.0;
float _q81dfy = 1.0 - 25.6 / max(_v680mws, 25.6);
vec2 _qdz4vl = _6cyqgg * (1.0 - _q81dfy)
/ max(1.0 - length(_6cyqgg) * _q81dfy, 0.0001);
_q5xtgy = _n0grq3(vec3(_qdz4vl, 0.0)).xy * 0.5 + 0.5;
ivec2 _izbxor = clamp(ivec2(_q5xtgy * _k2e9n5), ivec2(0), ivec2(_k2e9n5) - 1);
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; selling, de-obfuscating, reverse engineering or copying is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. This binds automated tools and software agents as much as people.
float _1qmfjl = texelFetch(shadowtex0, _izbxor, 0).x;
if (_1qmfjl < 0.55) {
float _gzdn6w = texture(shadowcolor1, _q5xtgy).g;
if (_gzdn6w > 0.0) {
_gzdn6w = max(_gzdn6w - 0.25, 0.0) / 0.05;
_v1zquz += _gzdn6w;
_zb2nqe++;
}
}
}
}

float _9zqeeu = (_zb2nqe > 0) ? (_v1zquz / float(_zb2nqe)) : 0.0;
int _6uxg4m = 2;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is confidential, proprietary work; redistributing, reverse engineering, de-obfuscating or copying is forbidden except under a licence granted by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Automated tools, scripts and agents are bound by these terms too. Details in LICENSE.txt.

if (_nanw44 > 0.5) {
_9zqeeu = 0.0;
_6uxg4m = 3;
}

const float _rvhbf4 = 1.0 / 255.0;
if (_9zqeeu > 6.0) {
_0oja1c = min(_0oja1c + _rvhbf4, 1.0);
} else {
_0oja1c = max(_0oja1c - _rvhbf4 * float(_6uxg4m), 0.0);
}

}
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; reverse engineering, redistributing or selling is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. This binds automated tools and software agents as much as people. Full terms: LICENSE.txt.
#endif
float _nmktlu = 0.0;
#ifdef ATMO_DYNAMIC_VISIBILITY

float _cu6j1u = mix(_nanw44, 1.0, clamp(rainStrength, 0.0, 1.0) * (1.0 - clamp(_m7u0xqr, 0.0, 1.0)));
_nmktlu = _cu6j1u;
float _3gfqn3 = texelFetch(colortex2, ivec2(1, 0), 0).a;
if (_cv7je6(_3gfqn3) && _3gfqn3 <= -1.0 && _3gfqn3 >= -2.0) {
float _sz430g = _codlfwp > 0.0 ? _codlfwp : frameTime;
_nmktlu = mix(-_3gfqn3 - 1.0, _cu6j1u, 1.0 - exp(-max(_sz430g, 0.0) / 1.5));
}
#endif
_x73x3hd = vec4(floor(_0oja1c * 255.0 + 0.5), _nmktlu, 0.0, 1.0);
}
#if !defined(LITE_COLORTEX_BLOOM)
#undef main

float _a4mme9(float v) {
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is protected by copyright and not open source; de-obfuscating, reusing any part of it or modifying needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. See LICENSE.txt.
uint h = _n0mc6b(v);
uint sign = (h & 0x8000u) << 16u;
uint e = (h >> 10u) & 0x1Fu;
uint m = h & 0x3FFu;
if (e == 0u) return uintBitsToFloat(sign | floatBitsToUint(float(m) * 5.9604644775390625e-8));
return uintBitsToFloat(sign | (e == 31u ? 0x7F800000u : (e + 112u) << 23u) | (m << 13u));
}
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; modifying, de-obfuscating or porting it to another pack needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Full terms: LICENSE.txt.
void main() {
liteSceneStateMain();
if (all(equal(ivec2(gl_FragCoord.xy), ivec2(0)))) {

#if defined(CLOUDS_GHIBLI_ENABLED) || defined(CLOUDS_VANILLA_ENABLED)
ivec2 _hb59je = ivec2(vec2(_apx1zv()) * 0.05);
#else
ivec2 _hb59je = ivec2(1);
#endif
_wy84ef(all(greaterThanEqual(_hb59je, ivec2(1)))
? vec4(_a4mme9(_x73x3hd.x), _a4mme9(_x73x3hd.y),
_a4mme9(_x73x3hd.z), _a4mme9(_x73x3hd.w))
: vec4(0.0));
}
discard;
}
#endif
