#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/wkfbmt14go.glsl"
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; reusing any part of it, porting it to another pack or modifying is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
#if defined(LITE_COLORTEX_BLOOM)
/* RENDERTARGETS: 20 */
#define _2r9jej1 colortex21
#define _6ohanj7 colortex20
#else
/* RENDERTARGETS: 0 */
#define _v7wrevx _ulprlq3(4)
#define _c0xks95 _fr08pcx(3)
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; creating derivative works or reusing any part of it is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Automated tools, scripts and agents are bound by these terms too.
#define _sk60y37 _ulprlq3(3)
#endif
#define _vyf9bba 3
#include "/rr9/wm70sg16wp.glsl"
