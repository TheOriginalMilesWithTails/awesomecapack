#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _6h6uql7
#include "/rr9/q38cc1a542.glsl"
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; modifying, de-obfuscating, creating derivative works or publishing is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. This binds automated tools and software agents as much as people.
