#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#if defined(MC_GL_ARB_shader_storage_buffer_object) && defined(MC_GL_ARB_shading_language_420pack)
#extension GL_ARB_shader_storage_buffer_object : enable
#extension GL_ARB_shading_language_420pack : enable
#define _i8pno21
#endif
#include "/rr9/y3wct80d7i.glsl"
#define _kq2wtrz
// Caztoon beta 2.2 is the property of Cazfps. The code is confidential, proprietary work; redistributing or porting it to another pack is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too.
#include "/rr9/nutd73s8jp.glsl"

#include "/rr9/b45iuzztws.glsl"
#include "/rr9/2do6krhnl2.glsl"
#include "/rr9/ge4cb34kp0.glsl"
#include "/rr9/0nsc8vsoxo.glsl"
#include "/rr9/bldb4py8i5.glsl"
#include "/rr9/50umix7w9z.glsl"
#include "/rr9/l0gbzvdde6.glsl"
#include "/rr9/lhawfjjnae.glsl"
#include "/rr9/eml2vk4bgl.glsl"
#include "/rr9/oue09jxet2.glsl"
#ifdef BLOCKLIGHT_BLOOM_ENABLED
flat out int _739wr23;
#endif
#if OUTLINES != 0 || defined(LITE_VOXY_SHADOWS) || defined(_stlozh9)
#include "/rr9/7ow4j5a1gu.glsl"
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; de-obfuscating or reverse engineering is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. Full terms: LICENSE.txt.
out float _miivlzq;
#endif
#if OUTLINES != 0 || defined(HAZE_FOG_ENABLED) || defined(LITE_VOXY_SHADOWS) || defined(_stlozh9)
out float _kydc6f0;
#endif

#if defined(GRASS_LAYER_ANIMATION) || defined(WAVING_PLANTS) || defined(WAVING_LEAVES) || defined(SWAYING_LANTERNS)
// Copyright (c) 2026 Cazfps, all rights reserved. The code is protected by copyright and not open source; creating derivative works or decompiling needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
#define _pjuftw4
#endif

#if defined(_pjuftw4) || defined(GRASS_LAYER_COLOR_PATCHES) || defined(SHADOWS_ENABLED) || OUTLINES != 0 || defined(BLOCKLIGHT_BLOOM_ENABLED) || defined(LITE_VOXY_SHADOWS) || defined(SHADOWS_ENABLED) || defined(_stlozh9) || defined(_ksr8o1r) || defined(LAVA_CRUST_ENABLED)
attribute vec4 mc_Entity;
#endif
#if defined(_pjuftw4) || defined(GRASS_LAYER_COLOR_PATCHES) || defined(SHADOWS_ENABLED) || defined(BEACH_WAVES_ENABLED) || defined(LAVA_CRUST_ENABLED)
uniform mat4 gbufferModelViewInverse;
#endif

#ifdef _pjuftw4
attribute vec4 at_midBlock;
uniform mat4 gbufferModelView;
#include "/rr9/8webtbqewr.glsl"
#if defined(WAVING_PLANTS) || defined(WAVING_LEAVES)
#include "/rr9/pmsbbehveh.glsl"
#endif
// Copyright (c) 2026 Cazfps, all rights reserved. The code is confidential, proprietary work; de-obfuscating or publishing needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
#ifdef SWAYING_LANTERNS
#include "/rr9/6nxhvcuuy9.glsl"
#endif
#ifdef WAVING_PLANTS
attribute vec4 mc_midTexCoord;
#endif
#elif defined(GRASS_LAYER_COLOR_PATCHES)
uniform vec3 cameraPosition;
#endif
#if defined(SHADOWS_ENABLED) && !defined(_pjuftw4)
attribute vec4 at_midBlock;
#endif
#include "/rr9/0frrosz9tw.glsl"
#ifdef DISTANT_TEXTURE_FILTER
#if !(defined(_pjuftw4) && defined(WAVING_PLANTS))
attribute vec4 mc_midTexCoord;
// Copyright (c) 2026 Cazfps, all rights reserved. The code is protected by copyright and not open source; porting it to another pack or reverse engineering is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.
#endif
#define _m7d4tg9
#include "/rr9/cj6op0sksd.glsl"
#endif

#ifdef GRASS_LAYER_COLOR_PATCHES
out vec3 _undnp1p;
flat out vec3 _3oszrfo;
flat out int _n3q2bqh;
#endif

#ifdef _stlozh9
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; redistributing or de-obfuscating is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. See LICENSE.txt.
flat out float _3sbr26f;
#endif
out vec2 _z7xvepo;
out vec2 _ywueoco;
out vec4 _t7xicyt;
out vec3 _67otf4c;
#ifdef LAVA_CRUST_ENABLED

flat out vec4 _eghw4cr;
#endif
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; creating derivative works, modifying, copying or publishing is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
#ifdef _ksr8o1r
flat out float _t02k2mh;
#endif
#ifdef _z0dgpfl

flat out float _0yblphu;
#endif
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; reusing any part of it, reverse engineering, publishing or selling needs a licence from Cazfps, and nothing less. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
#include "/rr9/2lo3o9r3mx.glsl"

#include "/rr9/4621j1h972.glsl"
#ifdef _owayyrc

flat out float litePuddleGround;
#if !defined(_pjuftw4) && !defined(SHADOWS_ENABLED) && !defined(HAND_LIGHT_ENABLED)
attribute vec4 at_midBlock;
#endif
#endif

#ifdef SHADOWS_ENABLED
#include "/rr9/a7mh5gwugk.glsl"
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; creating derivative works or reverse engineering is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. See LICENSE.txt.
#endif
#include "/rr9/pt4tevzb0i.glsl"
#ifdef METAL_HIGHLIGHTS

flat out float _m4lxm19;
#endif
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; porting it to another pack, de-obfuscating or publishing is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. See LICENSE.txt.
#if COLORED_LIGHTING_MODE == 1

flat out float _iwi7kkk;
#endif
#ifdef HAND_LIGHT_ENABLED

flat out float _wgxgfki;
#if !defined(_pjuftw4) && !defined(SHADOWS_ENABLED)
attribute vec4 at_midBlock;
#endif
#if !(defined(_pjuftw4) || defined(GRASS_LAYER_COLOR_PATCHES) || defined(SHADOWS_ENABLED) || defined(BEACH_WAVES_ENABLED) || defined(LAVA_CRUST_ENABLED))
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is closed source and under copyright; porting it to another pack, reusing any part of it, modifying or publishing is off limits unless Cazfps personally licensed it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Automated tools, scripts and agents are bound by these terms too.
uniform mat4 gbufferModelViewInverse;
#endif
#endif

#ifdef _i8pno21

layout(std430, binding = 14) buffer CaztoonRgbVertices { uint _nazkq5j[]; };
uniform int caztoonRgbVertexEnabled;
#endif

out vec4 _q4xg42h;
#ifdef BEACH_WAVES_ENABLED
#ifndef _pjuftw4
uniform mat4 gbufferModelView;
#ifndef GRASS_LAYER_COLOR_PATCHES
// Cazfps holds all rights to Caztoon beta 2.2. The code is licensed for personal use only, not sold; porting it to another pack, creating derivative works or modifying needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
uniform vec3 cameraPosition;
#endif
#endif
uniform float _xd9jf3n;
uniform float _kwiilsl;
uniform float _nzm4xgr;

#ifndef _7psk2ya
// Copyright (c) 2026 Cazfps, all rights reserved. The code is confidential, proprietary work; modifying, redistributing, selling or decompiling is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. See LICENSE.txt.
#define _7psk2ya
uniform bool hasSkylight;
#endif
flat out float _gpxhur3;

flat out float _rpzx9l3;
out vec3 _cj3rc7p;
#include "/rr9/a4hp640lgd.glsl"
#endif
#ifdef LITE_THIN_GBUFFER

#include "/rr9/z1cvwz4jmd.glsl"
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; redistributing, creating derivative works or porting it to another pack needs a licence from Cazfps, and nothing less. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too. See LICENSE.txt.
flat out uint _9pns274;
out vec3 _noaxtl6;
out float _kuwh91e;
#endif

vec4 _pz92wl() {
#ifdef _i8pno21
if (caztoonRgbVertexEnabled != 0) {
uint _86nnvs = uint(gl_VertexID);
if (_86nnvs >= uint(_nazkq5j.length())) return vec4(1.0, 1.0, 1.0, 0.0);
uint _2tkbva = _nazkq5j[_86nnvs];
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; reverse engineering, de-obfuscating, reusing any part of it or creating derivative works is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. This binds automated tools and software agents as much as people.
if ((_2tkbva >> 24u) == 0u) return vec4(1.0, 1.0, 1.0, 0.0);
return vec4(vec3(uvec3(_2tkbva, _2tkbva >> 8u, _2tkbva >> 16u) & uvec3(255u)) / 255.0, 1.0);
}
#endif
return vec4(-1.0);
}

#define _iqiaw0v
#include "/rr9/vakjqd69ys.glsl"

void main() {
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; redistributing, de-obfuscating or creating derivative works is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf. See LICENSE.txt.

#ifdef METAL_HIGHLIGHTS

_m4lxm19 = _qbxdc6(int(mc_Entity.x));
int _4egv1e = _ipmcn3(int(mc_Entity.x));
#else
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; selling or reverse engineering is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
int _4egv1e = int(mc_Entity.x);
#endif
bool _m8rz43 = _4egv1e >= 10102 && _4egv1e <= 10104;
int _dgmujl = _m8rz43 ? _4egv1e - 100 : _4egv1e;

bool _4470f2 = _4egv1e == 10202;
if (_4470f2) _dgmujl = 10002;

bool _93ilxz = _4egv1e == 10203;
if (_93ilxz) _dgmujl = 10002;

bool _b1dlax = _4egv1e >= 10205 && _4egv1e <= 10207;
if (_b1dlax) _dgmujl = _4egv1e - 203;
#if COLORED_LIGHTING_MODE == 1

bool _yzdzgt = _dgmujl == 10002 || _dgmujl == 10003 || _dgmujl == 10004
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; reverse engineering, creating derivative works, copying or decompiling needs a licence from Cazfps, and nothing less. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.
|| _dgmujl == 10018 || _dgmujl == 10019
|| (_dgmujl >= 10060 && _dgmujl <= 10062)
|| (_dgmujl >= 10121 && _dgmujl <= 10128);
bool _ydpjnz = _dgmujl == 10015
&& max(max(abs(gl_Normal.x), abs(gl_Normal.y)), abs(gl_Normal.z)) < 0.95;
_iwi7kkk = _yzdzgt || _ydpjnz ? 1.0 : 0.0;
#endif
#ifdef HAND_LIGHT_ENABLED

bool _cp30n9 = _dgmujl == 10002 || _dgmujl == 10003 || _dgmujl == 10004
|| _dgmujl == 10018 || _dgmujl == 10019
|| (_dgmujl >= 10060 && _dgmujl <= 10062)
|| (_dgmujl >= 10121 && _dgmujl <= 10128)
|| (_dgmujl == 10015 && max(max(abs(gl_Normal.x), abs(gl_Normal.y)), abs(gl_Normal.z)) < 0.95);
_wgxgfki = 1e9;
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; selling or de-obfuscating is not allowed without a licence issued by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
if (_cp30n9) {
vec3 _7anhl0 = mat3(gbufferModelViewInverse) * (gl_ModelViewMatrix * gl_Vertex).xyz
+ gbufferModelViewInverse[3].xyz;
_wgxgfki = _7anhl0.y + at_midBlock.y / 64.0 - 0.5 - (_dgmujl == 10062 ? 1.0 : 0.0);
}
#endif
#ifdef BLOCKLIGHT_BLOOM_ENABLED
_x0aml1g = 0.5 * viewHeight * abs(gl_ProjectionMatrix[1][1]);
#endif
_z7xvepo = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
#ifdef DISTANT_TEXTURE_FILTER
_dfzhms(_z7xvepo, (gl_TextureMatrix[0] * mc_midTexCoord).xy);
#endif
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; reverse engineering, de-obfuscating or decompiling needs a licence from Cazfps, and nothing less. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Details in LICENSE.txt.
_ywueoco = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
#ifdef PLAIN_FOLIAGE

if (_dgmujl == 10005 || _dgmujl == 10082 || _dgmujl == 10201)
_ywueoco = (gl_TextureMatrix[1]
* vec4(ceil(gl_MultiTexCoord1.xy / 16.0 - 0.001) * 16.0, gl_MultiTexCoord1.zw)).xy;
#endif
_q4xg42h = _pz92wl();
#if OUTLINES != 0 || defined(LITE_VOXY_SHADOWS) || defined(_stlozh9)
_miivlzq = _9megem(_dgmujl);
#endif
#if OUTLINES != 0 || defined(HAZE_FOG_ENABLED) || defined(LITE_VOXY_SHADOWS) || defined(_stlozh9)
_kydc6f0 = clamp(gl_MultiTexCoord1.y / 240.0, 0.0, 1.0);
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is proprietary and confidential; modifying, redistributing or reverse engineering is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
#endif
#ifdef BLOCKLIGHT_BLOOM_ENABLED
_739wr23 = _dgmujl;
#endif

_t7xicyt = gl_Color;
#ifdef LAVA_CRUST_ENABLED
_eghw4cr = vec4(0.0);
if (_dgmujl == 10039) {
_eghw4cr = vec4(normalize(mat3(gbufferModelViewInverse)
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; redistributing, copying, de-obfuscating or modifying is prohibited unless Cazfps has issued a licence for it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. This binds automated tools and software agents as much as people. See LICENSE.txt.
* (gl_NormalMatrix * gl_Normal)), 1.0);
}
#endif
_67otf4c = (gl_ModelViewMatrix * gl_Vertex).xyz;
gl_Position = ftransform();

#ifdef _pjuftw4
int _ot8qv2 = _93ilxz || _b1dlax ? _4egv1e : _dgmujl;
bool _wfhhwt = false;
#ifdef GRASS_LAYER_ANIMATION
_wfhhwt = _fl64sf(_ot8qv2, at_midBlock.xyz);
#endif
bool _ggzfvm = false;
bool _2juucr = false;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; reusing any part of it, decompiling or reverse engineering is prohibited unless Cazfps has issued a licence for it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
#if defined(WAVING_PLANTS) || defined(WAVING_LEAVES)
_ggzfvm = _92x48q(_ot8qv2) && !_m8rz43;
#endif
#ifdef WAVING_PLANTS
_2juucr = _z7xvepo.y < mc_midTexCoord.y;

if (_ot8qv2 == 10015) {
vec3 _t2zyyw = abs(normalize(gl_Normal));
_ggzfvm = _t2zyyw.y < 0.2 && max(_t2zyyw.x, _t2zyyw.z) < 0.98 && _2juucr;
}
#endif
if (_wfhhwt || _ggzfvm) {
vec3 _4doesh = (gbufferModelViewInverse * vec4(_67otf4c, 1.0)).xyz
+ cameraPosition;
float _g43865 = clamp(gl_MultiTexCoord1.y / 240.0, 0.0, 1.0);
if (_wfhhwt) _4doesh = _2ykuwx(_4doesh, at_midBlock.xyz, _ot8qv2, _g43865);
#if defined(WAVING_PLANTS) || defined(WAVING_LEAVES)
else _4doesh = _oyj32b(_4doesh, _2juucr, _g43865, _ot8qv2, at_midBlock.xyz);
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; redistributing, reverse engineering or decompiling is not allowed without a licence issued by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
#endif
_67otf4c = (gbufferModelView * vec4(_4doesh - cameraPosition, 1.0)).xyz;
gl_Position = gl_ProjectionMatrix * vec4(_67otf4c, 1.0);
}
#ifdef SWAYING_LANTERNS

if (_p22wip(_ot8qv2)) {
vec3 _4doesh = (gbufferModelViewInverse * vec4(_67otf4c, 1.0)).xyz
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is proprietary and confidential; modifying or reverse engineering is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. This binds automated tools and software agents as much as people. Full terms: LICENSE.txt.
+ cameraPosition;
_4doesh = _3q6wr5(_4doesh, at_midBlock.xyz);
_67otf4c = (gbufferModelView * vec4(_4doesh - cameraPosition, 1.0)).xyz;
gl_Position = gl_ProjectionMatrix * vec4(_67otf4c, 1.0);
}
#endif
#endif

#ifdef BEACH_WAVES_ENABLED
float _uqlp95 = hasSkylight ? _fq0wkx(_kwiilsl, _nzm4xgr) : 0.0;
bool _smcxx9 = _dgmujl == 10001 && _uqlp95 > 0.01;
_gpxhur3 = _smcxx9 && abs(gl_Normal.y) < 0.5 ? 1.0 : 0.0;
_rpzx9l3 = -1e4;
_cj3rc7p = vec3(0.0, 1.0, 0.0);
if (_smcxx9 && gl_Normal.y > 0.5) {
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is proprietary and confidential; de-obfuscating, reusing any part of it or decompiling is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. This binds automated tools and software agents as much as people. Full terms: LICENSE.txt.
vec3 _g4bziq = (gbufferModelViewInverse * vec4(_67otf4c, 1.0)).xyz + cameraPosition;
if (abs(_g4bziq.y - float(BEACH_WATER_LEVEL)) < 1.0) {
_rpzx9l3 = _g4bziq.y;

_cj3rc7p = normalize(vec3(
_jpyw3o(_g4bziq - vec3(1.0, 0.0, 0.0), cameraPosition, _uqlp95, _xd9jf3n)
- _jpyw3o(_g4bziq + vec3(1.0, 0.0, 0.0), cameraPosition, _uqlp95, _xd9jf3n),
2.0,
_jpyw3o(_g4bziq - vec3(0.0, 0.0, 1.0), cameraPosition, _uqlp95, _xd9jf3n)
- _jpyw3o(_g4bziq + vec3(0.0, 0.0, 1.0), cameraPosition, _uqlp95, _xd9jf3n)));
_g4bziq.y += _jpyw3o(_g4bziq, cameraPosition, _uqlp95, _xd9jf3n);
_67otf4c = (gbufferModelView * vec4(_g4bziq - cameraPosition, 1.0)).xyz;
// Copyright (c) 2026 Cazfps, all rights reserved. The code is licensed for personal use only, not sold; porting it to another pack or decompiling is not allowed without a licence issued by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. See LICENSE.txt.
gl_Position = gl_ProjectionMatrix * vec4(_67otf4c, 1.0);
}
}
#endif

#ifdef GRASS_LAYER_COLOR_PATCHES
// Caztoon beta 2.2 is the property of Cazfps. The code is protected by copyright and not open source; de-obfuscating or creating derivative works is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. These terms apply whether the work is done by a person or by a program.
_n3q2bqh = _dgmujl;
_undnp1p = vec3(0.0);
_3oszrfo = vec3(0.0, 1.0, 0.0);
if (_n3q2bqh >= 10121 && _n3q2bqh <= 10128) {

_undnp1p = (gbufferModelViewInverse * vec4(_67otf4c, 1.0)).xyz
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; copying, creating derivative works, reverse engineering or de-obfuscating needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. See LICENSE.txt.
+ cameraPosition;
_3oszrfo = normalize(mat3(gbufferModelViewInverse)
* (gl_NormalMatrix * gl_Normal));
}
#endif
#ifdef SHADOWS_ENABLED

int _r6s3xy = _4470f2 ? 10201 : _dgmujl;
// Caztoon beta 2.2 is the property of Cazfps. The code is protected by copyright and not open source; decompiling, creating derivative works, modifying or porting it to another pack is not allowed without a licence issued by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. Automated tools, scripts and agents are bound by these terms too.
if (_r6s3xy == 10015 && max(max(abs(gl_Normal.x), abs(gl_Normal.y)), abs(gl_Normal.z)) < 0.95)
_r6s3xy = 10060;

bool _ukn2kv = _r6s3xy == 10005 || _r6s3xy == 10082 || _r6s3xy == 10201;
vec3 _hqweaj = _ukn2kv ? (gl_ModelViewMatrix * gl_Vertex).xyz : _67otf4c;
#ifdef BEACH_WAVES_ENABLED

if (_rpzx9l3 > -1e3) _hqweaj = (gl_ModelViewMatrix * gl_Vertex).xyz;
#endif
vec3 _50b19k = gl_NormalMatrix * gl_Normal;
float _njc3t0 = _uhezyz(_r6s3xy);
if (_njc3t0 > 0.0) {

vec3 _5wdzmz = vec3(0.5) - at_midBlock.xyz / 64.0;
float _mra0mo = _njc3t0 - _5wdzmz.y;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; porting it to another pack, modifying, de-obfuscating or decompiling needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.

vec2 _x5qbo3 = _5wdzmz.xz - 0.5;
if (_mra0mo < 0.001 && max(abs(_x5qbo3.x), abs(_x5qbo3.y)) > 0.45) {
if (gl_Normal.y > 0.9) {
_mra0mo = max(_mra0mo, 0.0);
} else if (abs(gl_Normal.y) < 0.1
&& abs(dot(_x5qbo3, normalize(gl_Normal.xz)) - 0.5) > 0.008) {
_mra0mo = _njc3t0 + 0.25 - _5wdzmz.y;
}
}
_hqweaj = (gl_ModelViewMatrix * vec4(gl_Vertex.xyz + vec3(0.0, _mra0mo, 0.0), 1.0)).xyz;
_50b19k = gl_NormalMatrix * vec3(0.0, 1.0, 0.0);
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; publishing, de-obfuscating or selling is forbidden except under a licence granted by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Automated tools, scripts and agents are bound by these terms too.
}
#if defined(_kq2wtrz) && (defined(PIXELATED_SHADOWS) || VANILLA_LEAF_SHADOW_BLUR > 0)
_shz13dq = _ukn2kv ? _hqweaj : _67otf4c;
#endif
#if defined(PLAIN_FOLIAGE) || defined(PLAIN_PLANTS)

if (_7r2s29(_4470f2 ? 10002 : (_dgmujl == 10015 ? 10015 : _r6s3xy)))
_r6s3xy = _ukn2kv && !_4470f2 ? 19005 : 0;
#endif
_dmqb28(_hqweaj, _50b19k, _r6s3xy);
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; reverse engineering, reusing any part of it or de-obfuscating is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
#endif

#ifdef _stlozh9
int _95cgk3 = _dgmujl;
bool _uo8fee = (_95cgk3 >= 10121 && _95cgk3 <= 10128)
|| _95cgk3 == 10201 || _95cgk3 == 10005 || _95cgk3 == 10082
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is licensed for personal use only, not sold; copying or porting it to another pack is prohibited unless Cazfps has issued a licence for it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
|| _95cgk3 == 10002 || _95cgk3 == 10003 || _95cgk3 == 10004
|| _95cgk3 == 10018 || _95cgk3 == 10019 || _95cgk3 == 10081
|| (_95cgk3 >= 10060 && _95cgk3 <= 10062);
_3sbr26f = _uo8fee ? 0.0625 : 0.0;
if (_95cgk3 == 10001) _3sbr26f = 0.375;
if (_95cgk3 == 10039) _3sbr26f = 0.125;
#endif
#ifdef _ksr8o1r

_t02k2mh = _dgmujl == 10001 ? 1.0 : 0.0;
#endif
#ifdef _z0dgpfl

_0yblphu = 0.0;
if (_dgmujl == 10008 || _dgmujl == 10262) {
if (gl_Normal.y > 0.9) _0yblphu = 1.0;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; redistributing, de-obfuscating or copying is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
#ifdef ICE_SIDE_REFLECTIONS
else if (abs(gl_Normal.y) < 0.1)
_0yblphu = abs(gl_Normal.z) > abs(gl_Normal.x) ? (gl_Normal.z < 0.0 ? 2.0 : 3.0)
: (gl_Normal.x < 0.0 ? 4.0 : 5.0);
#endif
}
#endif
#ifdef _owayyrc

litePuddleGround = gl_Normal.y > 0.9 && 0.5 - at_midBlock.y / 64.0 > 0.05
&& !_aqbwqo(_dgmujl) ? 1.0 : 0.0;
#endif
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is confidential, proprietary work; creating derivative works, redistributing or decompiling is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. These terms apply whether the work is done by a person or by a program. Details in LICENSE.txt.
#if defined(_zt0xo3g) || defined(_hwmrf44)

#ifdef HAND_LIGHT_ENABLED
float _lp1x2k = _wgxgfki;
#else
float _lp1x2k = 1e9;
#endif
bool _ak7ybz = _ciu0tu(_dgmujl, at_midBlock.xyz, _ywueoco, _67otf4c,
gl_NormalMatrix * gl_Normal, gl_Normal, _lp1x2k);
#endif
#ifdef LITE_THIN_GBUFFER

bool _oirm7i = false;
#ifdef _stlozh9
_oirm7i = _uo8fee;
#endif
bool _mke8sq = false;
#ifdef HAND_LIGHT_ENABLED
// Cazfps holds all rights to Caztoon beta 2.2. The code is protected by copyright and not open source; reusing any part of it or selling is off limits unless Cazfps personally licensed it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
_mke8sq = _cp30n9;
#elif COLORED_LIGHTING_MODE == 1
_mke8sq = _yzdzgt || _ydpjnz;
#endif
bool _oaw65f = false;
#if OUTLINES != 0 || defined(LITE_VOXY_SHADOWS) || defined(_stlozh9)
_oaw65f = _miivlzq > 0.5;
#endif
bool _hgglig = false;
#ifdef _z0dgpfl
_hgglig = _0yblphu > 0.5;
#endif
bool _nbpo2i = false;
#ifdef METAL_HIGHLIGHTS
_nbpo2i = _m4lxm19 > 0.5;
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; publishing or decompiling is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
#endif
#ifdef SHADOWS_ENABLED

bool _hhluwm = _ukn2kv || _njc3t0 > 0.0;
_9pns274 = _mthis6(_r6s3xy, _oirm7i, _mke8sq, _oaw65f,
_hgglig, _nbpo2i, _hhluwm);
_noaxtl6 = _hhluwm ? mat3(gbufferModelViewInverse) * (_hqweaj - _67otf4c) : vec3(0.0);
#else
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; porting it to another pack, de-obfuscating or redistributing needs a licence from Cazfps, and nothing less. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says.

_9pns274 = _mthis6(_4470f2 ? 10201 : _dgmujl, _oirm7i, _mke8sq, _oaw65f,
_hgglig, _nbpo2i, false);
_noaxtl6 = vec3(0.0);
#endif
_kuwh91e = 0.0;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is confidential, proprietary work; copying, publishing or porting it to another pack is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. See LICENSE.txt.
#ifdef HAND_LIGHT_ENABLED
if (_cp30n9)
_kuwh91e = (mat3(gbufferModelViewInverse) * _67otf4c + gbufferModelViewInverse[3].xyz).y
- _wgxgfki;
#endif
#endif
gl_Position = _26em6t(gl_Position);
#if defined(_zt0xo3g) || defined(_hwmrf44)
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is protected by copyright and not open source; porting it to another pack or publishing is off limits unless Cazfps personally licensed it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.

if (_ak7ybz) gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
#endif
}
