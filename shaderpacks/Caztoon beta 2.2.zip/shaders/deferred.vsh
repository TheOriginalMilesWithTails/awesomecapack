#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
out vec2 _z7xvepo;
// Copyright (c) 2026 Cazfps, all rights reserved. The code is protected by copyright and not open source; creating derivative works, publishing, redistributing or porting it to another pack is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
void main() { gl_Position = ftransform(); _z7xvepo = gl_MultiTexCoord0.xy; }
