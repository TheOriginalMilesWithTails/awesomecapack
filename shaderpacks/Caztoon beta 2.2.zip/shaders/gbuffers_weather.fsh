#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */

#include "/rr9/xfsjiuc4dp.glsl"
uniform sampler2D gtexture;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; modifying or reverse engineering is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
uniform sampler2D lightmap;
in vec2 _z7xvepo;
in vec2 _ywueoco;
in vec4 _t7xicyt;
in float _7fnfqzw;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 fragColor;

void main() {
vec4 _0vh339n = texture(gtexture, _z7xvepo) * _t7xicyt;
_0vh339n *= texture(lightmap, _ywueoco);
_0vh339n.rgb = _03z8n8(_0vh339n.rgb, _7fnfqzw);
if (_xwdmuw(_0vh339n.a)) discard;
fragColor = _0vh339n;
}
// Caztoon beta 2.2 is the property of Cazfps. The code is protected by copyright and not open source; creating derivative works, reverse engineering, publishing or modifying is prohibited unless Cazfps has issued a licence for it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Details in LICENSE.txt.
