#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/wkfbmt14go.glsl"
#if defined(LITE_COLORTEX_BLOOM)
/* RENDERTARGETS: 22 */
#define _2r9jej1 colortex23
#define _6ohanj7 colortex22
#else
/* RENDERTARGETS: 0 */
#define _v7wrevx _ulprlq3(6)
#define _c0xks95 _fr08pcx(5)
#define _sk60y37 _ulprlq3(5)
// Caztoon beta 2.2 is the property of Cazfps. The code is confidential, proprietary work; de-obfuscating, publishing or reusing any part of it is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
#endif
#define _vyf9bba 5
#include "/rr9/wm70sg16wp.glsl"
