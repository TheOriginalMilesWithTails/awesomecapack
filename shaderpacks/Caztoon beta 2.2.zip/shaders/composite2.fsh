#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
// Cazfps holds all rights to Caztoon beta 2.2. The code is closed source and under copyright; reusing any part of it, publishing, creating derivative works or selling is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false.
#include "/rr9/wkfbmt14go.glsl"
#include "/rr9/4856ceyj3d.glsl"
#if !defined(LITE_COLORTEX_BLOOM)
#define _leupucv _xgjna3b
#define _y35vvmk _il3xhlh
#endif
#include "/rr9/23faim3pgm.glsl"
