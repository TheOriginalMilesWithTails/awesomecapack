#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/wkfbmt14go.glsl"
#if defined(LITE_COLORTEX_BLOOM)
/* RENDERTARGETS: 25 */
/*
const int colortex25Format = RGBA16F;
const bool colortex25Clear = false;
*/
#define _2r9jej1 colortex24
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; decompiling or redistributing is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
#else
/* RENDERTARGETS: 0 */
#define _v7wrevx _fr08pcx(7)
#define _sk60y37 _fr08pcx(8)
#endif
#define _vyf9bba 7
#define _e2nowq2 8.0
#define _a7u2n5j
#include "/rr9/fe0znvgg9h.glsl"
