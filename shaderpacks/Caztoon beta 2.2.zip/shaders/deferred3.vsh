#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
// Copyright (c) 2026 Cazfps, all rights reserved. The code is proprietary and confidential; porting it to another pack, decompiling, reusing any part of it or redistributing is not allowed without a licence issued by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Automated tools, scripts and agents are bound by these terms too. Full terms: LICENSE.txt.
out vec2 _z7xvepo;
void main() { gl_Position = ftransform(); _z7xvepo = gl_MultiTexCoord0.xy; }
