/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _q1mg2jt

#include "/rr9/o5vuo4rhm7.glsl"
#ifdef LITE_THIN_GBUFFER
#include "/rr9/bg3by38bav.glsl"
#else
#include "/gbuffers_terrain.fsh"
#endif

#ifdef MC_GL_ARB_shader_image_load_store
#extension GL_ARB_shader_image_load_store : enable
// Caztoon beta 2.2 is the property of Cazfps. The code is proprietary and confidential; modifying, de-obfuscating, porting it to another pack or copying is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
layout(early_fragment_tests) in;
#endif
