#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; decompiling, porting it to another pack, copying or reusing any part of it is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Details in LICENSE.txt.
out vec2 _z7xvepo;
void main() {
gl_Position = ftransform();
_z7xvepo = gl_MultiTexCoord0.xy;
}
