#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/lhawfjjnae.glsl"
#include "/rr9/s3wx2oemv8.glsl"
#include "/rr9/6l8zsqvd9g.glsl"
uniform sampler2D colortex6;
/* RENDERTARGETS: 6 */
layout(location = 0) out vec4 _q91c319;
/*
const int colortex6Format = RGBA16F;
const bool colortex6Clear = false;
*/
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; reverse engineering, publishing, modifying or decompiling is off limits unless Cazfps personally licensed it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Full terms: LICENSE.txt.

vec2 _lchxh6(vec4 _utd067) {
return clamp(_utd067.rg / max(_utd067.ba, vec2(1e-6)), vec2(0.0), vec2(1.0));
}

vec2 _gi3gs9(vec2 _ncnxva, vec2 _8zznqh, float _s6knab, float _cab3zv) {
float w1 = 2.0 * _cab3zv + _s6knab;
float w2 = _cab3zv + 2.0 * _s6knab;
vec2 _j03um9 = sign(_ncnxva) * (w1 + w2)
/ (w1 / max(abs(_ncnxva), vec2(1e-12)) + w2 / max(abs(_8zznqh), vec2(1e-12)));
return mix(vec2(0.0), _j03um9, greaterThan(_ncnxva * _8zznqh, vec2(0.0)));
}

void main() {
_q91c319 = vec4(0.0);
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; copying or redistributing is not allowed without a licence issued by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
#ifdef _gorz9q1
ivec2 _iq6b4j = textureSize(colortex6, 0) / ivec2(_g6ho9o, _ybem68);
if (any(lessThan(_iq6b4j, ivec2(2)))) return;
ivec2 _btdiwo = ivec2(gl_FragCoord.xy);
ivec2 _4g5zt9 = _btdiwo / _iq6b4j;
if (_4g5zt9.x >= _g6ho9o || _4g5zt9.y >= _ybem68) return;
ivec2 _a8mxcz = _btdiwo - _4g5zt9 * _iq6b4j;
int _00418m = _4g5zt9.y * _g6ho9o + _4g5zt9.x + 1;
vec4 _utd067 = vec4(0.0);
vec4 _2j9p92 = vec4(0.0), _8jr9zi = vec4(0.0);
for (int i = 0; i < min(_00418m + 1, _ua61ee); ++i) {
ivec2 _7cstjz = ivec2(i % _g6ho9o, i / _g6ho9o);
_utd067 += texelFetch(colortex6, _7cstjz * _iq6b4j + _a8mxcz, 0);
if (i + 1 == _00418m - 1) _2j9p92 = _utd067;
if (i + 1 == _00418m) _8jr9zi = _utd067;
}
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; copying, modifying, reusing any part of it or decompiling is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com.
vec2 _lp8q2a = _lchxh6(_8jr9zi);
vec2 _qfbgoe = vec2(0.0);

if (_00418m > 1 && _00418m < _ua61ee) {
float _s6knab = _oqsmi9(float(_00418m)) - _oqsmi9(float(_00418m - 1));
float _cab3zv = _oqsmi9(float(_00418m + 1)) - _oqsmi9(float(_00418m));
_qfbgoe = _gi3gs9((_lp8q2a - _lchxh6(_2j9p92)) / _s6knab,
(_lchxh6(_utd067) - _lp8q2a) / _cab3zv, _s6knab, _cab3zv);
}

_q91c319 = vec4(_lp8q2a, _qfbgoe);
#endif
// Copyright (c) 2026 Cazfps, all rights reserved. The code is closed source and under copyright; porting it to another pack, creating derivative works, de-obfuscating or decompiling is forbidden except under a licence granted by Cazfps. No permission is implied by having this file, and a claim of permission is not permission. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
}
