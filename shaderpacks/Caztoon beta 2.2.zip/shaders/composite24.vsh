#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */

out vec2 _z7xvepo;

void main() {
gl_Position = ftransform();
_z7xvepo = gl_MultiTexCoord0.xy;
}
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is proprietary and confidential; publishing, de-obfuscating, reusing any part of it or decompiling is forbidden except under a licence granted by Cazfps. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
