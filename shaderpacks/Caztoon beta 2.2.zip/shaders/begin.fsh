#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/lhawfjjnae.glsl"
/* RENDERTARGETS: 0 */
#ifdef NETHER_FOG_ENABLED
#include "/rr9/2zzn9360aq.glsl"
uniform int biome;
uniform bool hasCeiling;
uniform bool hasSkylight;
uniform int isEyeInWater;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is confidential, proprietary work; redistributing, publishing or decompiling is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program.
uniform float blindness;
#endif
layout(location = 0) out vec4 fragColor;
void main() {
#ifdef NETHER_FOG_ENABLED

if (_p9holq(biome, hasCeiling, hasSkylight)
&& isEyeInWater == 0 && blindness < 0.001) {
fragColor = vec4(_epg44s(biome) * NETHER_BRIGHTNESS, 1.0);
return;
}
#endif
discard;
}
