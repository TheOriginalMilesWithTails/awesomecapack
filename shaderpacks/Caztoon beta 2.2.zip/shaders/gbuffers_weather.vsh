#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */

out vec2 _z7xvepo;
out vec2 _ywueoco;
// Caztoon beta 2.2 is the property of Cazfps. The code is protected by copyright and not open source; reusing any part of it, reverse engineering, de-obfuscating or decompiling is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program.
out vec4 _t7xicyt;
out float _7fnfqzw;

void main() {
_z7xvepo = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;

_ywueoco = clamp(gl_MultiTexCoord1.xy / 256.0, vec2(0.5 / 16.0), vec2(15.5 / 16.0));
_t7xicyt = gl_Color;
vec4 _67otf4c = gl_ModelViewMatrix * gl_Vertex;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; de-obfuscating or copying is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
_7fnfqzw = length(_67otf4c.xyz);
gl_Position = gl_ProjectionMatrix * _67otf4c;
}
