/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#define _bbr0ecr
// Copyright (c) 2026 Cazfps, all rights reserved. The code is licensed for personal use only, not sold; porting it to another pack, redistributing, decompiling or copying is prohibited unless Cazfps has issued a licence for it. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. Automated tools, scripts and agents are bound by these terms too. Details in LICENSE.txt.
#include "/rr9/ge027kcckc.glsl"
