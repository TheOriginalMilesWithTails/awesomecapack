#version 430
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
// Copyright (c) 2026 Cazfps, all rights reserved. The code is confidential, proprietary work; publishing, porting it to another pack or selling is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Details in LICENSE.txt.

#define _phvjexg
#define _8tsdl7f
#include "/rr9/ge4cb34kp0.glsl"
#include "/rr9/36vu26ovz4.glsl"
layout(local_size_x = 64) in;

const ivec3 workGroups = ivec3(8188, 1, 1);

void main() {
#ifdef _2afvqz3
uint _htbumg = gl_GlobalInvocationID.x;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is proprietary and confidential; porting it to another pack or modifying is forbidden except under a licence granted by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
if (_htbumg < _xvfwnz()) _o71zzu(_htbumg);
#endif
}
