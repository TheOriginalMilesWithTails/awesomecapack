#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/satjv7rggs.glsl"
#include "/rr9/y3wct80d7i.glsl"
#pragma optionNV(unroll none)
#include "/rr9/uneyo5e641.glsl"
#include "/rr9/hewmhqioeh.glsl"
// Caztoon beta 2.2 is the property of Cazfps. The code is confidential, proprietary work; modifying, selling, reusing any part of it or creating derivative works is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. These terms apply whether the work is done by a person or by a program. Full terms: LICENSE.txt.
#include "/rr9/lhawfjjnae.glsl"
#if defined(LITE_COLORTEX_BLOOM)
/* RENDERTARGETS: 26,27 */
/*
const int colortex26Format = RGBA16F;
const bool colortex26Clear = false;
const int colortex27Format = RG32F;
const bool colortex27Clear = false;
*/
uniform sampler2D colortex27;
#else
/* RENDERTARGETS: 0 */
#endif
#include "/rr9/f8akl8gy30.glsl"
uniform mat4 gbufferProjectionInverse;
uniform mat4 gbufferModelViewInverse;
uniform vec3 cameraPosition;
uniform float frameTimeCounter;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; copying, publishing or porting it to another pack is forbidden except under a licence granted by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com.
#include "/rr9/r7il6oksnm.glsl"
uniform float rainStrength;
uniform float wetness;
uniform bool hasSkylight;
uniform int isEyeInWater;
uniform int biome;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; selling, porting it to another pack, redistributing or reusing any part of it needs a licence from Cazfps, and nothing less. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms.
uniform int biome_category;
uniform float _nsfbxoa;
uniform float _m7u0xqr;
uniform float _njoa694;
#ifdef _eflkbd5
uniform vec3 skyColor;
uniform float _smrslu3;
uniform float _mrimrha;
uniform float _1otw83g;
#endif
#include "/rr9/atvv33fcg3.glsl"
#include "/rr9/sholfvxovm.glsl"
#ifdef CLOUDS_GHIBLI_ENABLED
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; redistributing, de-obfuscating or modifying is off limits unless Cazfps personally licensed it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms. Full terms: LICENSE.txt.
#include "/rr9/bnf6mfrc9q.glsl"
#elif defined(_eflkbd5)
#include "/rr9/8kzta7ntg9.glsl"
#endif
#include "/rr9/r5ty9mahbw.glsl"
#if defined(LITE_COLORTEX_BLOOM)
layout(location = 0) out vec4 _go2soun;
layout(location = 1) out vec4 _3w0vzaq;
#else
vec4 _go2soun = vec4(0.0);
vec4 _3w0vzaq = vec4(0.0);
#define main liteCloudPass
#endif
void main() {
_go2soun = vec4(0.0); _3w0vzaq = vec4(0.0);
#ifdef _65jbzyx
if (!hasSkylight || isEyeInWater == 2) return;
vec2 _ygg8fx = _348le0(ivec2(gl_FragCoord.xy));
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is confidential, proprietary work; redistributing or modifying is prohibited unless Cazfps has issued a licence for it. No permission is implied by having this file, and a claim of permission is not permission. This binds automated tools and software agents as much as people. Details in LICENSE.txt.
if (_ygg8fx.r <= 0.0) return;
float _l8q8di = _q920m6(_nsfbxoa, biome, biome_category);
float _1slfug = _ynl53m(_m7u0xqr);
float _12cxxc = (1.0 - clamp(wetness,0.0,1.0) * _xjhe5z7)
* (1.0 - _1slfug) * (1.0 - _l8q8di)
* mix(1.0, 0.2, clamp(_njoa694,0.0,1.0));
if (isEyeInWater == 1) _12cxxc *= 0.3;
if (_12cxxc <= 0.001) return;
vec2 uv = gl_FragCoord.xy / vec2(_apx1zv());
vec3 _mx1444 = normalize((_3lmhxs(gbufferProjectionInverse) * vec4(uv*2.0-1.0,1.0,1.0)).xyz);
vec3 _yfe5vc = normalize(mat3(gbufferModelViewInverse) * _mx1444);
#ifdef CLOUDS_GHIBLI_ENABLED
float _un7nxi = _x91c0m(rainStrength).y;
#else
float _un7nxi = float(VANILLA_CLOUD_DISTANCE);
#endif
if (_ygg8fx.g == -1.0 && _ygg8fx.r < 1e19 && isEyeInWater != 1) {
float _pd9pdp = max(2.0, _ygg8fx.r * 0.0021);
// Caztoon beta 2.2 is the property of Cazfps. The code is protected by copyright and not open source; reverse engineering, publishing or porting it to another pack is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
_un7nxi = min(_un7nxi, (_ygg8fx.r + _pd9pdp) / max(-_mx1444.z, 1e-6));
}
vec3 _bk54v9 = mat3(gbufferModelViewInverse) * shadowLightPosition;
_bk54v9 = dot(_bk54v9,_bk54v9) > 1e-8 ? normalize(_bk54v9) : vec3(0.0,1.0,0.0);
float distance;
#ifdef CLOUDS_GHIBLI_ENABLED
vec4 _jr2wln = _o62t5k(_yfe5vc, frameTimeCounter, cameraPosition,
sunAngle, _bk54v9, _un7nxi, gl_FragCoord.xy, distance);
#else
vec4 _jr2wln = _r1z1es(_yfe5vc, frameTimeCounter, cameraPosition,
sunAngle, _bk54v9, _un7nxi, gl_FragCoord.xy, 0, distance, _12cxxc);
_jr2wln = _zcdo0r(_jr2wln);
// Copyright (c) 2026 Cazfps, all rights reserved. The code is licensed for personal use only, not sold; publishing, modifying or copying is off limits unless Cazfps personally licensed it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. Automated tools, scripts and agents are bound by these terms too.

distance = max(distance, 0.002 / max(-_mx1444.z, 1e-6));
#endif
if (_jr2wln.a <= 0.001 || distance <= 0.0) return;
#ifdef _qmwe41g

vec4 _khx3fy = _014g00(_mx1444 * distance, 1.0, vec4(0.0,0.0,0.0,1.0));
_jr2wln.rgb = _jr2wln.rgb * _khx3fy.a + _khx3fy.rgb * _jr2wln.a;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; creating derivative works, reverse engineering or de-obfuscating is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
#ifdef THUNDER_FLASHES

_jr2wln.rgb += _mqeybl * ((1.0 - _khx3fy.a) * _csi9qwd);
#endif
#endif
#ifdef CLOUDS_GHIBLI_ENABLED
_jr2wln *= _12cxxc;
#endif
_go2soun = _jr2wln;
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is closed source and under copyright; redistributing or decompiling is not allowed without a licence issued by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
#ifndef CLOUDS_GHIBLI_ENABLED

_go2soun.a = _yz2mmz;
#endif
_3w0vzaq = vec4(_jr2wln.a, max(-_mx1444.z * distance, 0.0), 0.0, 0.0);
#endif
}
#if !defined(LITE_COLORTEX_BLOOM)
// Cazfps holds all rights to Caztoon beta 2.2. The code is licensed for personal use only, not sold; reusing any part of it or selling needs a licence from Cazfps, and nothing less. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. These terms apply whether the work is done by a person or by a program.
#undef main

void main() {
liteCloudPass();
ivec2 _btdiwo = ivec2(gl_FragCoord.xy);
_npelav(_btdiwo, _go2soun);
_ehgw98(_btdiwo, _3w0vzaq.rg);
discard;
}
#endif
