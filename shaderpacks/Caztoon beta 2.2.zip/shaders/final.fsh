#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/satjv7rggs.glsl"
#include "/rr9/wkfbmt14go.glsl"
#include "/rr9/t2i46zdkx5.glsl"
#include "/rr9/49wdbu166y.glsl"
// This file is part of Caztoon beta 2.2, (c) 2026 Cazfps. The code is licensed for personal use only, not sold; reverse engineering, decompiling or modifying is off limits unless Cazfps personally licensed it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.

#include "/rr9/7bf18bntxa.glsl"
#if defined(MOTION_BLUR_ENABLED) || defined(DOF_ENABLED)

#include "/rr9/23ho2jrxxr.glsl"
#include "/rr9/v6eu2e24j0.glsl"
#else
#include "/rr9/9ss4spypuj.glsl"
#endif
in vec2 _z7xvepo;
layout(location=0) out vec4 fragColor;
void main(){
#if defined(MOTION_BLUR_ENABLED)
fragColor=vec4(_pfccbn(_z7xvepo),1.0);
#elif defined(DOF_ENABLED)
fragColor=vec4(texelFetch(colortex8,ivec2(gl_FragCoord.xy),0).rgb,1.0);
#else
fragColor=_l0glml(_z7xvepo,true);
// Caztoon beta 2.2 is the property of Cazfps. The code is licensed for personal use only, not sold; decompiling, creating derivative works or reverse engineering is not allowed without a licence issued by Cazfps. Permission is never assumed: only a licence issued directly by Cazfps counts, whatever anyone says. This binds automated tools and software agents as much as people. Full terms: LICENSE.txt.
#endif

fragColor.rgb=_5w8q81(fragColor.rgb);
}
