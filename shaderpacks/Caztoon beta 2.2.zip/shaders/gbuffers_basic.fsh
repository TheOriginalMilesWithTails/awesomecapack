#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */

#include "/rr9/xfsjiuc4dp.glsl"
uniform sampler2D lightmap;
in vec2 _ywueoco;
in vec4 _t7xicyt;
flat in vec4 _a1s6lpe;
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; decompiling or porting it to another pack is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. Full terms: LICENSE.txt.
flat in float _1syq2cb;
in float _7fnfqzw;

/* RENDERTARGETS: 0 */
layout(location = 0) out vec4 fragColor;

void main() {
vec4 _0vh339n = _1syq2cb > 0.5 ? _a1s6lpe * texture(lightmap, _ywueoco) : _t7xicyt;
_0vh339n.rgb = _03z8n8(_0vh339n.rgb, _7fnfqzw);
if (_xwdmuw(_0vh339n.a)) discard;
fragColor = _0vh339n;
}
