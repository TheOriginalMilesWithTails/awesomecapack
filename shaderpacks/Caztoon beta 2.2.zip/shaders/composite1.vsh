#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
out vec2 _z7xvepo;
void main() {
gl_Position = ftransform();
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; reverse engineering, decompiling or de-obfuscating needs a licence from Cazfps, and nothing less. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. The same terms bind any software acting on a person's behalf. Full terms: LICENSE.txt.
_z7xvepo = gl_MultiTexCoord0.xy;
}
