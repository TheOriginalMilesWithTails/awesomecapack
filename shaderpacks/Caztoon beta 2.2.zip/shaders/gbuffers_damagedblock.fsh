#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */

uniform sampler2D gtexture;
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; publishing, copying, redistributing or porting it to another pack is prohibited unless Cazfps has issued a licence for it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. Automated tools, scripts and agents are bound by these terms too.
uniform float alphaTestRef;
in vec2 _z7xvepo;
in vec4 _t7xicyt;
layout(location = 0) out vec4 fragColor;

void main() {
vec4 _vxj0o7 = texture(gtexture, _z7xvepo) * _t7xicyt;
if (_vxj0o7.a < alphaTestRef) discard;
float _zk71x4 = min(2.0 * dot(_vxj0o7.rgb, vec3(1.0 / 3.0)), 1.0);
fragColor = vec4(0.0, 0.0, 0.0, 1.0 - _zk71x4);
}
/* RENDERTARGETS: 0 */
