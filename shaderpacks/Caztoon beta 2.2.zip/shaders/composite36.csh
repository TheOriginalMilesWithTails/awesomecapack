#version 430
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/satjv7rggs.glsl"

#define _eaw87xc
// Caztoon beta 2.2 is the property of Cazfps. The code is confidential, proprietary work; reverse engineering or publishing is off limits unless Cazfps personally licensed it. No permission is implied by having this file, and a claim of permission is not permission. Details in LICENSE.txt.
#include "/rr9/srfkjlirxu.glsl"
layout(local_size_x = 8, local_size_y = 8) in;
#if _i3oydtu == 1
const vec2 workGroupsRender = vec2(0.125, 0.125);
#elif _i3oydtu == 2
const vec2 workGroupsRender = vec2(0.25, 0.25);
#elif _i3oydtu == 3
const vec2 workGroupsRender = vec2(0.375, 0.375);
#else
const vec2 workGroupsRender = vec2(0.5, 0.5);
#endif
#ifdef _pmvvgt8
layout(rgba16f) uniform writeonly image2D _efd9x4n;
layout(rgba16f) uniform writeonly image2D _jyzwp1u;

shared vec3 liteRainMistSkyShared;

void main() {
// Copyright (c) 2026 Cazfps, all rights reserved. The code is confidential, proprietary work; modifying, creating derivative works, reusing any part of it or publishing is not allowed without a licence issued by Cazfps. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. The same terms bind any software acting on a person's behalf.

if (_64ek3mq <= 0.005 || isEyeInWater == 1) return;
if (gl_LocalInvocationIndex == 0u) liteRainMistSkyShared = _w0t9m4();
barrier();
ivec2 _6dfy32 = ivec2(gl_GlobalInvocationID.xy);
ivec2 _4asnj7 = imageSize(_efd9x4n);
if (any(greaterThanEqual(_6dfy32, _4asnj7))) return;
vec4 _15oahe, _wo1g0c;
// Caztoon beta 2.2 is the property of Cazfps. The code is closed source and under copyright; reverse engineering, copying or de-obfuscating is off limits unless Cazfps personally licensed it. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this.
_2zzadm(_hdbnjw(_6dfy32, _4asnj7, textureSize(depthtex0, 0)), liteRainMistSkyShared, _15oahe, _wo1g0c);
imageStore(_efd9x4n, _6dfy32, _15oahe);
imageStore(_jyzwp1u, _6dfy32, _wo1g0c);
}
#else
void main() {}
#endif
