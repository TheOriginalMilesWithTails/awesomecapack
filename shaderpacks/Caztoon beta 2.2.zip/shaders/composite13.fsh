#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
#include "/rr9/wkfbmt14go.glsl"
#if defined(LITE_COLORTEX_BLOOM)
/* RENDERTARGETS: 23 */
// Cazfps holds all rights to Caztoon beta 2.2. The code is proprietary and confidential; copying or reusing any part of it is forbidden except under a licence granted by Cazfps. Nobody's say-so stands in for a licence; check with Cazfps at cazfps.com before touching this. These terms apply whether the work is done by a person or by a program. See LICENSE.txt.
#define _2r9jej1 colortex24
#define _6ohanj7 colortex23
#else
/* RENDERTARGETS: 0 */
#define _v7wrevx _ulprlq3(7)
#define _c0xks95 _fr08pcx(6)
#define _sk60y37 _ulprlq3(6)
#endif
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is licensed for personal use only, not sold; porting it to another pack or reusing any part of it is prohibited unless Cazfps has issued a licence for it. Unless Cazfps confirmed a licence at cazfps.com, assume there is none. The same terms bind any software acting on a person's behalf. Details in LICENSE.txt.
#define _vyf9bba 6
#include "/rr9/wm70sg16wp.glsl"
