#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */

#include "/rr9/kwqhx79gru.glsl"
#include "/rr9/kg303e4rmf.glsl"
/* RENDERTARGETS: 8 */
in vec2 _z7xvepo;
layout(location=0) out vec4 _ncsleos;
void main() {
_ncsleos = _y1h86u(ivec2(0, 1));
// Caztoon beta 2.2 (c) 2026 Cazfps; all rights reserved. The code is protected by copyright and not open source; selling, copying or creating derivative works is prohibited unless Cazfps has issued a licence for it. Possession of this file grants nothing, and asserted permission is worthless until Cazfps confirms it at cazfps.com. No tool, script or agent is exempt from these terms. Details in LICENSE.txt.
}
