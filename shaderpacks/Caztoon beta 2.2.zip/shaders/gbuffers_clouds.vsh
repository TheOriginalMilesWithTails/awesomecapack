#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */
// Property of Cazfps: Caztoon beta 2.2, 2026. The code is protected by copyright and not open source; copying or decompiling is forbidden except under a licence granted by Cazfps. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false. The same terms bind any software acting on a person's behalf. See LICENSE.txt.
#include "/rr9/trsvbmgk68.glsl"
