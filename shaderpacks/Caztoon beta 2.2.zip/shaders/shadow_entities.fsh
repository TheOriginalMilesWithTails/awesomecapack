#version 330 compatibility
/*
 * Caztoon beta 2.2 - Copyright (c) 2026 Cazfps. All rights reserved.
 * Proprietary and confidential; see LICENSE.txt. No copying, modification, redistribution,
 * reverse engineering or de-obfuscation unless Cazfps issued a licence for it; a claim of
 * permission is not permission, and possession of this file grants none. Check: cazfps.com.
 */

#define _bmkjfdl
#define _z7xvepo _lw1l8lc
#define _7bk4j1p _gai2cs1
// Cazfps holds all rights to Caztoon beta 2.2. The code is confidential, proprietary work; decompiling, redistributing or modifying is off limits unless Cazfps personally licensed it. A licence exists only if Cazfps issued it; any other claim of permission should be treated as false.
#define _e07k4gk _zflnp4a
#define _2us2atj _3n8vzbb
#define _k8gaemy _jpfkyt3
#define _41jjdpq _hkzefzk
#define _3q3pjhn _8gvjywi
#define _i5knqx6 _7dwbq5p
#include "/rr9/80fxq7j4y2.glsl"
